const path = require('path');
const MonacoEditorPlugin = require('monaco-editor-webpack-plugin');
const pkg = require('./package.json');

const ENV = process.env.VUE_APP_ENV || 'dev';
const options = {
  pro: {
    assetsRoot: path.resolve(__dirname, './dist/PRO', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/PRO/${pkg.version}/`,
  },
  uat: {
    assetsRoot: path.resolve(__dirname, './dist/UAT', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/UAT/${pkg.version}/`,
  },
  fat: {
    assetsRoot: path.resolve(__dirname, './dist/FAT', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/FAT/${pkg.version}/`,
  },
  dev: {
    assetsRoot: path.resolve(__dirname, './dist/DEV', pkg.version),
    assetsPublicPath: '/',
  }
};

// const config = options[ENV] || options.dev;
if (process.env.VUE_APP_ENV !== 'dev') {
  process.env.NODE_ENV = 'production';
}
module.exports = {
  // outputDir: config.assetsRoot,
  // publicPath: config.assetsPublicPath,
  outputDir: './dist',
  publicPath: './', // /aurora/
  configureWebpack: {
    entry: {
      app: './base/main.js'
    },
    resolve: {
      alias: {
        base: path.resolve(__dirname, './base'),
        src: path.resolve(__dirname, './src')
      }
    },
    plugins: [
      new MonacoEditorPlugin({
        // https://github.com/Microsoft/monaco-editor-webpack-plugin#options
        // Include a subset of languages support
        // Some language extensions like typescript are so huge that may impact build performance
        // e.g. Build full languages support with webpack 4.0 takes over 80 seconds
        // Languages are loaded on demand at runtime
        // languages: ['javascript', 'css', 'html', 'typescript', 'sql']
        features: ['coreCommands', 'find']
      })
    ]
  },
};
