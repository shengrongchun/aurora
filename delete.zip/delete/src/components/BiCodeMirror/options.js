const theme = ['eclipse', 'yonce'];
export default {
  theme,
};
