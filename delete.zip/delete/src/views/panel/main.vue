<template>
  <div :class="['main', $store.state.panel.theme]">
    <!-- 极光预览页面 -->
    <drag-container
      v-if="$store.state.panel.preView"
      :list="$store.state.panel.compList"/>
    <!-- 极光编辑页面 -->
    <div
      v-show="!$store.state.panel.preView"
      class="main-flex">
      <div class="left-container">
        <drag-header/>
        <drag-container :list="$store.state.panel.compList"/>
      </div>
      <!-- 右边的配置页面 -->
      <div
        v-if="$store.state.panel.compList.length>0&&activeObj.type"
        class="right-container">
        <component
          :key="activeObj.i"
          :is="activeObj.type+'Config'"
          :data="activeObj"/>
      </div>
    </div>
  </div>
</template>
<script>
import dragHeader from './dragComps/dragHeader';
import dragContainer from './dragComps/dragContainer';

export default {
  components: {
    dragHeader,
    dragContainer,
  },
  computed: {
    activeObj() {
      return this.$store.state.panel.activeComp;
    }
  },
  watch: { // 监听组件标签修改变化，统一处理重复标题名问题
    activeObj() { // 此变化，说明下面的text变化是因为组件切换了
      this.compChange = true;
    },
    'activeObj.styles.label.text': function watch(newV, oldV) {
      if (this.compChange) {
        delete this.compChange;
        return;
      }
      if (!newV) {
        this.$message({ type: 'warning', message: '组件标题必填' });
        this.activeObj.styles.label.text = oldV;
        this.compChange = true;
        return;
      }
      if (this.$store.state.panel.labelMap[newV]) {
        this.$message({ type: 'warning', message: '组件标题重复' });
        this.activeObj.styles.label.text = oldV;
        this.compChange = true;
        return;
      }
      delete this.$store.state.panel.labelMap[oldV];
      this.$store.state.panel.labelMap[newV] = true;
    },
  }
};
</script>
<style scoped lang="less">
.main {
  width: 100%;
  height: 100%;
  .main-flex {
    width: 100%;
    height: 100%;
    display: flex;
    .left-container {
      flex: 9;
      height: 100%;
    }
    .right-container {
      flex: 3;
      height: 100%;
    }
  }
}
</style>
