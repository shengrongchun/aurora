<template>
  <el-dialog
    v-loading="loading"
    title="数据权限设置"
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    width="50%">
    <el-form
      ref="form"
      :model="form"
      label-width="100px">
      <el-form-item label="数据权限控制">
        <el-switch
          style="margin-left:10px"
          v-model="form.authOpen"/>
      </el-form-item>
      <template v-if="form.authOpen">
        <el-form-item label="单车城市权限">
          <el-select
            v-model="form.cityAuthType"
            placeholder="单车城市权限">
            <el-option
              v-for="key in controlTypes"
              :key="key"
              :label="controlTypes[key]"
              :value="key"/>
          </el-select>
        </el-form-item>
        <el-form-item label="权限控制情况">
          <span class="noticeText">{{ controller.cLength }}个组件可以控制住数据权限 ; {{ controller.nCLength }}个组件不能控制，可选择修改或忽略</span>
        </el-form-item>
      </template>
     </el-form>
     <el-table
      v-if="form.authOpen"
      :data="form.compAuths">
      <el-table-column label="组件名称">
        <template slot-scope="scope">
          <span
            :style="scope.row.authType=== '不控制' ? 'color:red':''">
            {{ scope.row.compName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限控制粒度">
        <template slot-scope="scope">
          <el-dropdown v-model="scope.row.authType">
            <span class="el-dropdown-link">
              <span
                :style="scope.row.authType==='不控制' ? 'color:red': ''">
                {{ scope.row.authType || '请选择' }}</span>
              <i class="el-icon-arrow-down el-icon--right"/>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                @click.native="scope.row.authType='不控制'">
                不控制</el-dropdown-item>
              <el-dropdown-item
                @click.native="scope.row.authType='城市'">
                城市</el-dropdown-item>
              <el-dropdown-item
                @click.native="scope.row.authType='省区'">
                省区</el-dropdown-item>
              <el-dropdown-item
                @click.native="scope.row.authType='大区'">
                大区</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
      <el-table-column label="权限控制字段">
        <template slot-scope="scope">
          <el-select
            :disabled="scope.row.authType=== '不控制'"
            filterable
            v-model="scope.row.authCol"
            placeholder="请选择">
            <el-option
              v-for="item in scope.row.controlFieldList"
              :key="item.name"
              :label="item.name"
              :value="item.name"/>
          </el-select>
        </template>
      </el-table-column>
    </el-table>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button
        type="primary"
        @click="save">保 存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import {
  queryDashBoardAuthDef,
  queryDashBoardAuth,
  saveDashBoardAuth
} from '@/api/space';
import { queryXyOnline } from '@/api/panel';

export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    list: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      loading: false,
      dialogVisible: false,
      controlTypes: {},
      form: {
        dashboardId: null,
        authOpen: false,
        cityAuthType: null,
        compAuths: []
      },
    };
  },
  computed: {
    controller() {
      const cLength = this.form.compAuths.filter(item => item.authType !== '不控制').length;
      return {
        cLength,
        nCLength: this.form.compAuths.length - cLength
      };
    }
  },
  created() {
    this.getCityAuList();
    this.getOldData();
  },
  methods: {
    // 获取维度和度量
    async queryXyOnline(params, idx) {
      const res = await queryXyOnline(params);
      this.form.compAuths[idx].controlFieldList = res || [];// 下拉选择
    },
    getCityAuList() {
      queryDashBoardAuthDef(-1).then((res) => {
        this.controlTypes = res.cityAuthType;
      });
    },
    setTableList() {
      this.list.forEach((item, idx) => {
        const {
          compId, compName, dataSetId, dataSetName, dataSetType
        } = item;
        this.form.compAuths.push({
          compId,
          compName,
          authType: this.mapList[compId] ? this.mapList[compId].authType : null,
          authCol: this.mapList[compId] ? this.mapList[compId].authCol : null,
          controlFieldList: []
        });
        // 获取controlFieldList
        this.queryXyOnline({
          dataSetId,
          dataSetName,
          dataSetType
        }, idx);
      });
    },
    getOldData() {
      this.mapList = {};
      if (this.$route.params.id !== 'create') { // 编辑
        // 获取所有的已经设置的权限值
        queryDashBoardAuth(this.$route.params.id).then((res) => {
          const {
            dashboardId, authOpen, cityAuthType, compAuths
          } = res;
          (compAuths || []).forEach((item) => {
            this.mapList[item.compId] = item;
          });
          this.form = {
            dashboardId,
            authOpen: authOpen === 1,
            cityAuthType,
            compAuths: []
          };
          this.setTableList();
        }).catch(() => {});
      } else {
        this.setTableList();
      }
    },
    save() {
      if (this.form.authOpen) { // 数据权限控制打开的情况下
        if (!this.form.cityAuthType) {
          this.$message({ type: 'warning', message: '请选择单车城市权限' });
          return;
        }
        for (let i = 0; i < this.form.compAuths.length; i += 1) {
          const { authType, authCol } = this.form.compAuths[i];
          if (!authType) {
            this.$message({ type: 'warning', message: '请选择粒度字段' });
            return;
          }
          if (authType !== '不控制' && !authCol) {
            this.$message({ type: 'warning', message: '请选择城市控制字段' });
            return;
          }
        }
      }
      //
      const promise = this.$parent.save();
      promise.then((id) => {
        this.$route.params.id = id;
        const params = {
          dashboardId: id,
          authOpen: this.form.authOpen === true ? 1 : 0,
          cityAuthType: this.form.cityAuthType,
          compAuths: this.form.compAuths.map((item) => {
            const {
              authCol, authType, compId, compName
            } = item;
            return {
              authCol,
              authType,
              compId,
              compName
            };
          })
        };
        this.loading = true;
        saveDashBoardAuth(params).then(() => {
          this.$message({ type: 'success', message: '数据权限保存成功' });
          this.$emit('close');
        }).finally(() => {
          this.loading = true;
        });
      }).catch(() => {});
    }
  }
};
</script>
<style scoped lang="less">
  .noticeText {
    background: rgb(132, 194, 246);
    font-size: 12px;
    font-weight: bolder;
    border-radius: 5px;
    color: #fff;
    padding: 3px 10px;
  }
</style>
