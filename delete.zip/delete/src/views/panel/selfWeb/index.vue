<template>
  <Main
    v-loading="loading"
    v-if="!error"
    element-loading-text="数据查询中，请耐心等候"
    element-loading-spinner="el-icon-loading"
  />
</template>
<script>
import Main from '../main.vue';
import { getDataStatus } from '../../../api/panel';

export default {
  components: {
    Main
  },
  props: {
    dataSetId: {
      type: [String, Number],
      default: null
    },
    dataSetType: {
      type: String,
      default: null
    }
  },
  data() {
    return {
      loading: true,
      error: false,
    };
  },
  created() {
    this.timeRequest();
  },
  methods: {
    timeRequest() {
      this.loading = true;
      getDataStatus(this.dataSetId, this.dataSetType).then((res) => {
        if (this.timeout) {
          clearTimeout(this.timeout);
          this.timeout = null;
        }
        if (res) {
          const { state } = res;
          if (state === 'PENDING' || state === 'RUNNING') {
            this.error = false;
            this.timeout = setTimeout(() => {
              this.timeRequest();
            }, 3000);
          } else if (state === 'ERROR' || state === 'CANCELED') { // 错误
            this.$message.error('数据集解析有误或者取消');
            this.error = true;
            this.loading = false;
          } else if (state === 'FINISHED') { // 成功
            this.$message.success('数据集解析成功');
            this.error = false;
            this.loading = false;
            this.$store.commit('addComp', {
              type: 'Line',
              x: 0,
              y: 0,
              list: this.$store.state.panel.compList,
              compType: null,
              vm: this
            });
          }
        } else {
          this.$message.error('数据集解析有误');
          this.error = true;
          this.loading = false;
        }
      }).catch(() => {
        this.loading = false;
        this.error = true;
      });
    }
  }
};
</script>
