<template>
  <div :class="['compInfo']">
    <el-form
      label-position="right"
      label-width="130px">
      <div class="title">基础信息</div>
      <el-form
        label-width="50px">
        <template>
          <el-form-item label="标题">
            <el-input
              v-model="styles.label.text"
              placeholder="请输入标题"/>
          </el-form-item>
          <el-form-item label="备注">
            <el-input
              v-model="styles.label.subText"
              placeholder="请输入备注"/>
          </el-form-item>
        </template>
      </el-form>
      <div class="title">图表样式</div>
      <el-form-item label="显示图表图例">
        <el-switch
          v-model="styles.legend.show"
          active-color="#409EFF"
          inactive-color="#eee"/>
        <template v-if="styles.legend.show">
          <label class="position">位置</label>
          <el-select
            v-model="styles.legend.top"
            :style="{width:'68px'}"
            :popper-append-to-body="false">
            <el-option
              label="上"
              value="top"/>
            <el-option
              label="中"
              value="middle"/>
            <el-option
              label="下"
              value="bottom"/>
          </el-select>
        </template>
      </el-form-item>
      <el-form-item label="显示图表数据标签">
        <el-switch
          v-model="styles.labelNormal.show"
          active-color="#409EFF"
          inactive-color="#eee"/>
        <template v-if="styles.labelNormal.show">
          <label class="position">位置</label>
          <el-select
            v-model="styles.labelNormal.position"
            :style="{width:'68px'}"
            :popper-append-to-body="false">
            <el-option
              label="上"
              value="top"/>
            <el-option
              label="下"
              value="bottom"/>
            <el-option
              label="左"
              value="left"/>
            <el-option
              label="右"
              value="right"/>
            <el-option
              label="内嵌"
              value="inside"/>
          </el-select>
        </template>
      </el-form-item>
      <template v-if="data.type==='Line'">
        <el-form-item label="线条样式">
          <el-radio
            v-model="styles.lineParams.smooth"
            :label="false">折线</el-radio>
          <el-radio
            v-model="styles.lineParams.smooth"
            :label="true">曲线</el-radio>
        </el-form-item>
        <el-form-item label="区域填充类型">
          <el-radio
            v-model="styles.lineParams.areaStyle"
            :label="null">不填充</el-radio>
          <el-radio
            v-model="styles.lineParams.areaStyle"
            :label="true">填充</el-radio>
        </el-form-item>
        <el-form-item label="堆积类型">
          <el-radio
            v-model="styles.lineParams.stack"
            :label="null">不堆积</el-radio>
          <el-radio
            v-model="styles.lineParams.stack"
            label="总量">堆积</el-radio>
        </el-form-item>
      </template>
      <template v-if="data.type==='Bar'">
        <el-form-item label="图表方向">
          <el-radio
            v-model="styles.barParams.vertical"
            :label="false">水平</el-radio>
          <el-radio
            v-model="styles.barParams.vertical"
            :label="true">垂直</el-radio>
        </el-form-item>
        <el-form-item label="堆积类型">
          <el-radio
            v-model="styles.barParams.stack"
            :label="null">不堆积</el-radio>
          <el-radio
            v-model="styles.barParams.stack"
            label="总量">堆积</el-radio>
        </el-form-item>
      </template>
      <template v-if="data.type==='Line'||data.type==='Bar'||data.type==='Comb'">
        <div class="title">坐标轴</div>
        <ul class="axis">
          <li
            :class="{'active':axisType==='x'}"
            @click="axisType='x'">{{ axisName.x }}</li>
          <li
            :class="{'active':axisType==='y'}"
            @click="axisType='y'">{{ axisName.y }}</li>
          <li
            v-if="styles.xAxis[0].select.length<2"
            :class="{'active':axisType==='yy'}"
            @click="axisType='yy'">{{ axisName.yy }}</li>
        </ul>
        <el-form
          label-width="105px">
          <br>
          <el-form-item label="显示轴">
            <el-switch
              v-model="styles[axis.type][axis.index].show"
              active-color="#409EFF"
              inactive-color="#eee"/>
          </el-form-item>
          <template v-if="data.type==='Comb'">
            <template v-if="axisType==='y'">
              <el-form-item label="堆积类型">
                <el-radio
                  v-model="styles.barParams.stack"
                  :label="null">不堆积</el-radio>
                <el-radio
                  v-model="styles.barParams.stack"
                  label="总量">堆积</el-radio>
              </el-form-item>
            </template>
            <template v-if="axisType==='yy'">
              <el-form-item label="线条样式">
                <el-radio
                  v-model="styles.lineParams.smooth"
                  :label="false">折线</el-radio>
                <el-radio
                  v-model="styles.lineParams.smooth"
                  :label="true">曲线</el-radio>
              </el-form-item>
              <!-- <el-form-item label="区域填充类型">
                <el-radio
                  v-model="styles.lineParams.areaStyle"
                  :label="null">不填充</el-radio>
                <el-radio
                  v-model="styles.lineParams.areaStyle"
                  :label="true">填充</el-radio>
              </el-form-item>
              <el-form-item label="堆积类型">
                <el-radio
                  v-model="styles.lineParams.stack"
                  :label="null">不堆积</el-radio>
                <el-radio
                  v-model="styles.lineParams.stack"
                  label="总量">堆积</el-radio>
              </el-form-item> -->
            </template>
          </template>
          <template>
            <el-form-item label="名称">
              <el-input
                v-model="styles[axis.type][axis.index].name"
                placeholder="请输入轴名称"/>
            </el-form-item>
            <el-form-item :label="axis.name+'选择'">
              <el-select
                multiple
                :placeholder="'请选择'+axis.name"
                :multiple-limit="axis.limit"
                :collapse-tags="true"
                :popper-append-to-body="false"
                value-key="label"
                v-model="styles[axis.type][axis.index].select">
                <el-option
                  :label="obj.label"
                  :key="idx"
                  v-for="(obj,idx) in metricsFilter"
                  :value="obj"/>
              </el-select>
            </el-form-item>
            <el-form-item label="显示网格线">
              <el-switch
                v-model="styles[axis.type][axis.index].splitLine.show"
                active-color="#409EFF"
                inactive-color="#eee"/>
            </el-form-item>
            <el-form-item label="显示刻度线">
              <el-switch
                v-model="styles[axis.type][axis.index].axisLabel.show"
                active-color="#409EFF"
                inactive-color="#eee"/>
            </el-form-item>
          </template>
        </el-form>
      </template>
    </el-form>
  </div>
</template>
<script>

export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      axisType: 'x',
      styles: {},
    };
  },
  computed: {
    axisName() {
      const val = {
        x: '水平X轴',
        y: '左侧Y轴',
        yy: '右侧Y轴'
      };
      if (this.data.type === 'Bar' && !this.styles.barParams.vertical) {
        val.x = '左侧Y轴';
        val.y = '下侧X轴';
        val.yy = '上侧X轴';
      }
      if (this.data.type === 'Comb') {
        val.y = '左侧Y轴(柱)';
        val.yy = '右侧Y轴(折)';
      }
      return val;
    },
    axis() {
      let limit = 0;
      if (this.axisType === 'x') {
        const h = this.styles.yAxis[0].select.length + this.styles.yAxis[1].select.length;
        limit = h > 1 ? 1 : 2;
        return {
          name: '维度',
          type: 'xAxis',
          limit,
          index: 0,
        };
      }
      //
      if (this.styles.xAxis[0].select.length > 1) {
        limit = 1;
      }
      if (this.axisType === 'y') {
        return {
          name: '度量',
          type: 'yAxis',
          limit,
          index: 0,
        };
      }
      return {// yy
        name: '度量',
        type: 'yAxis',
        limit,
        index: 1,
      };
    },
    metricsFilter() {
      if (!this.data.params.dimensions) {
        return [];
      }
      let array = [];
      if (this.axisType === 'x') {
        array = this.data.params.dimensions;
      } else {
        const { select } = this.styles.yAxis[this.axisType === 'y' ? 1 : 0];
        array = this.data.params.metrics.filter((item) => {
          let result = true;
          for (let i = 0, j = select.length; i < j; i += 1) {
            if (select[i].label === item.label) {
              result = false;
              break;
            }
          }
          return result;
        });
      }
      return array;
    }
  },
  created() {
    this.styles = this.data.styles;
  }
};
</script>
<style scoped lang="less">
.compInfo {
  &.disabled {
    pointer-events: none;
  }
  .el-form {
    /deep/ .title {
      font-size: 15px;
      font-weight: bolder;
      padding: 10px 0;
      margin-bottom: 10px;
      border-bottom: 1px solid #3a4158;
    }
    /deep/ .position {
      font-size: 13px;
      font-weight: bolder;
      margin: 0 10px;
      vertical-align: bottom;
    }
    /deep/ .axis {
      margin: 0;
      padding: 0;
      list-style: none;
      width: 100%;
      border: 1px solid #3a4158;
      display: flex;
      li {
        &.active {
          color: #409EFF;
        }
        cursor: pointer;
        font-size: 13px;
        padding: 2px 0;
        text-align: center;
        flex: 1;
        display: inline-block;
        &:not(:last-child) {
          border-right: 1px solid #3a4158;
        }
      }
    }
  }
}
</style>
