export function validX(vm, data) { // 维度验证
  if (data.type === 'metric' && vm.data.type !== 'Select') {
    vm.$message({
      type: 'warning',
      message: '维度只能添加维度属性'
    });
    return true;
  }
  if (vm.data.type === 'Select' && vm.data.params.dimensions.length > 1) {
    vm.$message({
      type: 'warning',
      message: '最多添加两列'
    });
    return true;
  }
  if (vm.dimensionsMap[data.name] === data.label) { // 重复
    vm.$message({
      type: 'warning',
      message: '重复添加'
    });
    return true;
  }
  return false;
}
export function validY(vm, obj, data, keyList) { // 度量验证
  for (let i = 0, j = keyList.length; i < j; i += 1) {
    const [aggregate, name] = keyList[i];
    const label = name + data.label;
    if (!vm.metricsMap[label]) {
      obj.aggregate = aggregate;
      obj.label = label;
      vm.metricsMap[label] = true;
      break;
    }
  }
}

// 拖动添加过程中维度、度量的验证
export function validAll(data, vm, mask) {
  const { type, params } = data;
  if (type === 'Line' || type === 'Bar' || type === 'Comb') {
    const dlength = params.dimensions.length;
    const mlength = params.metrics.length;
    if (mask === 'dimensions') { // 维度
      if ((type === 'Comb' && dlength > 0) || (dlength > 0 && mlength > 1) || dlength > 1) {
        vm.$message({ type: 'warning', message: '维度已不能再添加' });
        return true;
      }
    } else if (mask === 'metrics') { // 度量
      if (mlength > 0 && dlength > 1) {
        vm.$message({ type: 'warning', message: '度量已不能再添加' });
        return true;
      }
    }
  } else if (type === 'Pie') {
    if (params[mask].length > 0) {
      vm.$message({ type: 'warning', message: `${mask === 'dimensions' ? '维度' : '度量'}最多添加一个` });
      return true;
    }
  } else if (type === 'Label') {
    if (params[mask].length > 2) {
      vm.$message({ type: 'warning', message: '度量最多添加三个' });
      return true;
    }
  }
  return false;
}
// 拖动添加过程中行、列的验证
export function validRowsC(vm, data, obj, Type) {
  //
  let rowsDimNum = 0;// 行维度个数
  vm.rows.forEach((row) => {
    if (row.dmType === 'dimension') {
      rowsDimNum += 1;
    }
  });
  // let columnsDimNum = 0;// 列维度个数
  // vm.columns.forEach((column) => {
  //   if (column.dmType === 'dimension') {
  //     columnsDimNum += 1;
  //   }
  // });
  // 行全部是维度
  const rowsAllDim = vm.rows.length > 0 && (vm.rows.length === rowsDimNum);
  // 列全部是维度
  // const columnsAllDim = vm.columns.length > 0 && (vm.columns.length === columnsDimNum);
  // 行全部是度量
  const rowsAllMet = vm.data.params.hasMetric === 'rows' && (vm.rows.length === Object.keys(vm.metricsMap).length);
  // 列全部是度量
  const columnsAllMet = vm.data.params.hasMetric === 'columns' && (vm.columns.length === Object.keys(vm.metricsMap).length);
  //
  if (Type === 'rows' && vm.rows.length > 1 && !rowsAllDim && !rowsAllMet) {
    vm.$message({
      type: 'warning',
      message: '行已经不满足添加条件'
    });
    return true;
  }
  //
  if (Type === 'columns' && vm.columns.length > 1 && vm.rows.length > 0 && !(rowsAllDim && columnsAllMet)) {
    vm.$message({
      type: 'warning',
      message: '列的个数最多两个'
    });
    return true;
  }
  if (data.type === 'dimension') { // 维度
    if (vm.dimensionsMap[data.name] === data.label) { // 重复
      vm.$message({
        type: 'warning',
        message: '重复添加'
      });
      return true;
    }
    vm.dimensionsMap[data.name] = data.label;
  } else { // 度量
    if (vm.data.params.hasMetric && vm.data.params.hasMetric !== Type) {
      vm.$message({
        type: 'warning',
        message: `${Type === 'rows' ? '列' : '行'}上已经有度量时，不能再添加度量`
      });
      return true;
    }
    obj.label = null;
    for (let i = 0, j = vm.keyList.length; i < j; i += 1) {
      const [aggregate, name] = vm.keyList[i];
      const label = name + data.label;
      if (!vm.metricsMap[label]) {
        obj.aggregate = aggregate;
        obj.label = label;
        vm.metricsMap[label] = true;
        break;
      }
    }
    if (!obj.label) {
      vm.$message({ type: 'warning', message: '同一属性计算方法已经添加满，无法再添加' });
      return true;
    }
    vm.data.params.hasMetric = Type;
    //
    obj.type = 'simple';
    obj.formatType = 'number'; // number 数值 percent 百分比,
    obj.formatNum = 0; // 小数位
  }
  return false;
}
// 更新验证
export function applyValid(data, vm) {
  const { type, params } = data;
  const { filters } = params;
  for (let i = 0; i < filters.length; i += 1) {
    if (!filters[i].conditions || filters[i].conditions.length === 0) {
      vm.$message({ type: 'warning', message: `《 ${filters[i].label} 》请指定过滤条件` });
      return true;
    }
  }
  if (type === 'Select') { // 下拉组件数据源验证
    if (!params.dimensions.length) {
      vm.$message({ type: 'warning', message: '筛选列必填' });
      return true;
    }
  } else if (type === 'Line' || type === 'Bar' || type === 'Comb' || type === 'Pie') { // 折线、柱状、组合、饼图数据源验证
    if (!params.dimensions.length || !params.metrics.length) {
      vm.$message({ type: 'warning', message: '维度或度量必填' });
      return true;
    }
  } else if (type === 'Lou' || type === 'Label') { // 漏斗、标签组件数据源验证
    if (!params.metrics.length) {
      vm.$message({ type: 'warning', message: '度量必填' });
      return true;
    }
  } else if (type === 'Table') { // 表格组件
    if (!params.hasMetric) {
      vm.$message({ type: 'warning', message: '行列必选度量' });
      return true;
    }
    if (!params.rows.length || !params.columns.length) {
      vm.$message({ type: 'warning', message: '行列必填' });
      return true;
    }
  }
  return false;
}
