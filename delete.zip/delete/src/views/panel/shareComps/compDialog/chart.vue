<template>
  <div class="chartXYW">
    <!-- 行 -->
    <div
      class="rows"
      v-if="showItem.includes('r')">
      <span>行
        <div @click="customType('rows')">
          <i class="iconfont icon-plus"/>自定义
        </div>
      </span>
      <ul
        :class="{'active':typeActive==='r'}"
        @dragover.prevent.stop="()=> {typeActive='r'}"
        @dragleave.stop="()=> {typeActive=null}"
        @drop.stop="(ev)=> {drop(ev,'r');typeActive=null}">
        <li
          class="row-li no"
          v-if="rows.length===0">
          <el-input
            placeholder="拖动右侧维度/度量添加"
            readonly/>
        </li>
        <draggable
          v-else
          :list="rows">
          <li
            class="row-li"
            @mousedown="mousedown(item,idx,'r')"
            v-for="(item,idx) in rows"
            :key="idx">
            <el-input
              v-model="item.label"
              :prefix-icon="'iconfont icon-'+item.dataType"
              readonly>
              <i
                v-if="item.dmType!=='dimension'"
                class="el-icon-edit"
                @click="editDimension(item,idx,'y','rows')"
                slot="suffix"/>
              <i
                slot="suffix"
                @click="tableDel(rows,idx,item)"
                class="iconfont icon-shanchu-copy-copy"/>
            </el-input>
          </li>
        </draggable>
      </ul>
    </div>
    <!-- 列 -->
    <div
      class="rows"
      v-if="showItem.includes('c')">
      <span>列
        <div @click="customType('columns')">
          <i class="iconfont icon-plus"/>自定义
        </div>
      </span>
      <ul
        :class="{'active':typeActive==='c'}"
        @dragover.prevent.stop="()=> {typeActive='c'}"
        @dragleave.stop="()=> {typeActive=null}"
        @drop.stop="(ev)=> {drop(ev,'c');typeActive=null}">
        <li
          class="row-li no"
          v-if="columns.length===0">
          <el-input
            placeholder="拖动右侧维度/度量添加"
            readonly/>
        </li>
        <draggable
          v-else
          :list="columns">
          <li
            class="row-li"
            @mousedown="mousedown(item,idx,'c')"
            v-for="(item,idx) in columns"
            :key="idx">
            <el-input
              v-model="item.label"
              :prefix-icon="'iconfont icon-'+item.dataType"
              readonly>
              <i
                v-if="item.dmType!=='dimension'"
                class="el-icon-edit"
                @click="editDimension(item,idx,'y','columns')"
                slot="suffix"/>
              <i
                slot="suffix"
                @click="tableDel(columns,idx,item)"
                class="iconfont icon-shanchu-copy-copy"/>
            </el-input>
          </li>
        </draggable>
      </ul>
    </div>
    <!-- 维度 -->
    <div
      class="rows"
      v-if="showItem.includes('x')">
      <span>{{ data.type==='Select'?'筛选列':'类别轴/维度' }}</span>
      <ul
        :class="{'active':typeActive==='x'}"
        @dragover.prevent.stop="()=> {typeActive='x'}"
        @dragleave.stop="()=> {typeActive=null}"
        @drop.stop="(ev)=> {drop(ev,'x');typeActive=null}">
        <li
          class="row-li no"
          v-if="dimensions.length===0">
          <el-input
            :placeholder="'拖动右侧'+ (data.type==='Select'?'维度/度量':'维度')+'添加'"
            readonly/>
        </li>
        <draggable
          v-else
          :list="dimensions">
          <li
            class="row-li"
            v-for="(item,idx) in dimensions"
            :key="idx+'x'">
            <el-input
              v-model="item.label"
              :prefix-icon="'iconfont icon-'+item.dataType"
              readonly>
              <i
                slot="suffix"
                @click="delType(dimensions,idx,'x',item)"
                class="iconfont icon-shanchu-copy-copy"/>
            </el-input>
          </li>
        </draggable>
      </ul>
    </div>
    <!-- 度量 -->
    <div
      class="rows"
      v-if="showItem.includes('y')">
      <span>值轴/度量
        <div
          @click="customType">
          <i class="iconfont icon-plus"/>自定义
        </div>
      </span>
      <ul
        :class="{'active':typeActive==='y'}"
        @dragover.prevent.stop="()=> {typeActive='y'}"
        @dragleave.stop="()=> {typeActive=null}"
        @drop.stop="(ev)=> {drop(ev,'y');typeActive=null}">
        <li
          class="row-li no"
          v-if="metrics.length===0">
          <el-input
            placeholder="拖动右侧维度/度量添加"
            readonly/>
        </li>
        <draggable
          v-else
          :list="metrics">
          <li
            class="row-li"
            v-for="(item,idx) in metrics"
            :key="idx+'y'">
            <el-input
              :prefix-icon="'iconfont icon-'+item.dataType"
              :value="item.label"
              readonly>
              <i
                class="el-icon-edit"
                @click="editDimension(item,idx,'y')"
                slot="suffix"/>
              <i
                slot="suffix"
                @click="delType(metrics,idx,'y',item)"
                class="iconfont icon-shanchu-copy-copy"/>
            </el-input>
          </li>
        </draggable>
      </ul>
    </div>
    <!-- 过滤 -->
    <div
      class="rows"
      v-if="showItem.includes('w')">
      <span>过滤条件</span>
      <ul
        :class="{'active':typeActive==='w'}"
        @dragover.prevent.stop="()=> {typeActive='w'}"
        @dragleave.stop="()=> {typeActive=null}"
        @drop.stop="(ev)=> {drop(ev,'w');typeActive=null}">
        <li
          class="row-li no"
          v-if="filters.length===0">
          <el-input
            placeholder="拖动右侧维度/度量添加"
            readonly/>
        </li>
        <draggable
          v-else
          :list="filters">
          <li
            class="row-li"
            v-for="(item,idx) in filters"
            :key="idx+'w'">
            <el-input
              :prefix-icon="'iconfont icon-'+item.dataType"
              v-model="item.label"
              readonly>
              <i
                class="el-icon-edit"
                @click="editDimension(item,idx,'w')"
                slot="suffix"/>
              <i
                slot="suffix"
                @click="delType(filters,idx,'w',item)"
                class="iconfont icon-shanchu-copy-copy"/>
            </el-input>
          </li>
        </draggable>
      </ul>
    </div>
    <!-- 排序 -->
    <div
      class="rows"
      v-if="showItem.includes('s')">
      <span>排序
        <div
          @click="addSort">
          <i class="iconfont icon-plus"/>添加
        </div>
      </span>
      <div
        v-for="(obj,index) in sortBy"
        class="parent"
        :key="index">
        <el-select
          class="sort"
          v-model="obj.column"
          placeholder="请选择"
          :popper-append-to-body="false">
          <el-option
            v-for="(item,idx) in sortList"
            :label="item.label"
            :value="item.column"
            :disabled="item.disabled"
            :key="idx"/>
        </el-select>
        <i
          :title="obj.asc?'升':'降'"
          class="el-icon-sort-down"
          @click="obj.asc=!obj.asc"
          :class="{'active':!obj.asc}"/>
        <i
          :title="obj.asc?'升':'降'"
          class="el-icon-sort-up"
          @click="obj.asc=!obj.asc"
          :class="{'active':obj.asc}"/>
        <i
          class="el-icon-delete"
          @click="delSort(index)"/>
      </div>
    </div>
    <chartDialog
      v-if="dialogVisible"
      :obj="dialogObj"
      :type="dialogType"
      :visible="dialogVisible"
      @close="dialogVisible=false"
      @save="dialogSave"
    />
  </div>
</template>
<script>
import draggable from 'vuedraggable';
import chartDialog from './chartDialog';
import {
  validX, validY, validAll, validRowsC
} from './checkValid';
import { ySetTypeMap } from '../options';

export default {
  components: {
    draggable,
    chartDialog
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    },
    showItem: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      dialogVisible: false,
      dialogType: null,
      dialogObj: {},
      typeActive: null, // x 维度 y 度量
      dimensions: [], // 维度列表
      dimensionsMap: {}, // 维度map 检测是否重复
      metrics: [], // 度量列表
      metricsMap: {}, // 度量map 检测是否重复
      filters: [], // 过滤列表
      rows: [], // 行
      columns: [], // 列
      sortBy: []
    };
  },
  computed: {
    sortList() {
      let list = [];
      if (this.data.type === 'Table') {
        list = this.rows.concat(this.columns);
      } else {
        list = this.dimensions.concat(this.metrics);
      }
      //
      const listVal = [];
      list.forEach((item) => {
        const column = item.aggregate ? `${item.aggregate.toUpperCase()}(${item.column})` : (item.column || item.expression);
        listVal.push({
          column,
          label: item.label,
          disabled: !this.sortBy.every(obj => obj.column !== column)
        });
      });
      return listVal;
    }
  },
  created() {
    this.keyList = Object.entries(ySetTypeMap);
    if (this.data.type === 'Table') {
      this.tableInit();
    } else {
      this.init();
    }
  },
  methods: {
    init() {
      if (Object.keys(this.data.params).length < 1) { // 新建
        this.data.params = {
          dataSetId: null,
          dataSetType: null,
          dataSetName: null,
          pageSize: 1000,
          dimensions: [], // 维度
          metrics: [], // 度量
          filters: [], // 过滤
          sortBy: [],
        }; // 数据源参数;
      }
      const {
        dimensions, metrics, filters, sortBy
      } = this.data.params;
      this.dimensions = dimensions;
      this.metrics = metrics;
      this.filters = filters;
      this.sortBy = sortBy;
      //
      this.dimensions.forEach((data) => {
        this.dimensionsMap[data.column] = data.label;
      });
      this.metrics.forEach((data) => {
        this.metricsMap[data.label] = true;
      });
    },
    tableInit() {
      if (Object.keys(this.data.params).length < 1) {
        this.data.params = {
          dataSetId: null,
          dataSetType: null,
          dataSetName: null,
          pageNo: 1,
          pageSize: 1000,
          hasMetric: null, // 度量在哪里: columns  rows null
          rows: [], // 行
          columns: [], // 列
          filters: [], // 过滤
          sortBy: [],
        }; // 数据源参数;
      }
      const {
        rows, columns, filters, sortBy
      } = this.data.params;
      this.rows = rows;
      this.columns = columns;
      this.filters = filters;
      this.sortBy = sortBy;
      //
      this.rows.forEach((data) => {
        if (data.dmType === 'dimension') {
          this.dimensionsMap[data.column] = data.label;
        } else {
          this.metricsMap[data.label] = true;
          this.data.params.hasMetric = 'rows';
        }
      });
      this.columns.forEach((data) => {
        if (data.dmType === 'dimension') {
          this.dimensionsMap[data.column] = data.label;
        } else {
          this.metricsMap[data.label] = true;
          this.data.params.hasMetric = 'columns';
        }
      });
    },
    addSort() {
      const { length } = this.sortBy;
      if (length && !this.sortBy[length - 1].column) {
        this.$message.warning('有下拉项未选择');
        return;
      }
      this.sortBy.push({
        column: null,
        asc: true
      });
    },
    delSort(idx) {
      this.sortBy.splice(idx, 1);
    },
    xSet(data) { // 维度
      let valid = validX(this, data);
      if (valid) return;
      valid = validAll(this.data, this, 'dimensions');
      if (valid) return;
      //
      this.dimensionsMap[data.name] = data.label;
      this.dimensions.push({
        label: data.label,
        column: data.name,
        dataType: data.dataType, // icon string time等
        dmType: data.type, // 来自 "dimension" 维度 "metric" 度量,
      });
    },
    ySet(data) { // 度量
      const obj = {
        type: 'simple',
        column: data.name,
        dataType: data.dataType, // icon string time等
        dmType: data.type, // 来自 "dimension" 维度 "metric" 度量
        //
        formatType: 'number', // number 数值 percent 百分比,
        formatNum: 0, // 小数位
      };
      validY(this, obj, data, this.keyList);
      if (!obj.label) {
        this.$message({ type: 'warning', message: '同一属性计算方法已经添加满，无法再添加' });
        return;
      }
      //
      const valid = validAll(this.data, this, 'metrics');
      if (valid) return;
      this.metrics.push(obj);
    },
    wSet(data) { // 过滤
      // 自定义、绝对时间、相对时间 time
      // 自定义、条件、枚举 非time
      const aggregate = data.type === 'dimension' ? null : 'sum';
      const obj = {
        aggregate,
        label: ySetTypeMap[aggregate] + data.label,
        column: data.name,
        dataType: data.dataType, // icon string time integer double等
        dmType: data.type, // 来自 "dimensions" 维度 "metrics" 度量
        type: data.dataType === 'time' ? 'absolute' : 'condition', // 默认是条件类型
        logical: 'or', // and 且 or 或
        conditions: null,
        // conditions: [{
        //   operator: '=',
        //   value: data.dataType === 'time' ? new Date().toLocaleDateString() : 1
        // }], // {operator,value}
      };
      this.filters.push(obj);
    },
    rSet(data) { // 行
      const obj = {
        label: data.label,
        column: data.name,
        dataType: data.dataType, // icon string time等
        dmType: data.type, // 来自 "dimension" 维度 "metric" 度量,
      };
      const valid = validRowsC(this, data, obj, 'rows');
      if (valid) return;
      this.rows.push(obj);
    },
    cSet(data) { // 列
      const obj = {
        label: data.label,
        column: data.name,
        dataType: data.dataType, // icon string time等
        dmType: data.type, // 来自 "dimension" 维度 "metric" 度量,
      };
      const valid = validRowsC(this, data, obj, 'columns');
      if (valid) return;
      this.columns.push(obj);
    },
    drop(ev, type) {
      let strdata = ev.dataTransfer.getData('data');
      if (strdata) {
        strdata = JSON.parse(strdata);
        // 判断数据集是否已经发生改变
        this.$parent.validDataSet(strdata).then((res) => {
          if (res === 'clear') { // 清空
            this.dimensionsMap = {};
            this.metricsMap = {};
            this.dimensions.length = 0;
            this.metrics.length = 0;
            this.filters.length = 0;
            this.rows.length = 0;
            this.columns.length = 0;
          }
          //
          this[`${type}Set`](strdata);
        });
      } else if (this.tempDragData && this.tempDragData.Type !== type) { // 行列部分互换判断操作
        const { item, Type } = this.tempDragData;
        const {
          label, dataType, column, dmType
        } = item;
        //
        if (this.timeout) {
          clearTimeout(this.timeout);
          this.timeout = null;
        }
        this.timeout = setTimeout(() => {
          let idx = null;
          const list = Type === 'r' ? this.rows : this.columns;
          if (dmType === 'dimension') { // 如果是维度,删除原来区域的维度，新增现在区域的维度
            // 获取删除的index
            for (let i = 0, j = list.length; i < j; i += 1) {
              if (list[i].label === label) {
                idx = i;
                break;
              }
            }
            this.tableDel(list, idx, item);// 删除
            // 新增
            this[`${type}Set`]({
              label,
              dataType,
              name: column,
              type: dmType,
            });
          } else {
            const dataArray = [];
            let i = list.length;
            while (i) {
              i -= 1;
              if (list[i].dmType === 'metric') { // 度量
                dataArray.push(list[i]);
                this.tableDel(list, i, list[i]);// 删除
              }
            }
            //
            dataArray.forEach((obj) => {
              const Label = obj.label.split(' ')[1];
              // 新增
              this[`${type}Set`]({
                label: Label,
                dataType: obj.dataType,
                name: obj.column,
                type: obj.dmType,
              });
            });
          }
        }, 0);
      }
    },
    mousedown(item, idx, Type) {
      this.tempDragData = { item, idx, Type };
    },
    delType(list, index, type, obj) {
      if (type === 'x') {
        delete this.dimensionsMap[obj.column];
      } else if (type === 'y') {
        delete this.metricsMap[obj.label];
      }
      list.splice(index, 1);
    },
    tableDel(list, index, item) {
      if (item.dmType === 'dimension') { // 维度
        delete this.dimensionsMap[item.column];
      } else { // 度量
        delete this.metricsMap[item.label];
        if (Object.keys(this.metricsMap).length < 1) {
          this.data.params.hasMetric = null;
        }
      }
      list.splice(index, 1);
    },
    customType(tableMask) { // 自定义类型
      this.dialogVisible = true;
      this.dialogObj = {
        type: 'custom',
        label: null,
        expression: null,
        dataType: 'sql'
      };
      this.dialogType = 'y';
      this.tableMask = tableMask;
    },
    editDimension(item, idx, type, tableMask) {
      item.index = idx;
      this.dialogVisible = true;
      this.dialogObj = item;
      this.dialogType = type;
      this.tableMask = tableMask;
    },
    dialogSave(data) {
      if (this.dialogType === 'y') { // 度量操作
        const mask = this.data.type === 'Table' ? this.tableMask : 'metrics';
        const idx = data.index;
        delete data.index;
        const label = idx === undefined ? null : this[mask][idx].label;
        if (this.metricsMap[data.label] && data.label !== label) { // 重复
          this.$message({ type: 'warning', message: '添加或修改产生重复' });
          return;
        }
        if (idx === undefined) { // 新增
          this[mask].push(data);
        } else {
          delete this.metricsMap[this[mask][idx].label];
          this[mask].splice(idx, 1, data);
        }
        this.metricsMap[data.label] = true;
      } if (this.dialogType === 'w') { // 过滤
        const idx = data.index;
        delete data.index;
        const { label, aggregate } = data;
        const [a, b] = label.split(' ');
        data.label = ySetTypeMap[aggregate] + (b || a);
        this.filters.splice(idx, 1, data);
      }
    },
  }
};
</script>
<style scoped lang="less">
.chartXYW {
  flex: 1;
  display: flex;
  flex-direction: column;
  .rows {
    flex: 1;
    padding: 15px 0;
    border-bottom: 1px solid #3a4158;
    > span {
      font-size: 13px;
      font-weight: bolder;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      > div{
          font-size: 12px;
          cursor: pointer;
        > i {
          font-size: 14px;
          vertical-align: text-top;
          color: #61a9f8;
          margin-right: 3px;
        }
      }
    }
    > .parent {
      margin-top: 8px;
      display: flex;
      align-items: center;
      i {
        cursor: pointer;
        margin-left: 5px;
        &.el-icon-sort-up {
           margin-left: -8px;
        }
        &.el-icon-delete,&.active {
          color: #61a9f8;
        }
      }
    }
    ul {
      &.active {
        margin-top: 5px;
        padding: 0 5px;
        border: 1px dashed #907f7f;
        background: #000;
      }
      height: calc(100% - 16px);
      overflow: auto;
      list-style: none;
      margin: 0;
      padding: 0;
      .row-li {
        display: flex;
        align-items: center;
        margin: 10px 0;
        &.no {
          > .el-input {
            /deep/ .el-input__inner {
              border: 1px dashed #5a5757;
              padding: 0;
              text-align: center;
            }
          }
        }
        &:not(.no):hover {
            > .el-input {
              /deep/  .el-input__inner {
                padding-right: 34px;
              }
              /deep/  .el-input__suffix {
                .el-input__suffix-inner i {
                  display: inline-block;
                }
              }
            }
        }
        .el-input {
          /deep/  .el-input__inner {
            padding: 0 0 0 25px;
            cursor: move;
          }
          /deep/  .el-input__prefix {
            color: #61a9f8;
          }
          /deep/ .el-input__suffix {
            color: #61a9f8;
            .el-input__suffix-inner i {
              display: none;
              font-size: 13px;
              cursor: pointer;
              line-height: 30px;
              margin-left: 2px;
            }
          }
        }
      }
    }
  }
}
</style>
