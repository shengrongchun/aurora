<template>
  <div class="chart">
    <chartXYW
      :data="copyData"
      :showItem="showItem"/>
    <div class="utils">
      <span>行数</span>
      <el-input
        type="number"
        v-model="copyData.params.pageSize"
        :min="1"/>
    </div>
    <div class="btn-apply">
      <el-button
        @click="apply"
        type="primary"
      >更新</el-button>
    </div>
  </div>
</template>
<script>
import chartXYW from './chart';
import deepCopy from '../../../../utils/deepCopy';
import { applyValid } from './checkValid';

export default {
  components: {
    chartXYW,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      copyData: deepCopy(this.data),
    };
  },
  computed: {
    showItem() {
      if (this.data.type === 'Lou' || this.data.type === 'Label') {
        return ['y', 'w', 's'];
      }
      if (this.data.type === 'Select') {
        return ['x', 'w', 's'];
      }
      if (this.data.type === 'Table') {
        return ['r', 'c', 'w', 's'];
      }
      return ['x', 'y', 'w', 's'];
    }
  },
  methods: {
    validDataSet(data) {
      return new Promise((resolve) => {
        const { dataSetType, dataSetId } = this.copyData.params;
        if (dataSetType) {
          // 数据集改变了
          if (dataSetType !== data.dataSetType || dataSetId !== data.dataSetId) {
            this.$confirm('发现数据集已经改变,会清空之前的选项，是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              Object.assign(this.copyData.params, {
                dataSetId: data.dataSetId,
                dataSetType: data.dataSetType,
                dataSetName: data.dataSetName,
              });
              resolve('clear'); // 清理
            }).catch(() => {
            });
          } else {
            resolve();
          }
        } else { // 首次添加
          Object.assign(this.copyData.params, {
            dataSetId: data.dataSetId,
            dataSetType: data.dataSetType,
            dataSetName: data.dataSetName,
          });
          resolve();
        }
      });
    },
    setAxis() {
      if (this.data.styles.xAxis) { // 设置显示中坐标轴的值
        this.data.styles.xAxis[0].select = this.data.params.dimensions;
        if (this.data.type === 'Comb') { // 组合图
          const h = this.data.params.metrics.length;
          this.data.styles.yAxis[0].select = this.data.params.metrics.slice(0, h - 1);
          this.data.styles.yAxis[1].select = [this.data.params.metrics[h - 1]];
        } else {
          this.data.styles.yAxis[0].select = this.data.params.metrics;
          this.data.styles.yAxis[1].select = [];
        }
        // 设置标识 styles变化不重新设置样式，因为下面更新数据方法直接更新
        this.data.params.changeData = true;
      }
    },
    apply() { // 数据更新
      const valid = applyValid(this.copyData, this);
      if (valid) return;// 验证是否通过
      // 通过后，params参数设置为最新值
      this.data.params = deepCopy(this.copyData.params);
      //
      this.setAxis();
      // 更新数据
      this.$store._vm.$emit(`${this.data.i}update${this.$store.state.panel.preView}`, this.data);
    }
  }
};
</script>
<style scoped lang="less">
.chart {
  height: 100%;
  display: flex;
  flex-direction: column;
  .utils {
    height: 30px;
    line-height: 30px;
    display: flex;
    font-size: 13px;
    font-weight: bolder;
    > .el-input {
      margin-left: 5px;
      flex: 1;
      /deep/ .el-input__inner {
        line-height: 20px;
        height: 20px;
        padding: 0 2px;
      }
    }
  }
  .btn-apply {
    text-align: center;
    .el-button {
      width: 50%;
      padding: 6px;
    }
  }
}
</style>
