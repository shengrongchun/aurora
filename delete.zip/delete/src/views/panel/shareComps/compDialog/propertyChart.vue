<template>
  <div
    v-if="dataList.length>0"
    class="property-chart">
    <div v-if="dataList.length==1">
      <slot
        v-if="dataList[0][typeName]"
        :name="dataList[0][typeName]"
        :item="dataList[0]"
        :index="0"
        :length="dataList.length"/>
      <slot
        v-else
        :item="dataList[0]"
        :index="0"
        :length="dataList.length"/>
    </div>
    <div
      v-else
      :style="{'marginLeft':leftWidth}"
      class="property-list">
      <div
        v-for="(item,index) in dataList"
        :key="index"
        :style="{'marginBottom':(index === dataList.length-1)?0:gap+'px'}"
        class="list">
        <div
          v-if="index!=0"
          :style="upStyleObj"
          class="border-up">
          <el-button type="primary">{{ tag }}</el-button>
        </div>
        <slot
          :name="item[typeName] || 'default'"
          :item="item"
          :index="index"
          :length="dataList.length"/>
        <div
          v-if="index!=(dataList.length-1)"
          :style="downStyleObj"
          class="border-down"/>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PropertyChart',
  props: {
    typeName: {
      type: String,
      default: 'typeName'
    },
    gap: {
      type: Number,
      default: 16
    },
    tag: {
      type: String,
      default: '且'
    },
    color: {
      type: String,
      default: '#337ab7'
    },
    width: {
      type: String,
      default: '50px'
    },
    dataList: {
      type: Array,
      default() {
        return [];
      },
    }
  },
  data() {
    return {
      leftWidth: `calc(10px + ${this.width})`,
      styleObj: {
        borderColor: this.color,
        width: this.width,
        left: `-${this.width}`,
        height: `calc(50% + ${(this.gap / 2) - 2}px)`,
      },
    };
  },
  computed: {
    upStyleObj() {
      return Object.assign({}, this.styleObj, {
        top: `-${this.gap / 2}px`
      });
    },
    downStyleObj() {
      return Object.assign({}, this.styleObj, {
        top: 'calc(50% + 2px)'
      });
    },
  },
};
</script>
<style scoped lang="less">
.property-chart {
  .property-list {
    .list {
      position: relative;
      .border-up {
        position: absolute;
        border-width: 1px;
        border-style: solid;
        border-top: 0;
        border-right: 0;
        .el-button {
          position: absolute;
          padding: 4px;
          top: -11px;
          left: -11px;
        }
      }
      .border-down {
        position: absolute;
        border-width: 1px;
        border-style: solid;
        border-bottom: 0;
        border-right: 0;
      }
    }
  }
}
</style>
