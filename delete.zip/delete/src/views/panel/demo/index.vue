<template>
  <div
    class="panel"
    v-loading="loading">
    <!-- 编辑 预览 保存等功能头部部分 -->
    <div class="header">
      <div class="left">
        <el-page-header>
          <div
            slot="content"
            class="content">
            <i class="iconfont icon-yibiaopan" />
            <el-input
              v-model="form.compName"
              placeholder="未命名"/>
            <span style="margin-left:20px;font-size:13px;color: yellow">注：下面小图标组件可以拖动或者双击，容器中会新增各种类型组件。可以切换主题展示不同风格样式。可以切换（编辑/预览）模式。</span>
          </div>
        </el-page-header>

      </div>
      <div class="right">
        <template v-if="!$store.state.panel.preView">
          <span class="theme">主题</span>
          <el-select
            class="dark"
            v-model="$store.state.panel.theme"
            :popper-append-to-body="false"
          >
            <el-option
              value="default"
              label="默认" />
            <el-option
              value="dark"
              label="黑暗" />
          </el-select>
        </template>
        <el-radio-group
          v-model="$store.state.panel.preView"
          size="mini">
          <el-radio-button
            :label="false"
          >编辑</el-radio-button>
          <el-radio-button
            :label="true"
          >预览</el-radio-button>
        </el-radio-group>
      </div>
    </div>
    <!-- 极光配置主体部分 -->
    <Main :style="{'height': 'calc(100% - 40px)'}"/>
  </div>
</template>
<script>
import Main from '../main.vue';
import './mock';
import { dashboard } from '../../../api/panel';

export default {
  components: {
    Main,
  },
  data() {
    return {
      loading: false,
      form: {
        compName: null, // 仪表盘名称
      },
    };
  },
  created() {
    this.getData();
  },
  methods: {
    getData() {
      this.loading = true;
      dashboard(34).then((res) => {
        this.form.compName = res.name;
        const config = JSON.parse(res.config);
        this.$store.commit('setCompList', config);
      }).finally(() => {
        this.loading = false;
      });
    },
  }
};
</script>
<style scoped lang="less">
.panel {
  height: 100vh;
  .header {
    color: #eee;
    display: inline-flex;
    justify-content: space-between;
    width: 100%;
    background: rgb(5,21,37);
    padding: 0 10px;
    .left {
      .el-page-header {
        font-weight: bolder;
        height: 40px;
        line-height: 40px;
        .content {
          margin-top: -2px;
          .icon-yibiaopan {
            font-size: 15px;
            color: #eee;
            margin-right: 10px;
          }
          .el-input {
            width: 100px;
            /deep/ .el-input__inner {
              font-size: 15px;
              font-weight: bolder;
              color: #fff;
              background: rgb(5,21,37);
              border: none;
              padding-left: 3px;
            }
          }
        }
      }
    }
    .right {
      margin-right: 15px;
      height: 40px;
      line-height: 40px;
      > .span-btn {
        background: #333b54;
        padding: 4px 7px;
        line-height: 1;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        color: #fff;
        font-size: 12px;
        font-weight: bolder;
        margin-left: 20px;
      }
      > .el-select /deep/  .el-input {
        .el-input__inner {
          border: none;
          border-radius: 4px;
          font-weight: bolder;
          color: #fff;
          background: #282f46;
          line-height: 22px;
          height: 22px;
        }
      }
      > .el-radio-group {
        /deep/ .el-radio-button.is-active {
          .el-radio-button__inner {
            background: #555863;
            color: #fff;
          }
        }
        /deep/ .el-radio-button__inner {
          padding: 4px 7px;
          border: none;
          background: #333b54;
          color: #aaa;
          font-weight: bolder;
          box-shadow: none;
        }
      }
    }
    .theme {
      font-size: 13px;
      font-weight: bolder;
      color: #aaa;
    }
    /deep/ .el-select {
      width: 80px;
      margin: 0 20px 0 10px;
      .el-select__tags {
        max-width: 100%;
      }
      .el-select-dropdown {
        background: #282f46;
        border-color: #282f46;
        box-shadow: 0 2px 12px 0 #141721;
        .el-select-dropdown__item {
          color: #bbb;
          font-weight: bolder;
          &.hover {
            color: #bbb;
            background: #282f46;
          }
          &:hover,&.selected {
            color: #61a9f8;
            background: #282f46;
          }
        }
      }
      .popper__arrow {
        border-bottom-color: #282f46;
        &::after {
          border-bottom-color: #282f46;
        }
      }
    }
  }
}
</style>
