import Mock from 'mockjs';
import config from '@/env.config';

const API = config.SPACE_API;
// 延时400s请求到数据
Mock.setup({
  timeout: 400
});
// get 请求 获取面板信息
Mock.mock(`${API}/api/v1/dashboard/34`, 'get', {
  code: 0,
  message: null,
  data: {
    name: '报表名称',
    config: '{"compList":[{"i":1590851420515,"type":"Pie","x":8,"y":3,"h":19,"w":8,"styles":{"label":{"text":"城市失联单车（最大值）","subtext":null,"subText":"这里是描述信息"},"labelNormal":{"show":true,"position":"outside","formatter":"{b} : {c} ({d}%)"},"tooltip":{"confine":true,"trigger":"item","formatter":"{a} <br/>{b} : {c} ({d}%)"},"legend":{"show":true,"top":"top","type":"scroll","padding":[30,20,20,15],"data":[]},"series":[{"name":"饼图","type":"pie","radius":"75%","center":["45%","60%"],"top":60,"bottom":35,"data":[],"emphasis":{"itemStyle":{"shadowBlur":10,"shadowOffsetX":0,"shadowColor":"rgba(0, 0, 0, 0.5)"}}}]},"params":{"dataSetId":36,"dataSetType":"sql","dataSetName":"测试数据源mysql","pageSize":1000,"dimensions":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"metrics":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"max","label":"(最大值) 失联单车数","formatThousand":true}],"filters":[],"sortBy":[]},"moved":false},{"i":1590851146243,"type":"Bar","x":16,"y":3,"h":19,"w":8,"styles":{"lineParams":{"smooth":false,"stack":null,"areaStyle":null},"barParams":{"vertical":true,"stack":null},"labelNormal":{"show":true,"position":"top"},"label":{"text":"城市失联单车（平均值）","subtext":null,"subText":"这里是描述信息"},"tooltip":{"show":true,"confine":true,"trigger":"axis","axisPointer":{"type":"cross","label":{"backgroundColor":"#6a7985"}}},"legend":{"data":[],"show":true,"type":"scroll","top":"top","padding":[30,20,20,15]},"series":[],"xAxis":[{"type":"category","data":[],"select":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"splitLine":{"show":true},"axisLabel":{"show":true},"show":true,"name":null}],"yAxis":[{"type":"value","min":"dataMin","show":true,"name":null,"select":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"avg","label":"(平均值) 失联单车数","formatThousand":true}],"splitLine":{"show":true},"axisLabel":{"show":true}},{"type":"value","min":"dataMin","show":true,"name":null,"select":[],"splitLine":{"show":true},"axisLabel":{"show":true}}]},"params":{"dataSetId":36,"dataSetType":"sql","dataSetName":"测试数据源mysql","pageSize":1000,"dimensions":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"metrics":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"avg","label":"(平均值) 失联单车数","formatThousand":true}],"filters":[],"sortBy":[]},"moved":false},{"i":1588927690218,"type":"Comb","x":0,"y":22,"h":21,"w":24,"styles":{"lineParams":{"smooth":false,"stack":null,"areaStyle":null},"barParams":{"vertical":true,"stack":null},"labelNormal":{"show":true,"position":"top"},"label":{"text":"城市失联单车（求和/平均值）对比展示","subtext":null,"subText":"这里是描述信息"},"tooltip":{"show":true,"confine":true,"trigger":"axis","axisPointer":{"type":"cross","label":{"backgroundColor":"#6a7985"}}},"legend":{"data":[],"show":true,"type":"scroll","top":"top","padding":[30,20,20,15]},"series":[],"xAxis":[{"type":"category","data":[],"select":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"splitLine":{"show":true},"axisLabel":{"show":true},"show":true,"name":null}],"yAxis":[{"type":"value","show":true,"name":null,"select":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"sum","label":"(求和) 失联单车数","formatThousand":true}],"splitLine":{"show":true},"axisLabel":{"show":true}},{"type":"value","show":true,"name":null,"select":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"avg","label":"(平均值) 失联单车数","formatThousand":true}],"splitLine":{"show":true},"axisLabel":{"show":true}}]},"params":{"dataSetId":36,"dataSetType":"sql","dataSetName":"测试数据源mysql","pageSize":20,"dimensions":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"metrics":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"sum","label":"(求和) 失联单车数","formatThousand":true},{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"avg","label":"(平均值) 失联单车数","formatThousand":true}],"filters":[]},"moved":false},{"i":1588909207142,"type":"Line","x":0,"y":3,"h":19,"w":8,"styles":{"lineParams":{"smooth":false,"stack":null,"areaStyle":null},"barParams":{"vertical":true,"stack":null},"labelNormal":{"show":true,"position":"top"},"label":{"text":"城市失联单车（求和）","subtext":null,"subText":"这里是描述信息"},"tooltip":{"show":true,"confine":true,"trigger":"axis","axisPointer":{"type":"cross","label":{"backgroundColor":"#6a7985"}}},"legend":{"data":[],"show":true,"type":"scroll","top":"top","padding":[30,20,20,15]},"series":[],"xAxis":[{"type":"category","data":[],"select":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"splitLine":{"show":true},"axisLabel":{"show":true},"show":true,"name":null}],"yAxis":[{"type":"value","show":true,"name":null,"select":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"sum","label":"(求和) 失联单车数","formatThousand":true}],"splitLine":{"show":true},"axisLabel":{"show":true}},{"type":"value","show":true,"name":null,"select":[],"splitLine":{"show":true},"axisLabel":{"show":true}}]},"params":{"dataSetId":36,"dataSetType":"sql","dataSetName":"测试数据源mysql","pageSize":20,"dimensions":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"metrics":[{"type":"simple","column":"miss_bike_cnt","dataType":"integer","dmType":"metric","formatType":"number","formatNum":0,"aggregate":"sum","label":"(求和) 失联单车数","formatThousand":true}],"filters":[]},"moved":false},{"i":1590483004033,"type":"Search","x":0,"y":0,"h":3,"w":24,"styles":{"label":{"text":"搜索框1","subText":null},"compList":[{"i":1590483007650,"type":"Select","x":0,"y":0,"h":2,"w":6,"styles":{"label":{"text":"城市","subText":null},"value":"","multiple":false,"columnVal":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"},"columnName":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"},"map":{"1590851420515":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"},"1590851146243":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"},"1588927690218":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"},"1588909207142":{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}}},"params":{"dataSetId":36,"dataSetType":"sql","dataSetName":"测试数据源mysql","pageSize":1000,"dimensions":[{"label":"城市名称","column":"city_name","dataType":"string","dmType":"dimension"}],"metrics":[],"filters":[],"sortBy":[]},"moved":false}],"btnName":"查询"},"params":{},"moved":false}],"labelMap":{"城市失联单车（求和/平均值）对比展示":true,"搜索框1":true,"城市":true,"城市失联单车（平均值）":true,"城市失联单车（求和）":true,"城市失联单车（最大值）":true},"theme":"dark"}',
  }
});
// post 请求 获取数据源度量纬度
Mock.mock(`${API}/api/v1/column/queryOnline`, 'post', () => Mock.mock({
  code: 0,
  message: null,
  data: [{
    id: 256, dataSetId: 36, dataSetType: 'sql', name: 'city_name', label: '城市名称', dataType: 'string', type: 'dimension', origin: 'primitive', version: 7
  }, {
    id: 259, dataSetId: 36, dataSetType: 'sql', name: 'miss_bike_cnt', label: '失联单车数', dataType: 'integer', type: 'metric', origin: 'primitive', version: 7
  }]
}));
//
const num = 5000;
const allData = [
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '上海市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '北京市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '天津市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '南京市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '合肥市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '重庆市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '广州市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '深圳市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '滁州市',
  },
  {
    'AVG(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'COUNT_DISTINCT(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MAX(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'MIN(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    'SUM(miss_bike_cnt)': parseInt(Math.random() * num, 10),
    city_name: '杭州市',
  },
];
// 获取组件信息接口
const regUrl = /\/api\/v1\/chart\/queryChartData\//;
function getData(param) {
  const { extra, params } = JSON.parse(param.body);
  const {
    dimensions, metrics, rows, columns
  } = params;
  const array = rows ? (rows.concat(columns)) : dimensions.concat(metrics);
  //
  const { value, column } = (extra || [])[0] || {};
  const result = [];
  allData.forEach((item) => {
    if (!value || value.length === 0 || value.includes(item[column])) {
      const keyVal = {};
      array.forEach((obj) => {
        const label = obj.aggregate ? `${obj.aggregate.toUpperCase()}(${obj.column})` : obj.column;
        keyVal[label] = item[label];
      });
      //
      result.push(keyVal);
    }
  });
  return result;
}
function getColumns(param) {
  const { params } = JSON.parse(param.body);
  const {
    dimensions, metrics, rows, columns
  } = params;
  const array = rows ? (rows.concat(columns)) : dimensions.concat(metrics);
  //
  const result = [];
  array.forEach((item) => {
    const { label, column, aggregate } = item;
    const name = aggregate ? `${aggregate.toUpperCase()}(${column})` : column;
    result.push({
      label, name
    });
  });
  return result;
}
Mock.mock(regUrl, 'post', params => Mock.mock({
  code: 0,
  message: null,
  data: {
    query: 'SELECT city_name as "city_name", SUM(miss_bike_cnt) as "SUM(miss_bike_cnt)", MAX(miss_bike_cnt) as "MAX(miss_bike_cnt)", COUNT(miss_bike_cnt) as "COUNT(miss_bike_cnt)", COUNT(DISTINCT miss_bike_cnt) as "COUNT_DISTINCT(miss_bike_cnt)", MIN(miss_bike_cnt) as "MIN(miss_bike_cnt)", AVG(miss_bike_cnt) as "AVG(miss_bike_cnt)" FROM (select * from test_city limit 10) __expr GROUP BY 1 limit 20',
    result: getData(params),
    columns: getColumns(params)
  }
}));
