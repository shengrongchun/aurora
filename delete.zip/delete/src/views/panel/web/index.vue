<template>
  <div
    v-loading="loading"
    :class="['main', $store.state.panel.theme]">
    <drag-container :list="list"/>
  </div>
</template>
<script>
import dragContainer from '../dragComps/dragContainer';
import { dashboard } from '../../../api/panel';

export default {
  components: {
    dragContainer
  },
  props: {
    id: {
      type: [String, Number],
      default: null
    }
  },
  data() {
    return {
      loading: false,
      list: []
    };
  },
  created() {
    if (this.id) {
      this.$store.state.panel.preView = true;
      this.getData();
    }
  },
  methods: {
    getData() {
      this.loading = true;
      dashboard(this.id).then((res) => {
        const config = JSON.parse(res.config);
        this.list = config.compList || [];
        this.$store.state.panel.theme = config.theme || 'default';
      }).finally(() => {
        this.loading = false;
      });
    },
  }
};
</script>
<style scoped lang="less">
.main {
  width: 100%;
  height: 100%;
}
</style>
