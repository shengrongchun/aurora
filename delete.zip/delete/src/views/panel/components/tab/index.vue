<template>
  <div class="tabs">
    <el-tabs
      v-if="data.styles.tabList.length>0"
      :tab-position="data.styles.tabPosition"
      v-model="active">
      <el-tab-pane
        v-for="(tab,idx) in data.styles.tabList"
        :key="idx"
        :label="tab.title"
        :name="idx+''">
        <dragContainer
          :obj="data"
          :list="tab.compList"/>
      </el-tab-pane>
    </el-tabs>
    <div
      v-else
      class="no-data">
      请添加Tab标签
    </div>
    <slot />
  </div>
</template>
<script>
import dragContainer from '../../dragComps/dragContainer';

export default {
  name: 'TabComp', // 组件名称icon+Comp
  components: {
    dragContainer
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      active: '0'
    };
  }
};
</script>
<style scoped lang="less">
.tabs {
  padding-top: 25px;
  .no-data {
    text-align: center;
    position: absolute;
    top: calc(50% - 10px);
    left: calc(50% - 50px);
    font-size: 15px;
    color:#61a9f8;
  }
  .el-tabs {
    display: flex;
    flex-direction: column;
    height: 100%;
    margin: 0;
    &.el-tabs--right {
      flex-direction: row-reverse;
    }
    &.el-tabs--left {
      flex-direction: row;
    }
    /deep/ .el-tabs__header {
      margin: 0;
      padding-left: 10px;
    }
    /deep/ .el-tabs__content {
      flex: 1;
      .el-tab-pane {
        height: 100%;
      }
    }
  }
}
</style>
