import Vue from 'vue';
//
const contexts = require.context('./', true, /(index|config).vue$/);
contexts.keys().forEach((fileName) => {
  const comp = contexts(fileName).default;
  // 全局注册组件
  Vue.component(comp.name, comp);
});
