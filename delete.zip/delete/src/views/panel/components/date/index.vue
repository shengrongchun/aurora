<template>
  <div class="date">
    <span class="name">{{ data.styles.label.text }}</span>
    <el-date-picker
      v-model="data.styles.value"
      :type="data.styles.type"
      value-format="yyyy-MM-dd"
      format="yyyy-MM-dd"
      :picker-options="options"
      placeholder="选择日期"/>
    <slot />
  </div>
</template>
<script>

export default {
  name: 'DateComp',
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  watch: {// 这里的watch顺序很重要，先定义的先执行
    'data.styles.time': {
      handler() {
        this.init();
      },
      deep: true
    },
    'data.styles.map': {
      handler() {
        this.noMapWatch = true; // 禁止去重新设置styles.map标识
      },
      deep: true
    },
    '$store.state.panel.compList': {// 全局监听各个组件的变化 重新设置styles.map
      handler(list) {
        if (this.noMapWatch || !this.data.styles.columnVal) {
          delete this.noMapWatch;
          return;
        }
        this.setMap(list);
      },
      deep: true
    },
  },
  created() {
    this.noMapWatch = true;
    this.init();
    this.options = {
      shortcuts: [{
        text: '今天',
        onClick(picker) {
          picker.$emit('pick', new Date());
        }
      }, {
        text: '昨天',
        onClick(picker) {
          const date = new Date();
          date.setTime(date.getTime() - 3600 * 1000 * 24);
          picker.$emit('pick', date);
        }
      }, {
        text: '一周前',
        onClick(picker) {
          const date = new Date();
          date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
          picker.$emit('pick', date);
        }
      }, {
        text: '一个月前',
        onClick(picker) {
          const date = new Date();
          date.setTime(date.getTime() - 3600 * 1000 * 24 * 30);
          picker.$emit('pick', date);
        }
      }, {
        text: '半年前',
        onClick(picker) {
          const date = new Date();
          date.setTime(date.getTime() - 3600 * 1000 * 24 * 30 * 6);
          picker.$emit('pick', date);
        }
      }]
    };
  },
  methods: {
    init() {
      const { styles } = this.data;
      const { time } = styles;
      if (time.show) { // 定义了绝对时间
        let gapTime = 1000 * time.unit * time.value;
        const date = new Date();
        if (time.position === 'pre') {
          gapTime = date.getTime() - gapTime;
          styles.value = [this.formatDateTime(gapTime), this.formatDateTime()];
        } else {
          gapTime = date.getTime() + gapTime;
          styles.value = [this.formatDateTime(), this.formatDateTime(gapTime)];
        }
      }
    },
    formatDateTime(inputTime) {
      const date = inputTime ? new Date(inputTime) : new Date();
      const y = date.getFullYear();
      let m = date.getMonth() + 1;
      m = m < 10 ? (`0${m}`) : m;
      let d = date.getDate();
      d = d < 10 ? (`0${d}`) : d;
      return `${y}-${m}-${d}`;
    },
    // 设置map方法
    setMap(list) {
      //
      const diffList = [];// 非同源列表
      this.getDiffList(list, diffList);
      const map = {};
      //
      diffList.forEach((item) => { // 把所有非同源保留原来的选中
        const id = item.i;
        if (this.data.styles.map[id]) { // 有
          map[id] = this.data.styles.map[id];
        }
      });
      this.data.styles.map = map;
    },
    // 获取非同源列表
    getDiffList(list, diffList) { // 获取非同源列表
      list.forEach((item) => {
        if (item.type !== 'Search' && item.type !== 'Tab') {
          const { dataSetId, dataSetType } = item.params;
          if (dataSetId && dataSetType) {
            diffList.push(item);
          }
        } else if (item.type === 'Tab') {
          item.styles.tabList.forEach((tab) => {
            this.getDiffList(tab.compList || [], diffList);
          });
        }
      });
    },
  }
};
</script>
<style scoped lang="less">
.date {
  border: none !important;
  display: flex;
  align-items: center;
  background: transparent;
  .name {
    margin: 0 10px;
  }
  .el-input {
    flex: 1;
    margin-right: 10px;
  }
}
</style>
