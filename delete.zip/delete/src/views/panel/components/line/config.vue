<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="数据">
        <dataContainer :data="data">
          <chartContainer :data="data"/>
        </dataContainer>
      </el-tab-pane>
      <el-tab-pane label="显示">
        <showContainer :data="data"/>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';
import dataContainer from '../../shareComps/dataContainer';
import showContainer from '../../shareComps/showContainer';
import chartContainer from '../../shareComps/compDialog/chartContainer';


export default {
  name: 'LineConfig',
  components: {
    tabContainer,
    dataContainer,
    chartContainer,
    showContainer
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
}
</style>
