<template>
  <div class="config">
    <tabContainer
      :data="data">
      <el-tab-pane label="数据">
        <dataContainer :data="data">
          <chartContainer
            :data="data"/>
        </dataContainer>
      </el-tab-pane>
      <el-tab-pane label="显示">
        <el-form
          label-position="right"
          label-width="80px">
          <div class="title">基础信息</div>
          <el-form
            label-width="50px">
            <template>
              <el-form-item label="标题">
                <el-input
                  v-model.lazy="styles.label.text"
                  placeholder="请输入标题"/>
              </el-form-item>
              <el-form-item label="备注">
                <el-input
                  v-model="styles.label.subText"
                  placeholder="请输入备注"/>
              </el-form-item>
            </template>
          </el-form>
          <!-- <div class="title">图表样式</div>
          <el-form-item label="展示顺序">
            <draggable
              :list="copyData.params.metrics">
              <div
                class="list-item"
                v-for="(obj) in copyData.params.metrics"
                :key="obj.id">
                {{ obj.label }}
              </div>
            </draggable>
          </el-form-item> -->
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
// import draggable from 'vuedraggable';
import tabContainer from '../../shareComps/tabContainer';
import dataContainer from '../../shareComps/dataContainer';
import chartContainer from '../../shareComps/compDialog/chartContainer';

export default {
  name: 'LabelConfig',
  components: {
    tabContainer,
    dataContainer,
    chartContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles
    };
  },
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .el-form {
    /deep/ .title {
      font-size: 15px;
      font-weight: bolder;
      padding: 10px 0;
      margin-bottom: 10px;
      border-bottom: 1px solid #3a4158;
    }
    // .list-item {
    //   font-weight: bolder;
    //   font-size: 13px;
    //   color: #409EFF;
    // }
  }
  /deep/ .position {
    font-size: 13px;
    font-weight: bolder;
    margin: 0 10px;
    vertical-align: bottom;
  }
}
</style>
