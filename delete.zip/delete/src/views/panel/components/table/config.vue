<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="数据">
        <dataContainer :data="data">
          <chartContainer
            :data="data"/>
        </dataContainer>
      </el-tab-pane>
      <el-tab-pane label="显示">
        <el-form
          label-width="80px">
          <div class="title">基础信息</div>
          <template>
            <el-form-item label="标题">
              <el-input
                v-model="styles.label.text"
                placeholder="请输入标题"/>
            </el-form-item>
            <el-form-item label="备注">
              <el-input
                v-model="styles.label.subText"
                placeholder="请输入备注"/>
            </el-form-item>
          </template>
          <div class="title">图表样式</div>
          <el-form-item label="显示序号">
            <el-switch
              v-model="styles.indexNo"
              active-color="#409EFF"
              inactive-color="#eee"/>
          </el-form-item>
          <!-- <el-form-item label="显示分页">
            <el-switch
              v-model="styles.page"
              active-color="#409EFF"
              inactive-color="#eee"/>
          </el-form-item> -->
          <el-form-item label="对齐方式">
            <el-select
              v-model="styles.position"
              :style="{width:'88px'}"
              :popper-append-to-body="false">
              <el-option
                label="居中"
                value="center"/>
              <el-option
                label="左对齐"
                value="left"/>
              <el-option
                label="右对齐"
                value="right"/>
            </el-select>
          </el-form-item>
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';
import dataContainer from '../../shareComps/dataContainer';
import chartContainer from '../../shareComps/compDialog/chartContainer';

export default {
  name: 'TableConfig',
  components: {
    tabContainer,
    dataContainer,
    chartContainer
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles,
    };
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .title {
    font-size: 15px;
    font-weight: bolder;
    padding: 10px 0;
    margin-bottom: 10px;
    border-bottom: 1px solid #3a4158;
  }
}
</style>
