<template>
  <Chart
    :data="data"
    @apply="applyChart">
    <slot />
  </Chart>
</template>
<script>
import Chart from '../../shareComps/chartComIndex';
import { thousandsFmt } from '../../../../utils/index';

export default {
  name: 'LouComp',
  components: {
    Chart
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  methods: {
    applyChart({ res, chartData, myChart }) {
      this.exportData = res;
      const list = res.result;
      this.myChart = myChart;
      const { styles, params } = chartData;
      const { metrics } = params;
      const legendData = [];
      const data = [];
      let min = 0;
      let max = 0;
      metrics.forEach((obj) => {
        legendData.push(obj.label);
        const value = list[0][obj.aggregate ? `${obj.aggregate.toUpperCase()}(${obj.column})` : (obj.column || obj.expression)];
        min = value < min ? value : min;
        max = value > max ? value : max;
        data.push({
          name: obj.label,
          value,
        });
      });
      styles.tooltip.formatter = (param) => {
        const {
          seriesName, name, value, marker, percent
        } = param;
        const { formatThousand, formatType, formatNum } = chartData.params.metrics.find(
          item => item.label === name
        );
        let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
        formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
        formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
        //
        return `${seriesName}<br/>${marker + name}: ${formatVal} ${percent}%`;
      };
      styles.legend.data = legendData;
      styles.series[0].min = min;
      styles.series[0].max = max;
      styles.series[0].name = styles.label.text;
      styles.series[0].data = data;
      styles.series[0].label = Object.assign(styles.labelNormal, {
        formatter: (param) => {
          const { name, value, percent } = param;
          const { formatThousand, formatType, formatNum } = chartData.params.metrics.find(
            item => item.label === name
          );
          let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
          formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
          formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
          return `${name} ${formatVal} ${percent}%`;
        }
      });
      this.myChart.resize();
      this.myChart.setOption(styles, true);// false为合并之前的数据
    },
    resize() {
      if (this.myChart) {
        this.myChart.resize();
      }
    }
  }
};
</script>
