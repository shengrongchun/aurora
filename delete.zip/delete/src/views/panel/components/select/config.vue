<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="数据">
        <dataContainer :data="data">
          <chartContainer
            :data="data"/>
        </dataContainer>
      </el-tab-pane>
      <el-tab-pane label="显示">
        <el-form
          label-width="80px">
          <el-form-item label="">
            <el-radio-group
              v-model="styles.multiple">
              <el-radio
                :label="false">单选</el-radio>
              <el-radio
                :label="true">多选</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="标题">
            <el-input
              v-model="styles.label.text"
              placeholder="请输入标题"/>
          </el-form-item>
          <el-form-item label="名称属性">
            <el-select
              value-key="label"
              v-model="styles.columnName"
              :popper-append-to-body="false">
              <el-option
                :key="idx"
                :value="obj"
                :label="obj.label"
                v-for="(obj,idx) in list"/>
            </el-select>
          </el-form-item>
          <el-form-item label="传值属性">
            <el-select
              value-key="column"
              :disabled="columnValDisabled"
              v-model="styles.columnVal"
              :popper-append-to-body="false">
              <el-option
                :key="idx"
                :value="obj"
                :label="obj.label"
                v-for="(obj,idx) in list"/>
            </el-select>
          </el-form-item>
          <template>
            <ul class="axis">
              <li
                :class="{'active':indexType==='same'}"
                @click="indexType='same'">同源关联</li>
              <li
                :class="{'active':indexType==='diff'}"
                @click="indexType='diff'">非同源关联</li>
            </ul>
            <div class="axis-container">
              <div
                class="compSearch"
                :key="idx+indexType"
                v-for="(item,idx) in filterCompList">
                <el-checkbox
                  @change="checkedChange(item.i)"
                  :checked="styles.map[item.i]?true:false"
                >{{ item.styles.label.text }}</el-checkbox>
                <div
                  v-if="styles.map[item.i]!==undefined"
                  class="dataset-container">
                  <div class="dataset">
                    <i class="iconfont icon-shujuji"/>
                    <span>{{ item.params.dataSetName }}</span>
                  </div>
                  <div class="dataset sub">
                    <i
                      v-if="styles.map[item.i]"
                      :class="'iconfont icon-'+styles.map[item.i].dataType"/>
                    <el-select
                      v-model="styles.map[item.i]"
                      :popper-append-to-body="false"
                      placeholder="请选择映射属性"
                      value-key="label">
                      <el-option
                        :key="index"
                        :value="ob"
                        :label="ob.label"
                        v-for="(ob,index) in getList(item)"/>
                    </el-select>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';
import dataContainer from '../../shareComps/dataContainer';
import chartContainer from '../../shareComps/compDialog/chartContainer';

export default {
  name: 'SelectConfig',
  components: {
    tabContainer,
    dataContainer,
    chartContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles,
      indexType: 'same',
      columnValDisabled: false
    };
  },
  computed: {
    list() {
      const array = this.data.params.dimensions || [];
      [this.styles.columnName] = array;
      [this.styles.columnVal] = array;
      return array;
    },
    filterCompList() {
      const list = this.$store.state.panel.compList;
      const sameList = [];
      const diffList = [];
      this.getSameDiffList(list, sameList, diffList);
      //
      if (this.indexType === 'same') {
        return sameList;
      }
      return diffList;
    }
  },
  watch: {
    'styles.columnName': {
      handler(val) {
        if (val && val.dmType === 'metric') {
          this.styles.columnVal = val;
          this.columnValDisabled = true;
          this.styles.multiple = false;
        } else {
          this.columnValDisabled = false;
        }
      },
    }
  },
  methods: {
    // 选中，不选中map的设置
    checkedChange(i) {
      if (this.styles.map[i] === undefined) {
        this.$set(this.styles.map, i, null);
      } else {
        this.$set(this.styles.map, i, undefined);
        delete this.styles.map[i];
      }
    },
    // 每个组件的映射列表的获取
    getList(item) {
      if (item.params.rows) {
        return item.params.rows.concat(item.params.columns);
      }
      if (item.params.dimensions) {
        return item.params.dimensions.concat(item.params.metrics);
      }
      return [];
    },
    // 获取同源非同源列表
    getSameDiffList(list, sameList, diffList) { // 获取同源非同源列表
      list.forEach((item) => {
        if (item.type !== 'Search' && item.type !== 'Tab') {
          const { dataSetId, dataSetType } = item.params;
          if (dataSetId && dataSetType && this.data.params.dataSetId
          && this.data.params.dataSetType) {
            if (dataSetId === this.data.params.dataSetId
            && dataSetType === this.data.params.dataSetType) { // 同源
              sameList.push(item);
            } else {
              diffList.push(item);
            }
          }
        } else if (item.type === 'Tab') {
          item.styles.tabList.forEach((tab) => {
            this.getSameDiffList(tab.compList || [], sameList, diffList);
          });
        }
      });
    },
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .axis {
    margin: 7px 0 0 0;
    padding: 0;
    list-style: none;
    width: 100%;
    border: 1px solid #3a4158;
    display: flex;
    > li {
      &.active {
        color: #409EFF;
      }
      cursor: pointer;
      font-size: 13px;
      padding: 2px 0;
      text-align: center;
      flex: 1;
      display: inline-block;
      &:not(:last-child) {
        border-right: 1px solid #3a4158;
      }
    }
  }
  .axis-container {
    padding: 12px 0;
    .compSearch {
      margin-bottom: 15px;
      .el-checkbox {
        color: #eee;
      }
      .dataset-container {
        padding: 10px 0 0 30px;
      }
      .dataset {
        font-size: 14px;
        font-weight: bolder;
        margin-bottom: 10px;
        &.sub {
          margin-left: 20px;
        }
        .el-select {
          width: 150px;
        }
        i {
          color: #61a9f8;
          margin-right: 5px;
        }
      }
    }
  }
}
</style>
