<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="显示">
        <el-form label-width="80px">
          <el-form-item label="按钮名称">
            <el-input
              v-model="data.styles.btnName"
              placeholder="请输入按钮名称"/>
          </el-form-item>
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';

export default {
  name: 'SearchConfig',
  components: {
    tabContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
}
</style>
