<template>
  <div class="compSelect">
    <el-button
      v-if="data.styles.compList.length>0"
      type="primary"
      @click="search">{{ data.styles.btnName }}</el-button>
    <dragContainer
      :obj="data"
      :list="data.styles.compList"/>
    <slot />
  </div>
</template>
<script>
import dragContainer from '../../dragComps/dragContainer';

export default {
  name: 'SearchComp', // 组件名称icon+Comp
  components: {
    dragContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  created() {
    this.search();
  },
  methods: {
    search() { // 对映射的组件发送请求
      const { compList } = this.data.styles;
      const mapList = [];
      compList.forEach((item) => {
        mapList.push({
          value: item.styles.value,
          map: item.styles.map,
          type: item.type
        });
      });
      const emitObj = {};
      mapList.forEach((obj) => {
        const { map, value, type } = obj;
        const keyList = Object.keys(map);
        for (let i = 0, j = keyList.length; i < j; i += 1) {
          const key = keyList[i];
          if (!map[key]) {
            // eslint-disable-next-line no-continue
            continue;
          }
          if (!emitObj[key]) {
            emitObj[key] = [];
          }
          //
          const { column, aggregate, expression } = map[key];
          const setColumn = aggregate ? `${aggregate.toUpperCase()}(${column})` : (column || expression);
          if (value && value !== '') {
            if (type === 'Date') {
              emitObj[key].push({
                column: setColumn,
                value: value[0],
                operator: '>=',
              });
              emitObj[key].push({
                column: setColumn,
                value: value[1],
                operator: '<',
              });
            } else {
              emitObj[key].push({
                column: setColumn,
                value,
                operator: value instanceof Array ? 'in' : '=',
              });
            }
          }
        }
      });
      const { preView } = this.$store.state.panel;
      Object.keys(emitObj).forEach((id) => {
        this.$store._vm.$emit(`${id}search${preView}`, emitObj[id]);
      });
    },
  }
};
</script>
<style scoped lang="less">
.compSelect {
  .el-button {
    z-index: 1;
    position: absolute;
    left: calc(100% - 80px);
    top: calc(50% - 14px);
  }
}
</style>
