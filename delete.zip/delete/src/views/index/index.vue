<template>
  <div
    class="welcome"
    @click="push">welcome aurora</div>
</template>
<script>
export default {
  methods: {
    push() {
      // this.$router.push({
      //   name: 'createSpaceIndex',
      //   params: {
      //     breadList: JSON.stringify([{ name: '直租测试' }]),
      //     projectId: 22,
      //     parentId: -1
      //   }
      // });
    },
  }
};
</script>
<style scoped lang="less">
.welcome {
  display: inline-block;
  height: 100%;
  width: 100%;
  text-align: center;
  padding-top: 20%;
  font-size: 30px;
  font-size: bolder;
  font-family: Zapfino, Arial, Verdana, Sans-serif;
}
</style>
