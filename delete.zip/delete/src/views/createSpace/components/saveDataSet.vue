<template>
  <el-dialog
    :style="{'opacity':dialogVisible?0:1}"
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    title="保存数据集"
    width="460px">
    <Dialog
      v-if="dialogVisible"
      :visible="dialogVisible"
      :obj="dialogObj"
      type="online"
      @close="dialogVisible=false;goBackList()"/>
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="70px">
      <el-form-item
        label="名称"
        prop="name">
        <el-input
          v-model="form.name"
          :maxlength="20"
          :show-word-limit="true"
          placeholder="请输入名称，最多20个字符"
          style="width: 300px;"/>
      </el-form-item>
      <el-form-item
        label="描述"
        prop="description">
        <el-input
          v-model="form.description"
          type="textarea"
          placeholder="请输入描述信息"
          style="width: 300px;"/>
      </el-form-item>
      <el-form-item
        label="项目">
        {{ breadList[0] ? breadList[0].name: '无' }}
      </el-form-item>
      <el-form-item
        label="文件夹">
        {{ dirName }}
      </el-form-item>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button
        type="primary"
        @click="save">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import {
  saveData,
  savePaiData
} from 'src/api/space.js';

import Dialog from './tipDialog';

export default {
  components: {
    Dialog
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    params: {
      type: Object,
      default() {
        return {};
      }
    },
    breadList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      dialogVisible: false,
      dialogObj: {},
      form: {
        name: this.params.name, // 文件夹名称，或者数据集名称
        description: this.params.description, // 描述
      }
    };
  },
  computed: {
    dirName() {
      const list = this.breadList.slice(1, this.breadList.length);
      let str = list.length === 0 ? '无' : '';
      list.forEach((obj) => {
        str += `/${obj.name}`;
      });
      return str;
    }
  },
  created() {
    this.rules = {
      name: [
        { required: true, message: '请输入名称', trigger: 'blur' },
      ],
      description: [
        { required: true, message: '请输入描述', trigger: 'blur' },
      ]
    };
  },
  methods: {
    getParams() {
      return {
        dataSet: {
          id: this.params.id,
          projectId: this.params.projectId,
          directoryId: `${this.params.directoryId}` === `${this.params.projectId}` ? -1 : this.params.directoryId,
          dataSourceId: this.params.dataSourceObj.id,
          dataSourceType: this.params.dataSourceObj.type,
          name: this.form.name,
          description: this.form.description,
          esIndex: this.params.esIndex,
          esType: this.params.esType,
          baseSql: this.params.baseSql
        },
        columns: this.params.columns
      };
    },
    goBackList() {
      let parentId = this.params.directoryId;
      let { projectId } = this.params;
      if (this.breadList.length > 1) {
        parentId = this.breadList[this.breadList.length - 1].id;
        projectId = this.breadList[0].i;
      }
      this.$router.push({
        name: 'createSpaceIndex',
        params: {
          parentId,
          projectId,
          breadList: JSON.stringify(this.breadList.slice(0, this.breadList.length))
        }
      });
    },
    save() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.params.paiConfig) { // 资产数据集保存
            Object.assign(this.params, this.form);
            savePaiData(this.params).then((res) => {
              this.$message({ type: 'success', message: '保存成功' });
              this.dialogObj = {
                dataSetId: res.dataSetId,
                dataSetType: res.dataSetType,
                dataSourceType: res.dataSourceType,
                name: this.form.name
              };
              this.dialogVisible = true;
            });
            return true;
          }
          const params = this.getParams();
          saveData(params).then((res) => {
            this.$message({ type: 'success', message: '保存成功' });
            this.dialogObj = {
              dataSetId: res.dataSetId,
              dataSetType: res.dataSetType,
              dataSourceType: res.dataSourceType,
              name: this.form.name
            };
            this.dialogVisible = true;
          });
          return true;
        }
        return false;
      });
    }
  }
};
</script>
