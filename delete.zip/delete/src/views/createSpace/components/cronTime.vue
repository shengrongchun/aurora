<template>
  <div class="cron-time">
    <span>每</span>
    <div>
      <el-select
        v-model="form.range"
        placeholder="请选择"
        @change="changeRange">
        <el-option
          v-for="item in cycleList"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </div>
    <div
      v-if="form.range !== 'hour' && form.range !== 'day'">
      <el-select
        v-model="form.selectTime"
        placeholder="请选择"
        @change="changeRange">
        <el-option
          v-for="item in selectTimeList"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </div>
    <div
      v-if="form.range !== 'hour'">
      <el-select
        v-model="form.hour"
        placeholder="请选择"
        @change="changeRange">
        <el-option
          v-for="item in hourList"
          :key="item"
          :label="item"
          :value="item+''"/>
      </el-select>
    </div>
    <div v-if="form.range !== 'hour'">时</div>
    <div>
      <el-select
        v-model="form.minute"
        placeholder="请选择"
        @change="changeRange">
        <el-option
          v-for="item in minuteList"
          :key="item"
          :label="item"
          :value="item+''"/>
      </el-select>
    </div>
    <div>分</div>
  </div>
</template>
<script>
import options from './options';

export default {
  props: {
    value: {
      type: String,
      default: null,
    }
  },
  data() {
    return {
      form: {
        range: null, // 日期类型 日 周 月 小时
        selectTime: null, // 周（1-7）或者是日（1-31）
        hour: null, // 小时
        minute: null, // 分钟
      }
    };
  },
  computed: {
    selectTimeList() {
      if (this.form.range === 'week') {
        return options.selectWeekList;
      }
      if (this.form.range === 'month') {
        return options.selectMonthList;
      }
      return [];
    }
  },
  watch: {
    value() {
      this.transCycle();// 翻译
    }
  },
  created() {
    this.cycleList = options.cycleList;
    this.hourList = options.hourList;
    this.minuteList = options.minuteList;
    this.transCycle();// 翻译
  },
  methods: {
    changeRange() {
      const val = [];
      const {
        range,
        selectTime,
        hour,
        minute
      } = this.form;
      val.push('0'); // 秒
      if (range === 'day') {
        if (minute && hour) {
          val.push(minute); // 分
          val.push(hour); // 时
          val.push('*'); // 日
          val.push('*'); // 月
          val.push('?');
        }
      } else if (range === 'hour') {
        if (minute) {
          val.push(minute); // 分
          val.push('*'); // 时
          val.push('*'); // 日
          val.push('*'); // 月
          val.push('?');
        }
      } else if (range === 'week') {
        if (minute && hour && selectTime) {
          val.push(minute); // 分
          val.push(hour); // 时
          val.push('?');// 日
          val.push('*');// 月
          val.push(selectTime);// 周
        }
      } else if (range === 'month') {
        if (minute && hour && selectTime) {
          val.push(minute); // 分
          val.push(hour); // 时
          val.push(selectTime);// 日
          val.push('*');// 月
          val.push('?');// 周
        }
      }
      this.$emit('input', val.length === 1 ? null : val.join(' '));// v-model
    },
    transCycle() {
      if (!this.value) return;
      // 翻译cron为form字段
      const [, minute, hour, day, , week] = this.value.split(' ');
      if (week !== '?') {
        this.form.range = 'week';
        this.form.hour = hour;
        this.form.minute = minute;
        this.form.selectTime = +week;
      } else if (day !== '*') {
        this.form.range = 'month';
        this.form.hour = hour;
        this.form.minute = minute;
        this.form.selectTime = +day;// 转成数字类型
      } else if (hour === '*') {
        this.form.range = 'hour';
        this.form.minute = minute;
      } else {
        this.form.range = 'day';
        this.form.hour = hour;
        this.form.minute = minute;
      }
    },
  }
};
</script>
<style scoped lang="less">
.cron-time {
  display: flex;
  > div {
    margin: 0 5px;
  }
}
</style>
