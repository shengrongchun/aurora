const cycleList = [{
  label: '月',
  value: 'month'
}, {
  label: '周',
  value: 'week'
}, {
  label: '日',
  value: 'day'
}, {
  label: '小时',
  value: 'hour'
}];
// 1-7
const selectWeekList = [{
  label: '星期一',
  value: 2
}, {
  label: '星期二',
  value: 3
}, {
  label: '星期三',
  value: 4
}, {
  label: '星期四',
  value: 5
}, {
  label: '星期五',
  value: 6
}, {
  label: '星期六',
  value: 7
}, {
  label: '星期日',
  value: 1
}];

// 1-31
const selectMonthList = Array(31).fill(1).map((v, i) => ({
  value: i + 1,
  label: `${i + 1}号`
}));
// 0-23
const hourList = [...Array(24).keys()];
// 0-59
const minuteList = [...Array(60).keys()].filter(v => v % 5 === 0);
//
export default {
  cycleList, selectWeekList, selectMonthList, hourList, minuteList
};
