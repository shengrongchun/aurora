<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    :title="type==='dataset'?'':title"
    :class="{'no-padding':type==='dataset'}"
    :width="type==='directory'?'460px':'582px'">
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="100px">
      <template v-if="type==='directory'">
        <el-form-item
          label="文件夹名称"
          prop="name">
          <el-input
            v-model="form.name"
            :maxlength="20"
            :show-word-limit="true"
            placeholder="请输入文件夹名称，最多20个字符"
            style="width: 300px;"/>
        </el-form-item>
      </template>
      <template v-if="type==='dataset'">
        <el-tabs value="first">
          <el-tab-pane
            label="自定义"
            name="first">
            <div class="icon-list">
              <i
                class="iconfont icon-presto"
                @click="save('presto')"/>
              <i
                class="iconfont icon-Fill"
                @click="save('postgresql')"/>
              <i
                class="iconfont icon-shujukuleixingtubiao-kuozhan-"
                @click="save('mysql')"/>
              <i
                class="no-margin iconfont icon-ES"
                @click="save('es')"/>
                <!-- <i
                class="iconfont icon-fuzhi"
                @click="save('copy')"/> -->
            </div>
          </el-tab-pane>
          <el-tab-pane
            label="资产管理"
            name="second">
            <div class="icon-list">
              <i
                class="iconfont icon-shujuzichan"
                @click="save('asset')"/>
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>
    </el-form>
    <span
      v-if="type==='directory'"
      slot="footer"
      class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button
        type="primary"
        @click="save">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import {
  createDir, getProjectList, getTreeDirList
} from 'src/api/space.js';

export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: null
    },
    dir: {
      type: Object,
      default() {
        return {};
      }
    },
    breadList: {
      type: Array,
      default() {
        return [];
      }
    },
    projectId: {
      type: [String, Number],
      default: null
    },
    parentId: {
      type: [String, Number],
      default: null
    }
  },
  data() {
    return {
      innerVisible: false,
      form: {
        name: this.dir.name, // 文件夹名称
      },
      projectList: [],
      dirList: [],
      subForm: {
        projectId: null,
        directoryId: null
      }
    };
  },
  computed: {
    title() {
      if (this.type === 'directory') { // 新建文件夹
        return this.dir.name ? '编辑文件夹' : '新建文件夹';
      } if (this.type === 'dataset') {
        return '新建数据集';
      } if (this.type === 'dashboard') {
        return '新建仪表盘';
      }
      return '';
    }
  },
  created() {
    this.rules = {
      name: [
        { required: true, message: '请输入名称', trigger: 'blur' },
      ],
      directoryId: [
        { required: true, message: '请选择文件夹', trigger: 'blur' },
      ]
    };
  },
  methods: {
    getParams() {
      if (this.type === 'directory') {
        const parentId = `${this.projectId}` === `${this.parentId}` ? -1 : this.parentId;
        if (this.dir.name) {
          return {
            name: this.form.name,
            id: this.dir.id,
            parentId
          };
        }
        return {
          name: this.form.name,
          projectId: this.projectId,
          parentId
        };
      }
      return {};
    },
    save(Dtype) {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.type === 'directory') { // 新建文件夹
            createDir(this.getParams()).then(() => {
              this.$emit('close');
              this.$emit('success');
            });
          } else if (this.type === 'dataset') { // 新建数据集
            if (Dtype === 'copy') { // 复制
              this.innerVisible = true;
              this.getProjectList();
            } else if (Dtype === 'es') { // es
              this.$router.push({
                name: 'createSpaceES',
                params: {
                  type: Dtype,
                  parentId: this.parentId,
                  projectId: this.projectId,
                  breadList: this.breadList,
                }
              });
            } else if (Dtype === 'asset') { // 资产
              this.$router.push({
                name: 'createSpaceAsset',
                params: {
                  type: Dtype,
                  parentId: this.parentId,
                  projectId: this.projectId,
                  breadList: this.breadList,
                }
              });
            } else if (Dtype !== 'asset') { // sql类
              this.$router.push({
                name: 'createSpaceSQL',
                params: {
                  type: Dtype,
                  parentId: this.parentId,
                  projectId: this.projectId,
                  breadList: this.breadList,
                }
              });
            }
          }
          return true;
        }
        return false;
      });
    },
    subSave() {
      this.$refs.subform.validate((valid) => {
        if (valid) {
          // 这里调复制接口
          this.$emit('close');
          this.$emit('success');
          return true;
        }
        return false;
      });
    },
    getProjectList() { // 获取项目列表
      getProjectList().then((res) => {
        this.projectList = res;
      });
    },
    getDirlist(projectId) { // 获取文件夹列表
      getTreeDirList({ projectId }).then((res) => {
        this.dirList = res;
      });
    },
  }
};
</script>
<style scoped lang="less">
.el-form {
  .el-tabs {
    .icon-list {
      > i {
        display: inline-block;
        &.no-margin {
          margin-right: 0;
        }
        margin-right: 10px;
        margin-bottom: 10px;
        vertical-align: top;
        &:hover {
          background: #eee;
        }
        cursor: pointer;
        text-align: center;
        width: 128px;
        height: 128px;
        line-height: 128px;
        font-size: 60px;
        background: #f5f8fb;
        &.icon-presto {
          color: rgb(51,63,127);
        }
        &.icon-Fill {
          color: rgb(51,63,127);
        }
        &.icon-shujukuleixingtubiao-kuozhan- {
          color: rgb(76,151,212);
        }
        &.icon-fuzhi {
          color: rgb(244,189,177);
        }
        &.icon-fuzhi:after {
          content: '从其它项目复制';
          margin-top: -80px;
          display: block;
          font-size: 14px;
          font-weight: bolder;
        }
        &.icon-shujuzichan:after {
          content: '资产管理数据集';
          margin-top: -80px;
          display: block;
          font-size: 14px;
          font-weight: bolder;
        }
      }
    }
  }
}
.no-padding {
  /deep/ .el-dialog__body {
    padding: 0 20px 20px !important;
  }
}
</style>
