<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    :title="title"
    :width="data.mask==='copy'?'480px':'580px'">
    <template v-if="data.mask==='list'">
      <Grid
        style="height:400px;margin-top: -30px;"
        :tableAttrs="{border: false}"
        :paginationAttrs="{
          total: total,
          pageSize: listForm.pageSize,
          currentPage: listForm.pageNo
        }"
        @size-change="(val)=> {listForm.pageSize=val;refreshLogs()}"
        @current-change="(val)=> {listForm.pageNo=val;refreshLogs()}"
        :data="tableList">
        <el-table-column
          prop="createTime"
          label="刷新时间"
          show-overflow-tooltip
          header-align="center"
          align="center"/>
        <el-table-column
          prop="state"
          label="刷新状态"
          header-align="center"
          align="center">
          <template slot-scope="scope">
            <el-tag
              v-if="scope.row.state==='PENDING'"
              type="info">{{ scope.row.state }}</el-tag>
            <el-tag
              v-else-if="scope.row.state==='RUNNING'"
              >{{ scope.row.state }}</el-tag>
            <el-tag
              v-else-if="scope.row.state==='FINISHED'"
              type="success">{{ scope.row.state }}</el-tag>
            <el-tag
              v-else
              type="danger">{{ scope.row.state }}</el-tag>
          </template>
        </el-table-column>
      </Grid>
    </template>
    <template v-else>
      <el-form
        ref="form"
        :model="form"
        :rules="rules"
        label-width="100px">
        <template v-if="data.mask==='info'">
          <el-form-item
            label="名称"
            prop="name">
            <el-input
              v-model="form.name"
              :maxlength="20"
              :show-word-limit="true"
              placeholder="请输入文件夹名称，最多20个字符"
              style="width: 400px;"/>
          </el-form-item>
          <el-form-item
            label="描述"
            prop="description">
            <el-input
              v-model="form.description"
              type="textarea"
              style="width: 400px;"
              placeholder="请输入描述"/>
          </el-form-item>
          <el-form-item
            label="项目">
            {{ form.breadList[0].name }}
          </el-form-item>
          <el-form-item
            label="文件夹">
            {{ dirName }}
          </el-form-item>
        </template>
        <template v-if="data.mask==='copy'">
          <el-form-item
            label="项目"
            prop="projectId">
            <el-select
              v-model="form.projectId"
              style="width: 300px;"
              @change="getDirlist(form.projectId)">
              <el-option
                v-for="obj in projectList"
                :key="obj.id"
                :value="obj.id"
                :label="obj.name"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="文件夹"
            prop="directoryId">
            <el-cascader
              :show-all-levels="false"
              v-model="form.directoryId"
              :options="dirList"
              :props="{ checkStrictly: false,expandTrigger: 'hover' }"
              style="width: 300px;"
              clearable/>
          </el-form-item>
        </template>
      </el-form>
      <span
        slot="footer"
        class="dialog-footer">
        <el-button @click="$emit('close')">取消</el-button>
        <el-button
          type="primary"
          @click="save">保存</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script>
import { Grid } from '@hb/bi-ui';
import {
  copyData, getProjectList, getTreeDirList,
  editDataSetBaseInfo, refreshLogs
} from 'src/api/space.js';

export default {
  components: {
    Grid
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default() {
        return {};
      }
    },
  },
  data() {
    return {
      projectList: [], // 项目列表
      dirList: [], // 文件夹列表
      form: {
        name: null, // 文件夹名称，或者数据集名称
        description: null, // 描述
        projectId: null, // 要复制的目标项目ID
        directoryId: null, // 要复制的目标文件夹ID
      },
      listForm: {
        dataSetId: this.data.dataSetId,
        dataSetType: this.data.dataSetType,
        pageNo: 1,
        pageSize: 10
      },
      total: 0,
      tableList: []
    };
  },
  computed: {
    title() {
      if (this.data.mask === 'info') { // 新建文件夹
        return '基本信息';
      }
      if (this.data.mask === 'copy') { // 复制
        return '复制至';
      }
      if (this.data.mask === 'list') { // 刷新列表
        return '刷新列表';
      }
      return '';
    },
    dirName() {
      const list = this.form.breadList.slice(1, this.form.breadList.length);
      let str = list.length === 0 ? '无' : '';
      list.forEach((obj) => {
        str += `/${obj.name}`;
      });
      return str;
    }
  },
  created() {
    this.rules = {
      name: [
        { required: true, message: '请输入名称', trigger: 'blur' },
      ],
      description: [
        { required: true, message: '请输入描述', trigger: 'blur' },
      ],
      directoryId: [
        { required: true, message: '请选择文件夹', trigger: 'blur' },
      ],
      projectId: [
        { required: true, message: '请选择项目', trigger: 'blur' },
      ]
    };
    Object.assign(this.form, this.data);
    if (this.data.mask === 'copy') { // 数据集
      this.getProjectList();
    }
    if (this.data.mask === 'list') { // 获取数据刷新列表
      this.refreshLogs();
    }
  },
  methods: {
    refreshLogs() {
      refreshLogs(this.listForm).then((res) => {
        this.tableList = res.list;
        this.total = res.total;
      });
    },
    getProjectList() { // 获取项目列表
      getProjectList().then((res) => {
        this.projectList = res;
      });
    },
    getDirlist(projectId) { // 获取文件夹列表
      getTreeDirList({ projectId }).then((res) => {
        this.dirList = res;
        this.dirList.unshift({ value: -1, label: '根目录', children: null });
      });
    },
    getParams() {
      if (this.data.mask === 'copy') {
        return {
          dataSetId: this.form.dataSetId,
          dataSetType: this.form.dataSetType,
          projectId: this.form.projectId,
          directoryId: this.form.directoryId[this.form.directoryId.length - 1]
        };
      }
      if (this.data.mask === 'info') {
        return {
          id: this.data.id,
          type: this.data.type,
          name: this.form.name,
          description: this.form.description,
        };
      }
      return {};
    },
    save() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.data.mask === 'copy') { // 复制
            copyData(this.getParams()).then(() => {
              this.$message.success('复制成功');
              this.$emit('close');
              this.$emit('success');
            });
          } else if (this.data.mask === 'info') { // 基本信息保存
            editDataSetBaseInfo(this.getParams()).then(() => {
              this.$message.success('修改成功');
              this.$emit('close');
              this.$emit('success');
            });
          }
          return true;
        }
        return false;
      });
    }
  }
};
</script>
