<template>
  <div
    v-if="mainCom"
    class="main-container">
    <Breadcrumb
      :bread-list="breadList"
      @breadClick="breadClick">
      <el-input
        v-model="name"
        prefix-icon="el-icon-search"
        placeholder="请模糊搜索"
        @change="getProjectAll"/>
      &nbsp;&nbsp;
      <el-button
        type="primary"
        plain
        @click="dialogType='directory';dialogVisible=true;dir={}">新建文件夹</el-button>
      <el-button
        type="primary"
        @click="dialogType='dataset';dialogVisible=true">新建数据集</el-button>
      <el-button
        @click="clickPanel()">新建仪表盘</el-button>
    </Breadcrumb>
    <Grid
      :tableAttrs="{border: false}"
      v-if="mask===1"
      :pagination-attrs="{
        total
      }"
      :data="dataList"
      @prev-click="(v)=> {pageNo=v;getProjectAll(1)}"
      @next-click="(v)=> {pageNo=v;getProjectAll(1)}"
      @current-change="(v)=> {pageNo=v;getProjectAll(1)}"
      @size-change="(v)=> {pageSize=v;getProjectAll(1)}">
      <template
        v-for="item in tableList"
      >
        <template v-if="item.prop==='type'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <i
                v-if="scope.row.type==='directory'"
                class="iconfont icon-wenjianjia"/>
              <i
                v-else-if="scope.row.type==='dashboard'"
                class="iconfont icon-yibiaopan"/>
              <i
                v-else
                class="iconfont icon-shujuji"/>
            </template>
          </el-table-column>
        </template>
        <template v-else-if="item.prop==='onlineVersion'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-tag v-if="scope.row.type==='directory'">无</el-tag>
              <el-tag
                v-else
                :type="scope.row.onlineVersion>0?'success':'danger'">
                {{ scope.row.onlineVersion>0?'上线':'未上线' }}</el-tag>
            </template>
          </el-table-column>
        </template>
        <template v-else-if="item.prop==='name'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-button
                type="text"
                @click="dirClick(scope.row)">{{ scope.row.name }}</el-button>
            </template>
          </el-table-column>
        </template>
        <el-table-column
          v-else
          :key="item.prop"
          :prop="item.prop"
          :label="item.label"
          :min-width="item.width"
          :sortable="item.sortable"
          show-overflow-tooltip
          header-align="center"
          align="center"/>
      </template>
      <el-table-column
        label="操作"
        header-align="center"
        align="left"
        width="130px">
        <template slot-scope="scope">
          <div class="el-table-edit">
            <i
              class="el-icon-edit"
              @click="editM(scope.row)"/>
            <i
              class="iconfont icon-shanchu-copy-copy"
              @click="deleteM(scope.row)"/>
            <el-popover
              v-if="scope.row.type!=='directory'"
              placement="right"
              popper-class="space"
              trigger="hover">
              <ul class="utils-ui">
                <template v-if="scope.row.type==='dashboard'&&scope.row.onlineVersion>0">
                  <li @click="setMethod('url',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-URL"/> 发布地址</li>
                </template>
                <template v-else-if="scope.row.type!=='dashboard'">
                  <li @click="setMethod('info',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-jibenxinxi"/> 基本信息</li>
                  <li @click="setMethod('copy',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-fuzhi"
                  /> 复制至</li>
                </template>
                <li
                  v-if="scope.row.onlineVersion>0"
                  @click="setMethod('offline',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-xiaxian"/> 下线</li>
                <li
                  v-else
                  @click="setMethod('online',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-shangxian"/> 上线</li>
                <template v-if="scope.row.dataSourceType==='presto'&&scope.row.onlineVersion>0">
                  <li @click="tipType='saveline',tipDialogVisible=true;tipData=scope.row"><i
                    slot="reference"
                    class="iconfont icon-diaodu"/> 调度信息</li>
                  <li @click="setMethod('refresh',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-refresh"
                  /> 刷新数据</li>
                  <li @click="setMethod('list',scope.row)"><i
                    slot="reference"
                    class="iconfont icon-neirongziduanguanli"
                  /> 刷新记录</li>
                </template>
              </ul>
              <i
                slot="reference"
                class="iconfont icon-msnui-more"/>
            </el-popover>
          </div>
        </template>
      </el-table-column>
    </Grid>
    <NoData
      v-if="mask===2"
      title="暂时没有任何内容哦，快开始吧"/>
    <Dialog
      v-if="dialogVisible"
      :visible="dialogVisible"
      :type="dialogType"
      :projectId="projectId"
      :parentId="parentId"
      :dir="dir"
      :breadList="breadList"
      @close="dialogVisible=false"
      @success="getProjectAll"/>
    <SubDialog
      v-if="subDialogVisible"
      :visible="subDialogVisible"
      :data="subData"
      @success="getProjectAll"
      @close="subDialogVisible=false"/>
    <tipDialog
      v-if="tipDialogVisible"
      :visible="tipDialogVisible"
      :obj="tipData"
      :type="tipType"
      @close="tipDialogVisible=false;getProjectAll()"/>
  </div>
  <Main
    v-else
    :breadList="subBreadList"
    :projectId="projectId"
    :parentId="subParentId"/>
</template>
<script>
import {
  getProjectAll, delDir, delDataSet, getDataSetInfo,
  getDataSetBaseInfo, online, offline, triggerRefresh,
  getUrl
} from 'src/api/space.js';
import { delDashboard } from 'src/api/panel.js';
import Breadcrumb from 'src/components/Breadcrumb';
import { Grid } from '@hb/bi-ui';
import options from './options';
import Dialog from '../components/dialogCreateDataset';
import NoData from '../components/noData';
import tipDialog from '../components/tipDialog';
import SubDialog from './dialog';

export default {
  name: 'Main',
  components: {
    Breadcrumb,
    Grid,
    Dialog,
    NoData,
    SubDialog,
    tipDialog
  },
  props: {
    breadList: {
      type: Array,
      default() {
        return [];
      }
    },
    projectId: {
      type: [String, Number],
      default: -1
    },
    parentId: {
      type: [String, Number],
      default: -1
    }
  },
  data() {
    return {
      dir: {},
      mainCom: true,
      dialogVisible: false, // 控制弹框展示
      dialogType: null, // 弹框类型，比如文件夹或者数据集
      mask: 0, // 控制展示列表还是展示文案（快新建哦）
      total: 0, // 总数
      pageNo: 1, // 表格第几页
      pageSize: 20, // 表格每页条数
      dataList: [], // 表格数据list,
      name: null, // 模糊搜索name
      // 子组件需要的参数
      subBreadList: [],
      subParentId: -1,
      // 列表操作
      subDialogVisible: false,
      subData: {},
      // 上线dialog
      tipDialogVisible: false,
      tipData: {},
      tipType: 'online'
    };
  },
  watch: {
    projectId: {
      handler() {
        this.getProjectAll();
      },
      immediate: true
    },
  },
  created() {
    this.tableList = options.tableList;
  },
  methods: {
    getParams() {
      return {
        name: this.name,
        projectId: this.projectId,
        parentId: `${this.parentId}` === `${this.projectId}` ? -1 : this.parentId,
        pageNo: this.pageNo,
        pageSize: this.pageSize
      };
    },
    async getProjectAll(mask) { // 获取项目列表信息
      this.mask = mask || 0;
      const res = await getProjectAll(this.getParams());
      this.mask = res.list.length > 0 ? 1 : 2;
      this.total = res.total;
      this.dataList = res.list;
    },
    deleteM(item) { // 删除方法
      const { id, type } = item;
      if (type === 'directory') {
        delDir({ id }).then(() => {
          this.getProjectAll();
        });
      } else if (type === 'dashboard') {
        delDashboard(id).then(() => {
          this.getProjectAll();
        });
      } else {
        delDataSet({ id, type }).then(() => {
          this.getProjectAll();
        });
      }
      // this.$confirm(`确定删除 ${item.name}?`, '提示', {
      //   confirmButtonText: '确定',
      //   cancelButtonText: '取消',
      //   type: 'warning'
      // }).then(() => {
      // }).catch(() => {});
    },
    // 展示子组件相关操作
    breadClick(breadList) { // 面包屑点击
      const h = breadList.length;
      this.mainCom = false;
      this.subParentId = breadList[h - 1].id;
      this.subBreadList = breadList;
    },
    dirClick(row) { // 文件夹名字点击
      if (row.type !== 'directory') {
        this.editM(Object.assign(row, { look: true }));
        return;
      }
      this.mainCom = false;
      this.subParentId = row.id;
      this.breadList.push({
        name: row.name,
        id: row.id
      });
      this.subBreadList = this.breadList;
    },
    editM(data) { // 点击编辑（文件夹或者数据集）
      if (data.type === 'directory') {
        this.dialogType = 'directory';
        this.dialogVisible = true;
        this.dir = data;
      } else if (data.type === 'dashboard') { // 编辑仪表盘
        this.clickPanel(data);
      } else { // 数据集
        getDataSetInfo({
          id: data.id,
          type: data.type
        }).then((res) => {
          let name = 'createSpaceSQL';
          if (data.type === 'es') {
            name = 'createSpaceES';
          } else if (data.type === 'pai') {
            name = 'createSpaceAsset';
          }
          this.$router.push({
            name,
            params: {
              res,
              look: data.look,
              type: res.dataSet.dataSourceType,
              parentId: this.parentId,
              projectId: this.projectId,
              breadList: this.breadList,
            }
          });
        });
      }
    },
    setMethod(mask, data) { // 基本信息或者复制按钮
      if (mask === 'url') { // 获取仪表盘url
        getUrl({
          dataSetId: data.id,
        }).then((res) => {
          this.$alert(res, '发布地址', {
            confirmButtonText: '复制',
            callback: (action) => {
              if (action === 'confirm') {
                if (!this.copyInputInstance) {
                  this.copyInputInstance = document.createElement('input');
                  document.body.appendChild(this.copyInputInstance);
                }
                this.copyInputInstance.style.display = 'block';
                this.copyInputInstance.value = res;
                this.copyInputInstance.select();
                // 调用浏览器的复制命令
                document.execCommand('Copy');
                this.copyInputInstance.style.display = 'none';
                //
                this.$message({
                  type: 'success',
                  message: '复制成功'
                });
              }
            }
          });
        });
      } else if (mask === 'info') { // 基本信息
        getDataSetBaseInfo({
          id: data.id,
          type: data.type
        }).then((res) => {
          this.subDialogVisible = true;
          Object.assign(this.subData, { ...res }, { mask, breadList: this.breadList });
        });
      } else if (mask === 'copy') { // 复制
        this.subDialogVisible = true;
        Object.assign(this.subData, {
          mask,
          dataSetId: data.id,
          dataSetType: data.type
        });
      } else if (mask === 'list') { // 展示刷新列表
        this.subDialogVisible = true;
        Object.assign(this.subData, {
          mask,
          dataSetId: data.id,
          dataSetType: data.type
        });
      } else if (mask === 'refresh') { // 刷新
        triggerRefresh({
          dataSetId: data.id,
          dataSetType: data.type
        }).then(() => {
          this.$message({
            type: 'success',
            message: '刷新任务已经提交，请查看刷新日志!'
          });
        }).catch(() => {});
      } else if (mask === 'online') { // 上线
        if (data.dataSourceType === 'presto') {
          this.tipType = 'line';
          this.tipDialogVisible = true;
          this.tipData = data;
          return;
        }
        this.$confirm(`确定上线 ${data.name} ?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          online({
            dataSetId: data.id,
            dataSetType: data.type,
            refreshable: 0, // 0 不启用 1 启用
          }).then(() => {
            this.getProjectAll();
          });
        }).catch(() => {});
      } else if (mask === 'offline') { // 下线
        this.$confirm(`确定下线 ${data.name} ?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          offline({
            dataSetId: data.id,
            dataSetType: data.type,
          }).then(() => {
            this.getProjectAll();
          });
        }).catch(() => {});
      }
    },
    clickPanel(data = {}) { // 新建仪表盘
      this.$store.commit('initState');
      this.$router.push({
        name: 'panel',
        params: {
          id: data.id || 'create', // 仪表盘id
          parentId: this.parentId,
          projectId: this.projectId,
          state: data.onlineVersion > 0 ? 'online' : 'offline',
          breadList: JSON.stringify(this.breadList),
        }
      });
    }
  }
};
</script>
<style scoped lang="less">
.el-table-edit {
  .el-icon-edit {
    font-size: 16px;
  }
  i {
    color: #409EFF;
    cursor: pointer;
    margin: 0 10px;
  }
}
</style>
