const tableList = [
  { label: '', prop: 'type', width: 80 },
  { label: '名称', prop: 'name' },
  { label: '状态', prop: 'onlineVersion' },
  { label: '创建人', prop: 'creator' },
  { label: '修改人', prop: 'updater' },
  { label: '最近修改时间', prop: 'createTime' },
];

export default {
  tableList,
};
