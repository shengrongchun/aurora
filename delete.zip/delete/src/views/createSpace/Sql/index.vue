<template>
  <div
    v-loading="loading"
    element-loading-text="字段信息加载中"
    class="main-container">
    <breadcrumb
      :bread-list="breadList"
      @breadClick="breadClick">
      <el-button
        v-if="breadList[breadList.length-1].name!=='新建'+$route.params.type+'数据集'"
        slot="left"
        type="text"
        @click="look=!look">{{ look?'查看模式':'编辑模式' }}</el-button>
      <el-button
        :class="{'look':look}"
        :disabled="look"
        type="primary"
        @click="saveData">保存数据集</el-button>
    </breadcrumb>
    <el-tabs
      v-model="activeName">
      <el-tab-pane
        label="SQL编辑"
        name="1">
        <div class="search">
          <el-select
            v-model="form.dataSourceObj"
            :disabled="look"
            :class="{'look':look}"
            value-key="id"
            placeholder="请选择数据源">
            <el-option
              v-for="item in options"
              :key="item.id"
              :label="item.name"
              :value="item"/>
          </el-select>
          <el-button
            :disabled="form.dataSourceObj.id===undefined || look"
            type="primary"
            @click="getSqlParamsList">加载字段</el-button>
        </div>
        <bi-monaco
          ref="biMonaco"
          :sql="form.baseSql"
          :disabled="look"
          :data-source-type="form.type"
          :show-operate="showOperate"
          :data-source-id="form.dataSourceObj.id+''"/>
      </el-tab-pane>
      <el-tab-pane
        :class="{'look':look}"
        label="字段配置"
        name="2">
        <el-table
          v-if="dataList.length"
          :data="dataList"
          class="no-vborder"
          max-height="950"
          style="width: 100%">
          <el-table-column
            label="序号"
            width="80px"
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <span>{{ scope.$index+1 }}</span>
            </template>
          </el-table-column>
          <template
            v-for="item in tableList">
            <template v-if="item.prop==='name'">
              <el-table-column
                :key="item.prop"
                :prop="item.prop"
                :label="item.label"
                :width="item.width"
                :sortable="item.sortable"
                show-overflow-tooltip
                header-align="center"
                align="center">
                <template slot-scope="scope">
                  <el-input
                    v-model="scope.row.name"
                    disabled
                    placeholder="请输入字段名"/>
                </template>
              </el-table-column>
            </template>
            <template v-else-if="item.prop==='label'">
              <el-table-column
                :key="item.prop"
                :prop="item.prop"
                :label="item.label"
                :width="item.width"
                :sortable="item.sortable"
                show-overflow-tooltip
                header-align="center"
                align="center">
                <template slot-scope="scope">
                  <el-input
                    v-model="scope.row.label"
                    placeholder="请输入显示名称"/>
                </template>
              </el-table-column>
            </template>
            <template v-else-if="item.prop==='dataType'">
              <el-table-column
                :key="item.prop"
                :prop="item.prop"
                :label="item.label"
                :width="item.width"
                :sortable="item.sortable"
                show-overflow-tooltip
                header-align="center"
                align="center">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.dataType"
                    placeholder="请选择字段类型">
                    <el-option
                      label="整型数值"
                      value="integer"/>
                    <el-option
                      label="浮点数值"
                      value="double"/>
                    <el-option
                      label="字符串"
                      value="string"/>
                    <el-option
                      label="日期"
                      value="time"/>
                  </el-select>
                </template>
              </el-table-column>
            </template>
            <template v-else-if="item.prop==='type'">
              <el-table-column
                :key="item.prop"
                :prop="item.prop"
                :label="item.label"
                :width="item.width"
                :sortable="item.sortable"
                show-overflow-tooltip
                header-align="center"
                align="center">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.type"
                    placeholder="请选择字段种类">
                    <el-option
                      label="维度"
                      value="dimension"/>
                    <el-option
                      label="指标"
                      value="metric"/>
                  </el-select>
                </template>
              </el-table-column>
            </template>
          </template>
          <el-table-column
            label="操作"
            header-align="center"
            align="center"
            width="100px">
            <template slot-scope="scope">
              <div
                class="el-table-edit"
                @click="deleteRow(scope.$index, dataList)">
                <i
                  class="iconfont icon-shanchu-copy-copy"
                />
              </div>
            </template>
          </el-table-column>
        </el-table>
        <NoData
          v-else
          title="没有字段噢～"/>
      </el-tab-pane>
    </el-tabs>
    <Dialog
      v-if="dialogVisible"
      :visible="dialogVisible"
      :params="form"
      :breadList="$route.params.breadList"
      @close="dialogVisible=false"/>
  </div>
</template>
<script>

import Breadcrumb from 'src/components/Breadcrumb';
import { getDataSourceList, getSqlParamsList } from 'src/api/space.js';
import BiMonaco from '../components/biMonaco';
import NoData from '../components/noData';
import Dialog from '../components/saveDataSet';
import options from './options';

export default {
  components: {
    Breadcrumb,
    BiMonaco,
    NoData,
    Dialog
  },
  data() {
    return {
      showOperate: { run: true, format: true }, // toolbar上展示测试运行/格式化
      activeName: '1', // SQL编辑：1，字段配置：2
      options: [],
      loading: false,
      dataList: [],
      dialogVisible: false,
      look: !!this.$route.params.look,
      form: {
        id: this.res.dataSet.id,
        type: this.$route.params.type, // 数据源类型
        projectId: this.$route.params.projectId,
        directoryId: this.$route.params.parentId,
        dataSourceObj: {},
        name: this.res.dataSet.name,
        description: this.res.dataSet.description,
        baseSql: this.res.dataSet.baseSql,
        columns: this.res.columns || [],
      }
    };
  },
  computed: {
    breadList() {
      const list = (this.$route.params.breadList || []).concat([]);
      if (this.res.columns.length > 0) {
        list.push({ name: `${this.look ? '查看' : `编辑`} ${this.$route.params.type} - ${this.form.name} 数据集` });
      } else {
        list.push({ name: `新建${this.$route.params.type}数据集` });
      }
      return list;
    }
  },
  beforeCreate() {
    this.res = this.$route.params.res || { columns: [], dataSet: {} };
    this.tableList = options.tableList;
  },
  created() {
    // 判断是自定比sql页面的时候，再去请求，否则在首页就会发出一次请求
    if (this.form.type === 'mysql' || this.form.type === 'postgresql' || this.form.type === 'presto') {
      this.getDataSourceList();
    }
  },
  methods: {
    getDataSourceList() {
      const params = {
        projectId: this.form.projectId,
        dataSourceType: this.form.type
      };
      getDataSourceList(params).then((res) => {
        this.options = res;
        if (this.res.columns.length > 0) {
          const { dataSet } = this.res;
          for (let i = 0, j = res.length; i < j; i += 1) {
            if (res[i].id === dataSet.dataSourceId && res[i].type === dataSet.dataSourceType) {
              this.form.dataSourceObj = res[i];
            }
          }
          // 编辑状态下默认显示已有字段
          this.dataList = this.res.columns;
        } else { // 新建
          [this.form.dataSourceObj = {}] = res;
        }
      });
    },
    breadClick(breadList) { // 跳转
      const h = breadList.length;
      this.$router.push({
        name: 'createSpaceIndex',
        params: {
          parentId: h > 1 ? breadList[h - 1].id : -1,
          projectId: this.form.projectId || -1,
          breadList: JSON.stringify(breadList)
        }
      });
    },
    // 加载字段
    getSqlParamsList() {
      this.loading = true;
      const sql = this.$refs.biMonaco.getValue();
      const params = {
        dataSourceId: `${this.form.dataSourceObj.id}`,
        dataSourceType: this.form.type,
        sql
      };
      getSqlParamsList(params).then((res) => {
        this.dataList = res;
        this.activeName = '2';
      }).finally(() => {
        this.loading = false;
      });
    },
    deleteRow(index, rows) {
      rows.splice(index, 1);
    },
    saveData() {
      if (this.form.dataSourceObj.id === undefined) {
        this.$message.warning('请选择数据源');
        return;
      }
      if (this.dataList.length === 0) {
        this.$message.warning('请加载字段');
      } else {
        for (let i = 0, j = this.dataList.length; i < j; i += 1) {
          const obj = this.dataList[i];
          if (!obj.name || !obj.label || !obj.dataType || !obj.type) {
            this.$message.warning(`第 ${i + 1} 行有未填项`);
            return;
          }
        }
        //
        this.form.columns = this.dataList;
        this.form.baseSql = this.$refs.biMonaco.getValue();
        if (!this.form.baseSql) {
          this.$message.warning('请输入sql');
          return;
        }
        this.dialogVisible = true;
      }
    }
  }
};
</script>

<style scoped lang="less">
.search {
  padding: 0 0 14px;
  button {
    margin-left: 20px;
  }
}
.look {
  pointer-events: none;
}
.el-table.no-vborder {
  /deep/ td {
    border: none;
  }
}
.el-table-edit {
  .el-icon-edit {
    font-size: 16px;
  }
  i {
    color: #409EFF;
    cursor: pointer;
    margin: 0 10px;
  }
}
</style>
