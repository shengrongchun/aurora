<template>
  <div class="createSpace">
    <Main
      v-if="showMask===1"
      :list="list"/>
    <NoData v-if="showMask===2">
      <el-button
        type="primary"
        @click="dialogVisible=true">新建项目</el-button>
    </NoData>
    <Dialog
      :visible="dialogVisible"
      @close="dialogVisible=false"
      @success="getProjectList"/>
  </div>
</template>
<script>
import { getProjectList } from 'src/api/space.js';
import Main from './main';
import Dialog from './components/dialogCreateProject';
import NoData from './components/noData';

export default {
  components: {
    Main,
    Dialog,
    NoData
  },
  data() {
    return {
      showMask: 0,
      dialogVisible: false,
      list: [],
    };
  },
  created() {
    this.getProjectList();
  },
  methods: {
    async getProjectList() {
      const res = await getProjectList();
      if (res && res instanceof Array && res.length > 0) {
        this.list = res;
        this.showMask = 1;
      } else {
        this.showMask = 2;
      }
    },
  }
};
</script>
<style scoped>
.createSpace {
  height: 100%;
}
</style>
