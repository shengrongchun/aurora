<template>
  <div
    class="main-container">
    <Breadcrumb
      :bread-list="breadList"
      @breadClick="breadClick">
      <el-button
        v-if="breadList[breadList.length-1].name!=='新建ES数据集'"
        slot="left"
        type="text"
        @click="look=!look">{{ look?'查看模式':'编辑模式' }}</el-button>
      <el-button
        :disabled="look"
        type="primary"
        @click="saveData">保存数据集</el-button>
    </Breadcrumb>
    <el-form
      ref="form"
      :inline="true"
      :model="form"
      :rules="rules"
      class="header">
      <el-form-item
        label="数据源"
        prop="dataSourceObj">
        <el-select
          v-model="form.dataSourceObj"
          :disabled="look"
          placeholder="请选择数据源">
          <el-option
            v-for="(obj,idx) in sourceList"
            :key="idx"
            :value="obj"
            :label="obj.name"/>
        </el-select>
      </el-form-item>
      <el-form-item
        label="索引名"
        prop="esIndex">
        <el-input
          v-model="form.esIndex"
          :disabled="look"
          placeholder="请输入索引名"/>
      </el-form-item>
      <el-form-item
        label="type"
        prop="esType">
        <el-input
          v-model="form.esType"
          :disabled="look"
          placeholder="请输入type"/>
      </el-form-item>
      <el-button
        :disabled="look"
        type="primary"
        icon="el-icon-plus"
        @click="form.columns.push({})">新建</el-button>
    </el-form>
    <Grid
      :tableAttrs="{border: false}"
      :isCellborder="false"
      :isPagination="false"
      :data="form.columns">
      <el-table-column
        label="序号"
        header-align="center"
        align="center">
        <template slot-scope="scope">
          <span>{{ scope.$index+1 }}</span>
        </template>
      </el-table-column>
      <template
        v-for="item in tableList">
        <template v-if="item.prop==='name'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-input
                v-model="scope.row.name"
                :disabled="look"
                placeholder="请输入字段名"/>
            </template>
          </el-table-column>
        </template>
        <template v-else-if="item.prop==='label'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-input
                v-model="scope.row.label"
                :disabled="look"
                placeholder="请输入显示名称"/>
            </template>
          </el-table-column>
        </template>
        <template v-else-if="item.prop==='dataType'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-select
                v-model="scope.row.dataType"
                :disabled="look"
                placeholder="请选择字段类型">
                <el-option
                  label="整型数值"
                  value="integer"/>
                <el-option
                  label="浮点数值"
                  value="double"/>
                <el-option
                  label="字符串类型"
                  value="string"/>
                <el-option
                  label="时间类型"
                  value="time"/>
              </el-select>
            </template>
          </el-table-column>
        </template>
        <template v-else-if="item.prop==='type'">
          <el-table-column
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
            :width="item.width"
            :sortable="item.sortable"
            show-overflow-tooltip
            header-align="center"
            align="center">
            <template slot-scope="scope">
              <el-select
                v-model="scope.row.type"
                :disabled="look"
                placeholder="请选择字段种类">
                <el-option
                  label="维度"
                  value="dimension"/>
                <el-option
                  label="指标"
                  value="metric"/>
              </el-select>
            </template>
          </el-table-column>
        </template>
      </template>
      <el-table-column
        label="操作"
        header-align="center"
        align="center"
        width="100px">
        <template slot-scope="scope">
          <div class="el-table-edit">
            <el-button
              :disabled="look"
              :class="{'disabled':look}"
              type="text"
              @click="deleteM(scope.$index)">
              <i
                class="iconfont icon-shanchu-copy-copy"
              />
            </el-button>
          </div>
        </template>
      </el-table-column>
    </Grid>
    <Dialog
      v-if="dialogVisible"
      :visible="dialogVisible"
      :params="form"
      :breadList="$route.params.breadList"
      @close="dialogVisible=false"/>
  </div>
</template>
<script>
import { getDatasources } from 'src/api/space.js';
import Breadcrumb from 'src/components/Breadcrumb';
import { Grid } from '@hb/bi-ui';
import Dialog from '../components/saveDataSet';
import options from './options';

export default {
  components: {
    Grid,
    Dialog,
    Breadcrumb
  },
  data() {
    return {
      dialogVisible: false,
      sourceList: [],
      look: !!this.$route.params.look,
      form: {
        name: this.res.dataSet.name,
        description: this.res.dataSet.description,
        id: this.res.dataSet.id,
        projectId: this.$route.params.projectId,
        directoryId: this.$route.params.parentId,
        dataSourceObj: null,
        esIndex: this.res.dataSet.esIndex, // es索引
        esType: this.res.dataSet.esType, // es类型
        columns: this.res.columns || []
      },
    };
  },
  computed: {
    breadList() {
      const list = (this.$route.params.breadList || []).concat([]);
      if (this.res.columns.length > 0) {
        list.push({ name: `${this.look ? '查看' : `编辑`} ES - ${this.form.name} 数据集` });
      } else {
        list.push({ name: '新建ES数据集' });
      }
      return list;
    }
  },
  beforeCreate() {
    this.res = this.$route.params.res || { columns: [], dataSet: {} };
    this.tableList = options.tableList;
    this.rules = {
      dataSourceObj: [
        { required: true, message: '请选择数据源', trigger: 'blur' }
      ],
      esIndex: [
        { required: true, message: '请输入索引值', trigger: 'blur' }
      ],
      esType: [
        { required: true, message: '请输入索引类型', trigger: 'blur' }
      ]
    };
  },
  created() {
    this.getTypeSource();
  },
  methods: {
    getTypeSource() {
      getDatasources({
        projectId: this.$route.params.projectId,
        dataSourceType: this.$route.params.type
      }).then((res) => {
        this.sourceList = res;
        if (this.res.columns.length > 0) {
          const { dataSet } = this.res;
          for (let i = 0, j = res.length; i < j; i += 1) {
            if (res[i].id === dataSet.dataSourceId && res[i].type === dataSet.dataSourceType) {
              this.form.dataSourceObj = res[i];
              return;
            }
          }
        }
      });
    },
    deleteM(idx) {
      this.form.columns.splice(idx, 1);
    },
    breadClick(breadList) { // 跳转
      const h = breadList.length;
      this.$router.push({
        name: 'createSpaceIndex',
        params: {
          parentId: h > 1 ? breadList[h - 1].id : -1,
          projectId: this.$route.params.projectId || -1,
          breadList: JSON.stringify(breadList)
        }
      });
    },
    saveData() {
      const j = this.form.columns.length;
      if (j < 1) {
        this.$message.warning('请新建');
        return;
      }
      for (let i = 0; i < j; i += 1) {
        const obj = this.form.columns[i];
        if (!obj.name || !obj.label || !obj.dataType || !obj.type) {
          this.$message.warning(`第 ${i + 1} 行有未填项`);
          return;
        }
      }
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.dialogVisible = true;
          return true;
        }
        return false;
      });
    }
  }
};
</script>
<style scoped lang="less">
.header{
  margin: 10px 0 0;
  border-bottom: 1px solid #eee;
}
.el-button.disabled {
  i {
    color: gray;
  }
}
.el-table-edit {
  .el-icon-edit {
    font-size: 16px;
  }
  i {
    color: #409EFF;
    cursor: pointer;
    margin: 0 10px;
  }
}
</style>
