<template>
  <div class="container-left flex-box">
    <div
      class="left-content flex-box"
      v-loading="loading">
      <div class="data-set">
        <span class="data-set-text">
          <i class="iconfont icon-shujuji"/>数据集
        </span>
        <el-select
          style="width:300px"
          v-model="dataSetId"
          placeholder="请选择数据集"
          filterable
          @change="changeDataSet">
          <el-option
            v-for="(item,index) in dataSetOptions"
            :key="index+'dataSetId'"
            :label="item.name"
            :value="item.id"/>
        </el-select>
        <el-tooltip
          effect="dark"
          content="前往查看数据集详情"
          placement="top">
          <i
            class="el-icon-view"
            @click="leavePi"/>
        </el-tooltip>
      </div>
      <div class="search">
        <el-input
          placeholder="快速搜索你想要的指标或维度，亦可使用&符号多关键字联查，点击选中"
          clearable
          @clear="searchIndexAndDim"
          v-model="searchContent"
          @keyup.enter.native="searchIndexAndDim"/>
        <el-button
          type="primary"
          @click="searchIndexAndDim">搜索</el-button>
      </div>
      <div class="index-dim flex-box">
        <div class="index-dim-title">
          <span
            @click="changeIndexDim('index')"
            :class="{'active':activeTitle==='index'}"
            class="title">
            指标<span style="font-size:14px;">（{{ indexTotal }}）</span>
          </span>
          <span
            @click="changeIndexDim('dim')"
            :class="{'active':activeTitle==='dim'}"
            class="title">
            维度<span style="font-size:14px;">（{{ dimTotal }}）</span>
          </span>
        </div>
        <!-- <div class="index-dim-filter">
          <div
            class="index-group"
            v-if="activeTitle==='index'">
            <span>指标组</span>
            <el-select
              v-model="configGroupId"
              placeholder="请选择指标组"
              size="mini"
              clearable>
              <el-option
                v-for="item in indexGroupOptions"
                :key="item.guid"
                :label="item.groupName"
                :value="item.guid"/>
            </el-select>
          </div>
        </div> -->
        <div class="index-dim-table">
          <div style="height:100%;overflow:auto">
            <div
              v-if="!(tableList && tableList.length)"
              style="text-align:center;margin-top: 30%;font-size: 14px;">
              暂无数据
            </div>
            <template v-else>
              <div
                class="table-list"
                v-for="(item,index) in tableList"
                :key="index"
                :class="{'select-list':item.isSelect}"
                @click="toggleSelect(item)"
                @mouseenter="event=>handleCellMouseEnter(event,item)">
                <span class="table-index">{{ index+1 }}</span>
                <div
                  class="table-list-item"
                  v-if="!item.isShowTop">
                  <span>
                    <template v-if="item.definition && item.definition!=='null'">
                      <span style="color:#037EFF">{{ item[tableTitleName]+' | ' }}</span>
                      {{ item.definition }}
                    </template>
                    <template v-else>
                      <span style="color:#037EFF">{{ item[tableTitleName] }}</span>
                    </template>
                  </span>
                </div>
                <el-tooltip
                  v-if="item.isShowTop"
                  class="item"
                  effect="dark"
                  popper-class="popper-wd-500"
                  :content="item.definition && item.definition!=='null'?
                  (item[tableTitleName]+' | '+item.definition) : item[tableTitleName]"
                  placement="left">
                  <div class="table-list-item">
                    <span>
                      <template v-if="item.definition && item.definition!=='null'">
                        <span style="color:#037EFF">{{ item[tableTitleName]+' | ' }}
                        </span>{{ item.definition }}
                      </template>
                      <template v-else>
                        <span style="color:#037EFF">{{ item[tableTitleName] }}</span>
                      </template>
                    </span>
                  </div>
                </el-tooltip>
                <i
                  class="el-icon-success"
                  v-if="item.isSelect"/>
              </div>
            </template>
          </div>
        </div>
        <div class="pagination">
          <el-pagination
            @current-change="handleCurrentChange"
            :pager-count="5"
            :current-page="currentPage"
            :page-size="20"
            layout="prev, pager, next, jumper"
            :total=" activeTitle === 'index' ? indexTotal : dimTotal"/>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import request from '@/api/AssetsData.js';

export default {
  props: {
    showData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      dataSetOptions: [],
      dataSetId: '',
      dataSetList: {},
      searchContent: null,
      activeTitle: 'index',
      isScroll: false,
      indexTableList: [],
      dimTableList: [],
      indexSelectList: this.showData.indexSelectList || [],
      dimSelectList: this.showData.dimSelectList || [],
      currentPage: 1,
      tableList: [],
      tableTitleName: 'indexName',
      dimTotal: 0,
      indexTotal: 0,
      loading: false,
      bizModuleId: null,
      dataFieldId: null,
      indexGroupOptions: [],
      configGroupId: '', // 指标组id
    };
  },
  watch: {
    configGroupId() { // 监听指标组id
      this.getIndexAndDimData('getIndexAndDim');
    }
  },
  created() {
    this.getDataSet();
    request.getNoticeData();
  },
  mounted() {
  },
  methods: {
    searchIndexAndDim() { // 搜索数据集
      this.getIndexAndDimData('getIndexAndDim');
    },
    async getDataSet() { // 获取数据集
      this.loading = true;
      try {
        this.dataSetOptions = await request.getDataSet();
        this.loading = false;
        if (this.dataSetOptions && this.dataSetOptions.length) {
          this.dataSetId = this.showData.dataSetId || this.dataSetOptions[0].id;
          //
          let dataSetList = {};
          for (let i = 0, j = this.dataSetOptions.length; i < j; i += 1) {
            if (this.dataSetOptions[i].id === this.dataSetId) {
              dataSetList = this.dataSetOptions[i];
              break;
            }
          }
          //
          this.dataSetList = dataSetList;
          this.$emit('getDataset', this.dataSetList);
          this.getIndexAndDimData('getIndexAndDim');
        }
      } catch (e) {
        this.loading = false;
      }
    },
    changeIndexDim(type) { // 切换指标维度
      this.activeTitle = type;
      this.tableTitleName = `${this.activeTitle}Name`;
      this.tableList = this[`${this.activeTitle}TableList`];
      this.currentPage = 1;
      this.getIndexAndDimData('getIndexAndDim');
      // UBT.clickButton({
      //   pageId: 'selfdata',
      //   buttonName: 'secondary_navigation_bar_click',
      //   categoryId: 'dataplatform',
      // });
    },
    getIndexAndDimData(type) { // 获取指标维度列表
      this.loading = true;
      const params = {
        dataSetId: this.dataSetId,
        indexInfoList: this.indexSelectList,
        dimInfoList: this.dimSelectList,
        searchInfo: {
          keyword: this.searchContent || null,
          bizModuleId: this.bizModuleId,
          dataFieldId: this.dataFieldId,
          configGroupId: this.configGroupId,
          pageInfo: { pageSize: 20, current: this.currentPage }
        }
      };
      request.getIndexAndDimData(params).then((res) => {
        if (res) {
          this.indexTableList = res.indexInfoList || [];
          this.dimTableList = res.dimInfoList || [];
          this.compareSelect(this.activeTitle);
          this.tableTitleName = `${this.activeTitle}Name`;
          this.tableList = this[`${this.activeTitle}TableList`];
          this.dimTotal = res.dimTotal || 0;
          this.indexTotal = res.indexTotal || 0;
          if (!type) {
            this.indexSelectList = this.indexSelectList.reduce((arr, items) => {
              let obj = Object.assign({}, items);
              this.indexTableList.forEach((item) => {
                if (items.indexId === item.indexId && items.indexName === item.indexName) {
                  obj = { ...item };
                }
              });
              arr.push(obj);
              return arr;
            }, []);
            this.dimSelectList = this.dimSelectList.reduce((arr, items) => {
              let obj = Object.assign({}, items);
              this.dimTableList.forEach((item) => {
                if (items.dimId === item.dimId && items.dimName === item.dimName) obj = { ...item };
              });
              arr.push(obj);
              return arr;
            }, []);
            this.$emit('selectIndexAndDim', this[`${this.activeTitle}SelectList`], this.activeTitle);
            this.$emit('selectFilterInfo', this.indexSelectList, this.dimSelectList);
          }
        }
      }).finally(() => {
        this.loading = false;
      });
    },
    toggleSelect(item) { // 选中切换
      this.$set(item, 'isSelect', !item.isSelect);
      if (item.isSelect) {
        let isContain = true;
        this[`${this.activeTitle}SelectList`].forEach((val) => {
          if (item[`${this.activeTitle}Name`] === val[`${this.activeTitle}Name`] && item[`${this.activeTitle}Id`] === val[`${this.activeTitle}Id`])isContain = false;
        });
        if (isContain) this[`${this.activeTitle}SelectList`].push(item);
      } else {
        this[`${this.activeTitle}SelectList`].forEach((val, index) => {
          if (item[`${this.activeTitle}Name`] === val[`${this.activeTitle}Name`] && item[`${this.activeTitle}Id`] === val[`${this.activeTitle}Id`]) this[`${this.activeTitle}SelectList`].splice(index, 1);
        });
      }
      this.getIndexAndDimData();
    },
    cancelSelect(list, type) { // 取消选中
      this[`${type}SelectList`] = list;
      this.getIndexAndDimData();
    },
    compareSelect(type) { // 选中
      this[`${type}TableList`].forEach(item => this.$set(item, 'isSelect', false));
      this[`${type}SelectList`].forEach((item) => {
        this[`${type}TableList`].forEach((items) => {
          if (items[`${type}Id`] === item[`${type}Id`] && items[`${type}Name`] === item[`${type}Name`]) this.$set(items, 'isSelect', true);
        });
      });
    },
    handleCurrentChange(val) { // 分页
      this.currentPage = val;
      this.getIndexAndDimData('getIndexAndDim');
    },
    changeDataSet() { // 改变数据集 所有条件重置
      ['searchContent', 'bizModuleId', 'dataFieldId'].forEach((item) => {
        this[item] = null;
      });
      ['indexSelectList', 'dimSelectList'].forEach((item) => {
        this[item] = [];
      });
      // this.foldTabList.forEach((item) => { item.initItem = 0; });
      this.activeTitle = 'index';
      this.currentPage = 1;
      this.getIndexAndDimData('getIndexAndDim');
      // this.getIndexGroupList();
      const array = this.dataSetOptions.filter(item => item.id === this.dataSetId);
      const [arr] = array;
      this.dataSetList = arr;
      this.$emit('getDataset', this.dataSetList);
      this.$emit('clearRightData', this.indexSelectList, this.dimSelectList);
      // UBT.clickButton({
      //   pageId: 'selfdata',
      //   buttonName: 'datagroup_dropdownbox_click',
      //   categoryId: 'dataplatform',
      // });
    },
    getDetailAllData(allData) { // 获取详情
      this.searchContent = '';
      this.currentPage = 1;
      this.dataSetId = allData.dataSetId;
      this.indexSelectList = allData.indexInfoList;
      this.dimSelectList = allData.dimInfoList;
      this.getIndexAndDimData('getIndexAndDim');
    },
    // getTableList() { // 获取右侧任务列表
    //   this.$emit('getTableList');
    // },
    handleCellMouseEnter(event, item) {
      const range = document.createRange();
      range.selectNodeContents(event.target);
      const rangeWidth = range.getBoundingClientRect().width;
      this.$set(item, 'isShowTop', parseInt(rangeWidth, 10) + 40 > event.target.offsetWidth || event.target.scrollWidth > event.target.offsetWidth);
    },
    leavePi() { // 前往资产管理
      const env = process.env.VUE_APP_ENV;
      const prefix = env === 'pro' ? '' : `${env}-`;
      const { name, id } = this.dataSetList;
      window.open(`http://${prefix}pi.hellobike.cn/#/assetsMap/exploration/components/detail/detailList?name=${name}&guid=${id}`);
    }
  }
};

</script>

<style lang="less" scoped src="../style/index.less"></style>
