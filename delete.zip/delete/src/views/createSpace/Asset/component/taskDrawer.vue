<template>
  <div class="flex-box">
    <div class="task-content flex-box">
      <div class="search">
        <el-input
          placeholder="快速搜索定时任务，双击可重复选中，亦可选择快速直接执行"
          v-model="taskName"
          @keyup.enter.native="searchData"
          clearable
          @clear="searchData"/>
        <el-button
          type="primary"
          @click="searchData">搜索</el-button>
      </div>
      <div class="task-list flex-box">
        <grid
          ref="grid"
          :border="false"
          dataName="records"
          emptyText="无相关任务，请重新输入查询"
          :smallPagination="true"
          @sortMethod="sortMethod"
          :remote-method="getTableDataRemoteMethod"
          :row-click="rowClick">
          <template v-for="item in tableList">
            <el-table-column
              v-if="item.prop !=='taskName'"
              :key="item.prop"
              :label="item.label"
              :prop="item.prop"
              header-align="center"
              align="center"
              :sortable="item.sortable"
              :min-width="item.minWidth"
              show-overflow-tooltip/>
            <el-table-column
              v-if="item.prop ==='taskName'"
              :key="item.prop"
              :label="item.label"
              :prop="item.prop"
              header-align="center"
              align="center"
              show-overflow-tooltip>
              <template slot-scope="scope">
                <el-popover
                  placement="right-start"
                  trigger="click">
                  <div>
                    <p style="color:#037EFF">详情：</p>
                    <h4
                      v-for="(items,index) in popoverList"
                      :key="index+'popover'">
                      {{ items.name+items.value }}
                    </h4>
                  </div>
                  <div
                    slot="reference"
                    style="cursor:pointer;color:#037EFF"
                    @click="getPopoverData(scope.row)">{{ scope.row.taskName }}</div>
                </el-popover>
              </template>
            </el-table-column>
          </template>
          <el-table-column
            label="操作"
            header-align="center"
            align="center"
            width="90px">
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="success"
                class="button-success"
                @click="changeCarry(scope.row.guid)">手动执行</el-button>
              <el-button
                size="mini"
                class="button-warning"
                :type="scope.row.taskTag === 1 ? 'warning' : 'info'"
                @click="changeStatus(scope.row.guid,scope.row.taskTag === 1 ? 0 : 1)">
                {{ scope.row.taskTag === 1 ? '暂停':'恢复' }}</el-button>
              <el-button
                size="mini"
                type="danger"
                class="button-danger"
                @click="changeStatusDel(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </grid>
      </div>
    </div>
    <el-dialog
      :visible.sync="dialogVisible"
      custom-class="select-dialog"
      center
      append-to-body
      width="500px">
      <span>
        <i class="el-icon-warning"/>确认删除<span style="color:#E6A23C">
        {{ delTaskItem.taskName || '--' }} </span>定时任务？
      </span>
      <span
        slot="footer"
        class="dialog-footer">
        <el-button @click="dialogVisible =false">取 消</el-button>
        <el-button
          type="primary"
          @click="delConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import request from '@/api/AssetsData.js';
import options from '../options';
import grid from './commonGrid';


export default {
  components: {
    grid
  },
  data() {
    return {
      taskName: null,
      tableList: options.drawerTableList,
      popoverList: [],
      searchParams: { taskName: null, taskType: 2 },
      dialogVisible: false,
      delTaskItem: {}
    };
  },
  created() {
    this.popoverList = this.resetPopoverdata();
  },
  methods: {
    searchData() {
      this.searchParams.taskName = this.taskName;
      this.loadTableData();
    },
    loadTableData() { // 获取table
      this.$refs.grid.loadData({ search: this.searchParams });
    },
    getTableDataRemoteMethod(params) {
      return request.getTaskTableData(params);
    },
    closeDrawer() {
      this.$emit('getDataList');
    },
    getPopoverData(item) { // 获取任务详情
      this.popoverList = this.resetPopoverdata();
      request.getTaskDetailData({ guid: item.guid }).then((res) => {
        // eslint-disable-next-line no-shadow
        this.popoverList.forEach((item) => {
          item.value = res[item.prop] || '--';
        });
      });
    },
    changeStatus(guid, status) { // 操作
      const params = {
        guid,
        taskTag: status,
        taskType: 2
      };
      request.changeTimingTaskStatus(params).then((res) => {
        if (res) this.loadTableData();
      });
    },
    changeCarry(guid) { // 手动执行
      const params = { guid, taskType: 2 };
      request.getManulSumbit(params).then((res) => {
        if (res) {
          this.$message.success('手动执行成功');
          this.$emit('getRightTableList');
        }
      });
    },
    changeStatusDel(item) { // 删除任务
      this.delTaskItem = item;
      this.dialogVisible = true;
    },
    delConfirm() { // 删除确认
      const params = {
        guid: this.delTaskItem.guid,
        taskTag: 2,
        taskType: 2
      };
      request.changeTimingTaskStatus(params).then((res) => {
        if (res) {
          this.$message.success('删除成功');
          this.loadTableData();
        }
      }).finally(() => {
        this.dialogVisible = false;
      });
    },
    sortMethod(item) { // 排序
      let type = 0;
      if (item.order) type = item.order === 'ascending' ? 1 : 2;
      Object.assign(this.searchParams, {
        sort: { name: item.prop, type },
      });
      this.loadTableData();
    },
    resetPopoverdata() {
      return [
        { name: '任务名称：', prop: 'taskName', value: '--' },
        { name: '指标：', prop: 'indexs', value: '--' },
        { name: '维度：', prop: 'dims', value: '--' },
        { name: '数据通知人：', prop: 'notifyList', value: '--' },
        { name: '定时周期：', prop: 'schduledCycle', value: '--' },
        { name: '创建时间：', prop: 'createDate', value: '--' },
        { name: '最后一次执行时间：', prop: 'lastProcessDate', value: '--' },
      ];
    },
    rowClick(row) { // 获取详情接口
      this.$emit('getDetail', row.guid, 'timingTask');
    }
  },

};
</script>
<style lang="less" src="../style/index.less"></style>
