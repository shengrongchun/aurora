<template>
  <div
    class="filter-content"
    :class="{'filter-margin':filterList.length}">
    <template v-for="(item,index) in filterList">
      <div
        :key="index+'text'"
        class="filter-or"
        v-if="index!==0">
        <div class="text-or">或</div>
        <div class="line-or"/>
      </div>
      <div
        class="filter"
        :key="index+filterList.length">
        <div class="border-right">
          <div class="filter-flex">
            <div
              class="line"
              :class="{'white-line':!(item.conditionList && item.conditionList.length)}"/>
            <div
              class="filter-select"
              style="position:relative">
              <div
                class="left-line"
                v-if="item.conditionList && item.conditionList.length"/>
              <selectGroup
                :item="item"
                :select-data="selectData"
                :index="index"
                :key="index"
                :dictionary-field-type="item.dictionaryFieldType"
                ref="validate"
                :dataSetId="dataSetId"
              />
              <span style="margin-left:-10px">
                <span @click="addFilterAnd(item)">
                  <i class="el-icon-circle-plus-outline el-icon"/>
                </span>
                <span
                  @click="delFilterAnd(item,index,'parent')">
                  <i class="el-icon-delete el-icon"/>
                </span>
              </span>
            </div>
          </div>
          <template v-if="item.conditionList && item.conditionList.length">
            <div
              v-for="(child,ind) in item.conditionList"
              :key="ind+'child'"
              class="filter-child">
              <div class="filter-flex">
                <div class="line"/>
                <div
                  class="filter-select-child"
                  style="position:relative">
                  <div
                    class="left-line"
                    v-if="ind!==item.conditionList.length-1"/>
                  <div class="filter-text">且</div>
                  <selectGroup
                    :item="child"
                    :select-data="selectData"
                    :index="ind"
                    :dictionary-field-type="child.dictionaryFieldType"
                    ref="validate"
                    :key="index+item.conditionList.length"
                    style="margin-left:-27px"
                    :dataSetId="dataSetId"
                  />
                  <span style="margin-left:-10px">
                    <span @click="addFilterAnd(item,ind)">
                      <i class="el-icon-circle-plus-outline el-icon"/>
                    </span>
                    <span @click="delFilterAnd(item,ind,'child')">
                      <i class="el-icon-delete el-icon"/>
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </template>
  </div>
</template>
<script>
import request from '@/api/AssetsData.js';
import options from '../options';
import selectGroup from './selectGroup';

export default {
  components: { selectGroup },
  props: {
    detailList: {
      type: Array,
      default: () => []
    },
    dataSetId: {
      type: [String, Array],
      default: null
    }
  },
  data() {
    return {
      request,
      compareOptions: options.filterOptions,
      filterList: [],
      selectData: [],
    };
  },
  watch: {
    detailList(newVal) {
      this.filterList = newVal;
    },
  },
  created() {
  },
  mounted() {
    this.filterList = this.detailList;
  },
  methods: {
    createFilterList() {
      this.filterList = this.resetFilterList();
    },
    resetFilterList() {
      return [{ conditionList: [] }];
    },
    addFilterOr() {
      this.filterList.push({
        connectiveSymbol: '1', conditionList: []
      });
    },
    addFilterAnd(item, index) {
      if (!index && index !== 0) {
        item.conditionList.unshift({
          connectiveSymbol: '0', conditionList: []
        });
      } else {
        item.conditionList.splice(index + 1, 0, {
          connectiveSymbol: '0', conditionList: []
        });
      }
    },
    delFilterAnd(item, index, type) {
      if (type === 'child') {
        item.conditionList.splice(index, 1);
      } else {
        this.filterList.splice(index, 1);
      }
      if (this.filterList.length === 0) this.$emit('resetFirst');
    },
    resetFilterData() {
      this.filterList = [];
    },
    getSelectData(data) {
      this.selectData = data;
      this.selectData.forEach((item) => {
        if (item.attrCnName.length > 10) { item.hoverName = `${item.attrCnName.substring(0, 10)}...`; }
      });
    },
    validateList() {
      if (this.$refs.validate && this.$refs.validate.length) {
        this.$refs.validate.forEach((item, idx) => {
          this.$refs.validate[idx].validateItem();
        });
      }
    }
  }
};
</script>
<style lang="less" src="../style/index.less" scoped>
