<template>
  <div class="tabs-title">
    <span
      class="title"
      v-if="list && list.length">{{ title }}</span>
    <div
      class="list-item"
      ref="list"
      :class="{'shouqi': isShowToggle && !isToggle,'zhankai': isShowToggle && isToggle}">
      <div class="list">
        <div
          v-for="(item,index) in list"
          :key="item.name+index+'tabs'"
          :class="{'active':index===activeIndex}">
          <span
            @click="clickTabs(item,index)">
            {{ item.name }}
            <span v-if="item.cnt">{{ '('+item.cnt+')' }}}}</span>
          </span>
        </div>
      </div>
      <div
        class="toggle"
        @click="toggleTabs"
        v-if="isShowToggle">
        {{ !isToggle? '展开':'收起' }}
        <i
          v-if="!isToggle"
          class="el-icon-arrow-down"/>
        <i
          v-else
          class="el-icon-arrow-up"/>
      </div>
    </div>
  </div>
</template>
<script>
// import { UBT } from '@hb/tianqi/lib/pc';

export default {
  props: {
    title: {// 模块名
      type: String,
      default: ''
    },
    tabsList: {// 数据list
      type: Array,
      default: () => ([])
    },
    type: {// 参数
      type: String,
      default: ''
    },
    isCustomExploration: {
      type: Boolean,
      default: false
    },
    initItem: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      input: '',
      list: [],
      activeIndex: 0,
      isToggle: false,
      isShowToggle: false,
    };
  },
  watch: {
    tabsList(newVal) {
      this.list = newVal;
      this.adjustH();
    },
    initItem(newVal) {
      this.activeIndex = newVal;
    }
  },
  mounted() {
    this.list = this.tabsList;
    this.adjustH();
  },
  methods: {
    clickTabs(item, index) { // 点击tab
      // this.activeIndex = index;
      this.$emit('clickTab', item.id, this.type, index);
    },
    toggleTabs() { // 是否展开
      this.isToggle = !this.isToggle;
      // UBT.clickButton({
      //   pageId: 'selfdata',
      //   buttonName: 'data_bar_shrink_button_click',
      //   categoryId: 'dataplatform',
      // });
    },
    adjustH() {
      this.$nextTick(() => {
        const leftH = this.$refs.list.offsetHeight;
        this.isShowToggle = leftH > 30;
      });
    },
  }
};
</script>
<style lang="less" scoped>
@import '../style/variable';

.tabs-title{
  display: flex;
  font-size: 12px;
  margin-bottom: 8px;
  .title{
    width: 70px;
    // font-size: 12px;
    padding-top:4px;
    // height: 42px;
  }
  .list-item{
    width: 100%;
    display: flex;
    position: relative;
  }
  .shouqi{
    height: 30px;
    overflow: hidden;
  }
  .zhankai{
    height: auto;
  }
  .list{
    display: flex;
    flex-wrap: wrap;
    width: 90%;
    &>div{
      // width: 25%;
      flex-shrink: 0;
      span{
        text-align: center;
        cursor: pointer;
        padding:4px 10px;
        margin-right: 5px;
        min-width: 50px;
        display: inline-block;
        margin-bottom: 5px;
        &:hover{
          color:@blue
        }
      }
    }
    .active{
      span{
        background: @blue;
        color:#fff;
        border-radius: 4px;
        &:hover{
          color:#fff
        }
      }
    }
  }
  .toggle{
    font-size: 12px;
    cursor: pointer;
    color:@blue;
    padding-top:4px;
    min-width: 40px;
    position: absolute;
    right: 0;
  }
}
</style>
