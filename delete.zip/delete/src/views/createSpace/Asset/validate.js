const validatorName = (rule, value, callback) => {
  // if (value === '' || value === undefined || value && value.trim() === '') {

  if (value === '' || value === undefined || (value && value.trim() === '')) {
    callback(new Error('请填写任务名'));
  } else if (value.length >= 100) {
    callback(new Error('输入限制100字符'));
  } else {
    callback();
  }
};

const rules = {
  taskType: [
    { required: true, message: '请选择任务类型', trigger: 'change' },
  ],
  scheduledType: [
    { required: true, message: '请选择任务周期', trigger: 'change' },
  ],
  taskName: [
    { required: true, validator: validatorName, trigger: 'blur' },
  ],
};

export default rules;
