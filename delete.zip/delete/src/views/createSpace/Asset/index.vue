<template>
  <div class="main-container">
    <Breadcrumb
      :bread-list="breadList"
      @breadClick="breadClick">
      <el-button
        v-if="breadList[breadList.length-1].name!=='新建资产数据集'"
        slot="left"
        type="text"
        @click="look=!look">{{ look?'查看模式':'编辑模式' }}</el-button>
      <el-button
        :disabled="look"
        type="primary"
        @click="saveData">保存数据集</el-button>
    </Breadcrumb>
    <div
      class="container-web"
      :class="{'disabled-pai':look}">
      <div
        class="container"
        v-loading="loading">
        <!-- 左侧数据集 -->
        <container-left
          @selectIndexAndDim="selectIndexAndDim"
          ref="containerLeft"
          @selectFilterInfo="selectFilterInfo"
          @clearRightData="clearRightData"
          @getDataset="getDataset"
          :showData="showData"/>
        <div class="container-handle"/>
        <div class="container-right">
          <div class="right-content">
            <!-- 查询指标 -->
            <div
              class="icon-title"
              style="margin-top:0">
              <i class="iconfont icon-data"/>查询的指标
            </div>
            <div
              class="content-index"
              @click="(item)=>showTips(item,'指标')">
              <div
                class="empty-content"
                v-if="!indexSelectList.length">查询更多数据请至左侧选中更多指标</div>
              <draggable
                v-model="indexSelectList"
                v-bind="draggableOptions()"
                class="draggable-flex">
                <div
                  class="select-index"
                  v-for="(item,index) in indexSelectList"
                  :key="index+'index'">
                  {{ item.indexName }}
                  <i
                    class="el-icon-circle-close"
                    @click="cancelSelect(index,indexSelectList,'index')"/>
                </div>
              </draggable>
              <span
                @click="clearSelectIndexOrDim('index')"
                class="clear-select"
                v-if="indexSelectList.length"><i class="el-icon-circle-close"/></span>
            </div>
            <!-- 聚合维度 -->
            <div class="icon-title">
              <i class="iconfont icon-weidu"/>聚合的维度
            </div>
            <div
              class="content-index"
              @click="(item)=>showTips(item,'维度')">
              <div
                class="empty-content"
                v-if="!dimSelectList.length">查询更多数据请至左侧选中更多维度</div>
              <draggable
                v-model="dimSelectList"
                v-bind="draggableOptions()"
                class="draggable-flex">
                <div
                  class="select-index select-dim"
                  v-for="(item,index) in dimSelectList"
                  :key="index+'index'">
                  {{ item.dimName }}
                  <i
                    class="el-icon-circle-close"
                    @click="cancelSelect(index,dimSelectList,'dim')"/>
                </div>
              </draggable>
              <span
                @click="clearSelectIndexOrDim('dim')"
                class="clear-select"
                v-if="dimSelectList.length"><i class="el-icon-circle-close"/></span>
            </div>
            <!-- 筛选条件 -->
            <div class="content-filter">
              <div class="filter-title">
                <i class="iconfont icon-shaixuan"/>筛选条件
                <el-button
                  v-if="isFilterList"
                  type="primary"
                  size="mini"
                  style="margin-left:19px"
                  @click="addFilterFirst"><i class="el-icon-plus"/></el-button>
                <el-button
                  v-if="!isFilterList"
                  type="primary"
                  size="mini"
                  style="margin-left:9px"
                  @click="addFilterOr"><i class="el-icon-plus"/>或</el-button>
                <span
                  @click="resetFilterData"
                  class="clear-select"><i class="el-icon-delete-solid"/>清空</span>
                <el-tooltip
                  effect="dark"
                  content="筛选条件内可选内容与查询的指标和维度有关"
                  placement="top">
                  <i class="el-icon-warning-outline"/>
                </el-tooltip>
                <template v-if="dataSetList.ptType === '1' && taskForm.taskType===1">
                  <el-tooltip
                    effect="dark"
                    content="多日期指标&维度配置"
                    placement="top">
                    <i
                      class="el-icon-folder-add"
                      @click="showConfigDialog"/>
                  </el-tooltip>
                </template>
              </div>
              <div class="data-time">
                <span class="time-title">
                  <span style="color:red;margin-right:5px">*</span>
                  数据日期
                </span>
                <template v-if="checkDateType === 1">
                  <el-date-picker
                    style="text-align: center;padding-left:20px"
                    v-if="dataSetList.ptType === '0'"
                    v-model="dateRangeHour"
                    type="datetimerange"
                    :clearable="false"
                    range-separator="至"
                    start-placeholder="开始日期"
                    :picker-options="pickerOptionsHour"
                    end-placeholder="结束日期"
                    value-format="yyyyMMddHH"
                    @change="changeTime"/>
                  <el-date-picker
                    v-else
                    v-model="dateRange"
                    type="daterange"
                    :clearable="false"
                    range-separator="至"
                    value-format="yyyyMMdd"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :picker-options="pickerOptions"
                    @change="changeTime"/>
                </template>
                <div
                  class="fixed"
                  v-else>
                  <span style="margin:10px">T -</span>
                  <el-input
                    text-align="center"
                    @blur="checkDate"
                    type="number"
                    style="width:80px;margin:0 10px;padding:0;"
                    v-model="startDate"
                    placeholder="开始日期"
                    size="mini"/>
                  <span> 至 T - </span>
                  <el-input
                    @blur="checkDate"
                    type="number"
                    style="width:80px;margin:0 10px;padding:0"
                    v-model="endDate"
                    placeholder="截止日期"
                    size="mini"/>
                  <span style="color:#606266">(T代表当前日期)</span>
                </div>
                <el-radio-group
                  v-model="checkDateType"
                  size="small"
                  class="time-type"
                  :disabled="isModelDisabeld">
                  <el-tooltip
                    effect="dark"
                    content="选中固定日期，筛选的日期不会随任何场景发生改变"
                    placement="top">
                    <el-radio-button
                      :label="1"
                      v-model="checkDateType">固定日期</el-radio-button>
                  </el-tooltip>
                  <el-tooltip
                    effect="dark"
                    content="选中相对日期，筛选的日期会根据选择日期发生改变"
                    placement="top">
                    <el-radio-button
                      :label="2"
                      v-model="checkDateType" >相对日期</el-radio-button>
                  </el-tooltip>
                </el-radio-group>
              </div>
              <select-list
                @resetFirst="resetFirst"
                ref="selectList"
                :dataSetId="dataSetId"
                :detail-list="detailList"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Dialog
      v-if="dialogVisibleSet"
      :visible="dialogVisibleSet"
      :params="form"
      :breadList="$route.params.breadList"
      @close="dialogVisibleSet=false"/>
  </div>
</template>

<script>
import request from '@/api/AssetsData.js';
import moment from 'moment';
import draggable from 'vuedraggable';
import containerLeft from './component/containerLeft';
import selectList from './component/selectList';
import options from './options';
import rules from './validate';
import Breadcrumb from 'src/components/Breadcrumb';
import Dialog from '../components/saveDataSet';

export default {
  components: {
    Dialog,
    Breadcrumb,
    containerLeft,
    selectList,
    draggable
  },
  data() {
    return {
      dialogVisibleSet: false,
      look: Boolean(this.$route.params.look),
      form: {
        name: this.res.dataSet.name,
        description: this.res.dataSet.description,
        id: this.res.dataSet.id,
        projectId: this.$route.params.projectId,
        directoryId: this.$route.params.parentId,
      },
      checkDateType: this.paiConfig.ptType === 'relative' ? 2 : 1, // 日期选择方式
      startDate: this.paiConfig.ptType === 'relative' ? (this.paiConfig.startDate || 1) : 1, // 开始时间
      endDate: this.paiConfig.ptType === 'relative' ? (this.paiConfig.endDate || 1) : 1, // 结束时间
      allData: {}, // 回选的详情
      showData: {
        dataSetId: this.paiConfig.dataSetId,
        indexSelectList: this.paiConfig.indexInfoList || [],
        dimSelectList: this.paiConfig.dimInfoList || [],
      }, // 回显 数据集和数据集下面的指标和维度
      indexSelectList: this.paiConfig.indexInfoList || [], // 选中的指标
      dimSelectList: this.paiConfig.dimInfoList || [], // 选中的维度
      detailList: this.paiConfig.conditionList || [], // 筛选条件回选
      isFilterList: !this.paiConfig.conditionList, // 显示且还是或
      dateRange: [], // 日期范围天级
      dateRangeHour: [], // 小时级日期范围
      selectData: [], // 筛选条件下拉
      pickerOptions: options.pickerOptions, // 日期快捷选项天级
      pickerOptionsHour: options.pickerOptionsHour, // 日期快捷选项小时级
      taskForm: {}, // 定时任务,
      ruleForm: rules,
      cycleOptions: options.cycleOptions, // 周期
      weekOptions: options.weekOptions, // 每周
      monthOptions: options.monthOptions(), // 每月
      loading: false, // 正屏
      dialogVisible: false, // 定时任务提交时弹框
      taskType: 1,
      dataSetId: this.paiConfig.dataSetId || '',
      isModelDisabeld: false, // 是否可以选择定时任务和收藏任务
      currentGuid: undefined, // 当前任务id
      dataSetList: { ptType: '1' }, //
      data: { ptType: '1' }
    };
  },
  computed: {
    breadList() {
      const list = (this.$route.params.breadList || []).concat([]);
      if (this.res.columns.length > 0) {
        list.push({ name: `${this.look ? '查看' : `编辑`} 资产 - ${this.form.name} 数据集` });
      } else {
        list.push({ name: '新建资产数据集' });
      }
      return list;
    }
  },
  beforeCreate() {
    this.res = this.$route.params.res || {
      columns: [],
      dataSet: { paiConfig: '{}' }
    };
    this.paiConfig = JSON.parse(this.res.dataSet.paiConfig);
  },
  created() {
    // 初始默认日期
    this.dateRange = options.lastDayTime();
    this.dateRangeHour = options.lastDayTimeHour();
    // 数据日期编辑回显
    if (this.paiConfig.ptType === 'absolute') {
      if (this.dataSetList.ptType === '0') { // hour
        this.dateRangeHour = [this.paiConfig.startDate, this.paiConfig.endDate];
      } else {
        this.dateRange = [this.paiConfig.startDate, this.paiConfig.endDate];
      }
    }
    // 编辑模式
    if (this.res.columns.length > 0 && this.look === false) {
      this.selectFilterInfo(this.indexSelectList, this.dimSelectList);
    }
  },
  methods: {
    checkDate() {
      if (this.startDate === '' || this.endDate === '') {
        this.$message.warning('请输入完整的日期时间');
      }
    },
    breadClick(breadList) { // 跳转
      const h = breadList.length;
      this.$router.push({
        name: 'createSpaceIndex',
        params: {
          parentId: h > 1 ? breadList[h - 1].id : -1,
          projectId: this.$route.params.projectId || -1,
          breadList: JSON.stringify(breadList)
        }
      });
    },
    saveData() { // 保存数据集方法
      if (this.checkDateType === 1) {
        if (!this.dateRangeHour) {
          this.$message.warning('请输入固定日期时间');
          return;
        }
      } else if (this.startDate === '' || this.endDate === '') {
        this.$message.warning('请输入完整的日期时间');
        return;
      } else if (parseInt(this.startDate, 10) < parseInt(this.endDate, 10)) {
        this.$message.error('起始时间的值应大于结束时间的值');
        return;
      }
      const params = this.getParams();
      const valid = this.validateParams(params);
      if (valid) {
        this.form.paiConfig = params;
        this.dialogVisibleSet = true;
      }
    },
    draggableOptions() {
      return {
        animation: 200,
        disabled: false,
        ghostClass: 'ghost',
        forceFallback: true
      };
    },
    cancelSelect(index, list, type) { // 指标维度选中取消
      list.splice(index, 1);
      this.$refs.containerLeft.cancelSelect(list, type);
    },
    selectIndexAndDim(list, type) { // 选中指标|维度
      this[`${type}SelectList`] = list;
    },
    clearSelectIndexOrDim(type) { // 清空指标维度的选择
      this[`${type}SelectList`] = [];
      this.$refs.containerLeft.cancelSelect([], type);
    },
    addFilterFirst() { // 加且
      this.isFilterList = false;
      this.$refs.selectList.createFilterList();
    },
    resetFirst() { // 清空
      this.isFilterList = true;
    },
    addFilterOr() { // 加或
      this.$refs.selectList.addFilterOr();
    },
    resetFilterData() { // 清空
      this.resetFirst();
      this.$refs.selectList.resetFilterData();
    },
    getParams() {
      // 通过refs获取selectList组件内的数据
      let filterList = this.$refs.selectList.filterList || [];
      filterList = JSON.parse(JSON.stringify(filterList));
      // 当数据类型是date的时候，处理rightValue，也就是日期值为字符串，因为后端要求传递字符串
      filterList.forEach((item) => {
        if (item.timeType === 0 || item.timeType === 1) {
          if (item.rightValue === '' || item.rightValue == null) {
            item.rightValue = '[]';
          } else if (Array.isArray(item.rightValue)) {
            item.rightValue = JSON.stringify(item.rightValue);
          }
        }
        if (item.conditionList.length) {
          const conditionListChild = item.conditionList;
          for (let j = 0; j < conditionListChild.length; j += 1) {
            if (conditionListChild[j].timeType === 0 || conditionListChild[j].timeType === 1) {
              if (conditionListChild[j].rightValue === '' || conditionListChild[j].rightValue == null) {
                conditionListChild[j].rightValue = '[]';
              } else if (Array.isArray(conditionListChild[j].rightValue)) {
                conditionListChild[j].rightValue = JSON.stringify(conditionListChild[j].rightValue);
              }
            }
          }
        }
      });
      const {
        indexSelectList, dimSelectList,
        isModelDisabeld, dateRangeHour, dateRange
      } = this;
      const endDate = this.dataSetList.ptType === '0' ? dateRangeHour[1] : dateRange[1];
      const startDate = this.dataSetList.ptType === '0' ? dateRangeHour[0] : dateRange[0];
      const formData = {
        dataSetId: this.dataSetId,
        ptType: this.checkDateType === 1 ? 'absolute' : 'relative',
        setType: this.dataSetList.ptType === '0' ? 'H' : 'T',
        endDate: this.checkDateType === 1 ? `${endDate}` : `${this.endDate}`,
        startDate: this.checkDateType === 1 ? `${startDate}` : `${this.startDate}`,
      };
      if (isModelDisabeld) { // 多pt不传这两个参数
        formData.endDate = undefined;
        formData.startDate = undefined;
      }
      const params = {
        indexInfoList: indexSelectList,
        dimInfoList: dimSelectList,
        conditionList: filterList,
        ...formData,
        modelFieldGroups: null
      };
      return params;
    },
    validateParams(params) { // 参数验证
      if (!params.indexInfoList.length) {
        this.$message.error('请选择指标');
        return false;
      }
      if (!params.dimInfoList.length) {
        this.$message.error('请选择维度');
        return false;
      }
      this.$refs.selectList.validateList();
      //
      const { conditionList, ptType } = params;
      for (let i = 0; i < conditionList.length; i += 1) {
        if (!this.isValidateMethod(conditionList[i])) return false;

        if (conditionList[i].conditionList.length) {
          const conditionListChild = conditionList[i].conditionList;
          for (let j = 0; j < conditionListChild.length; j += 1) {
            if (!this.isValidateMethod(conditionListChild[j])) return false;
          }
        }
      }

      if (ptType === 'absolute') {
        const duration = moment.duration(moment(params.endDate) - moment(params.startDate));
        if (duration.asDays() > 60) {
          this.$message({
            type: 'error',
            message: '数据日期最大选择范围为60天!'
          });
          return false;
        }
      }
      return true;
    },
    isValidateMethod(obj) {
      // if (!obj.isValidate) return false;
      // if (!obj.attrNameValidate) return false;
      if (!obj.attrCnName || !obj.rightValue) {
        return false;
      }
      if (obj.compareSymbol === 9 || obj.compareSymbol === 10) {
        // 比较符号为空或者不为空时，可以不传值，默认校验正确
        return true;
      }
      // if (!obj.rightValueValidate) return false;
      return true;
    },
    changeTime() { // 事件切换
      if (this.dataSetList.ptType === '1' && !this.dateRange) return;
      if (this.dataSetList.ptType === '0' && !this.dateRangeHour) return;
      const dateInfo = this.dataSetList.ptType === '0' ? this.dateRangeHour : this.dateRange;
      const diffDays = moment(dateInfo[1]).diff(moment(dateInfo[0]), 'days');
      if (diffDays > 60) this.$message.error('数据日期最大选择范围为60天');
    },
    selectFilterInfo(indexInfoList, dimInfoList, isDetail) { // 选择过滤信息
      const dataSetId = isDetail ? this.allData.dataSetId : this.dataSetId;
      request.getModelField({
        data: { indexInfoList, dimInfoList, dataSetId }
      }).then((res) => {
        this.selectData = res || [];
        this.selectData.sort((a, b) => a.attrCnName.localeCompare(b.attrCnName, 'zh-CN'));
        this.$refs.selectList.getSelectData(this.selectData);
      });
    },
    clearRightData(indexInfoList, dimInfoList) { // 清空右侧条件
      this.resetFilterData();
      this.selectIndexAndDim([], 'index');
      this.selectIndexAndDim([], 'dim');
      this.selectFilterInfo(indexInfoList, dimInfoList);
    },
    showTips(item, type) { // 点击指标维度空白处显示提示
      const { target } = item;
      if (target.className === 'content-index' || target.className === 'empty-content') {
        this.$message({
          message: `已选中的${type}可拖动排列顺序，查询更多数据请至左侧选中更多${type}`,
          type: 'warning',
          duration: 2000
        });
      }
    },
    //
    showPicDialog() {
      this.$refs.picDialog.toggleDialog();
    },
    // 错误提示信息
    showConfigDialog() {
      if (!(this.indexSelectList.length && this.dimSelectList.length)) {
        this.$message({
          type: 'error',
          message: '请先选择指标维度!'
        });
      } else {
        this.$refs.configDialog.toggleDialog();
      }
    },
    // 获取数据集信息
    getDataset(dataSetList) {
      if (dataSetList) {
        this.dataSetId = dataSetList.id;
        this.dataSetList = dataSetList;
        this.currentGuid = undefined;
        this.isModelDisabeld = false;
        this.detailType = undefined;
      }
    }

  }
};
</script>

<style lang="less" scoped src="./style/index.less">
</style>
