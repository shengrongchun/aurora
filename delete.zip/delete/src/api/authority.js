
// import Ax from 'base/api/axios';
// import config from '@/env.config';

// const API = config.BOX_API;
// // 保存
// export function save(params) {
//   return Ax.post(`${API}/api/view/config/save`, params).then(res => res.data);
// }
// // 删除
// export function del({ id }) {
//   return Ax.get(`${API}/api/view/config/del`, { id }).then(res => res.data);
// }
// // 查询所有
// export function queryAll() {
//   return Ax.get(`${API}/api/view/config/queryAll`).then(res => res.data);
// }
// // 菜单查询
// export function queryCascademenuTree() {
//   return Ax.get(`${API}/api/view/menu/queryCascadeTree`).then(res => res.data);
// }
// // 菜单删除
// export function menuTreeDel({ id }) {
//   return Ax.get(`${API}/api/view/menu/del`, { id }).then(res => res.data);
// }
// // 新增获取视图安全级别
// export function getSecurityLevel() {
//   return Ax.get(`${API}/api/view/config/getSecurityLevel`).then(res => res.data);
// }

// // 视图新增修改
// export function saveMenus(obj) {
//   return Ax.post(`${API}/api/view/menu/save`, obj).then(res => res.data);
// }
// export function queryByName(value) {
//   const params = { name: value };
//   return Ax.get(`${API}/api/user/queryByName`, { params }).then(res => res.data);
// }
// export function saveformData({ obj }) {
//   return Ax.post(`${API}/api/view/config/save`, { obj }).then(res => res.data);
// }

// // 查询所有;
// export function queryCascadeTree() {
//   return Ax.get(`${API}/api/view/config/queryCascadeTree`).then(res => res.data);
// }

// export function queryAllViews() {
//   return Ax.get(`${API}/api/view/config/queryAllViews`).then(res => res.data);
// }
