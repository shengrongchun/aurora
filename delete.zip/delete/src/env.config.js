const config = {
  dev: {
    SPACE_API: 'https://dev-aurora-srv.hellobike.cn',
    DATABOX_API: 'http://121.40.107.27:21010',
    BOX_API: 'https://databox-srv.hellobike.cn',
  },
  fat: {
    SPACE_API: 'https://fat-aurora-srv.hellobike.cn',
    DATABOX_API: 'http://121.40.107.27:21010',
    BOX_API: 'https://gray-databox.hellobike.cn',
  },
  uat: {
    SPACE_API: 'https://uat-aurora-srv.hellobike.cn',
    BOX_API: 'https://gray-databox.hellobike.cn'
  },
  pro: {
    SPACE_API: 'https://aurora-srv.hellobike.cn',
    DATABOX_API: 'https://dataassetgw.hellobike.com',
    BOX_API: 'https://databox-srv.hellobike.cn',
  }
};
export default config.dev;
