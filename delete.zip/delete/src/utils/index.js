/* eslint-disable import/prefer-default-export */
// export function thousandsFmt(num) {
//   return ((num || 0).toString(10)).replace(/(\d{1,3})(?=(\d{3})+$)/g, '$1,');
// }
export function thousandsFmt(num) { // {thousandsFmt}
  let [numVal, dotVal] = (`${num}`).split('.');
  numVal = parseFloat(numVal);
  if (Number.isNaN(numVal)) {
    return null;
  }
  numVal = ((numVal || 0).toString(10)).replace(/(\d{1,3})(?=(\d{3})+$)/g, '$1,');
  if (dotVal) {
    const dotTempVal = parseFloat(dotVal);
    if (Number.isNaN(dotTempVal)) {
      return null;
    }
    dotVal = `.${dotVal}`;
    numVal += dotVal;
  }
  return numVal;
}

// export default { //obj.thousandsFmt
//   thousandsFmt
// };
