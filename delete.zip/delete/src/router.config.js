import Layout from 'base/views/layout/Layout';

export default [{
  path: '/',
  component: Layout,
  // redirect: '/createSpace',
  redirect: '/aurora-edit/1/sql/测试数据源',
  children: [{
    name: '首页',
    path: 'index',
    component: () => import(`@/views/index`),
  }, {
    name: '创作空间',
    path: 'createSpace',
    // redirect
    component: () => import(`@/views/createSpace`),
    children: [{
      name: 'createSpaceIndex',
      path: 'index/:projectId/:parentId/:breadList',
      props: route => (route.params.breadList ? {
        breadList: JSON.parse(route.params.breadList),
        projectId: route.params.projectId || '-1',
        parentId: route.params.parentId || '-1'
      } : {}),
      component: () => import(`@/views/createSpace/Main/index`),
    }, {
      name: 'createSpaceES',
      path: 'es',
      component: () => import(`@/views/createSpace/ES/index`),
    }, {
      name: 'createSpaceSQL',
      path: 'sql',
      component: () => import(`@/views/createSpace/Sql/index`),
    }, {
      name: 'createSpaceAsset',
      path: 'asset',
      component: () => import(`@/views/createSpace/Asset/index`),
    }]
  }]
}, {
  name: 'panel', // 极光编辑报表页面
  path: '/aurora/:projectId/:parentId/:id/:state/:breadList',
  component: () => import(`@/views/panel/index`),
  props: route => (route.params.breadList ? {
    breadList: JSON.parse(route.params.breadList),
    projectId: route.params.projectId || '-1',
    parentId: route.params.parentId || '-1',
    id: route.params.id,
    state: route.params.state,
  } : {}),
  children: []
}, {
  name: 'panelWeb', // 极光最终展示报表页面
  path: '/aurora/view/:id',
  component: () => import(`@/views/panel/web/index`),
  props: route => ({
    id: route.params.id
  }),
}, {
  name: 'selfWeb', // 自取取数分析页面
  path: '/auroraSelfview/:dataSetId/:dataSetType/:dataSetName',
  component: () => import(`@/views/panel/selfWeb/index`),
  props: route => ({
    dataSetId: route.params.dataSetId,
    dataSetType: route.params.dataSetType,
  }),
}, {
  name: 'panelEdit', // 极光编辑报表页面-网站展示
  path: '/aurora-edit/:dataSetId/:dataSetType/:dataSetName',
  component: () => import(`@/views/panel/demo`),
}];
