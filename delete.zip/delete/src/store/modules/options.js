export const utilsCList = [{
  icon: 'Search',
  name: '查询控件'
}, {
  icon: 'Tab',
  name: 'Tab控件'
}];

export const compCList = [{
  icon: 'Select',
  name: '选择框'
}, {
  icon: 'Date',
  name: '日期'
}, {
  icon: 'Line',
  name: '折线图'
}, {
  icon: 'Bar',
  name: '柱状图'
}, {
  icon: 'Comb',
  name: '组合图'
},
{
  icon: 'Lou',
  name: '漏斗图'
},
{
  icon: 'Pie',
  name: '饼图'
},
{
  icon: 'Label',
  name: '标签卡'
},
{
  icon: 'Table',
  name: '表格'
}
// , {
//   icon: 'China',
//   name: '地图'
// }
];

// 根据text设置不重复的name
export function setText(state, style, text) {
  let i = 1;
  let name = null;
  while (i > 0) {
    name = `${text + i}`;
    if (!state.labelMap[name]) {
      style.label.text = name;
      if (!style.label.subText) {
        style.label.subText = null;
      }
      state.labelMap[name] = true;
      i = 0;
    } else {
      i += 1;
    }
  }
}
// 递归遍历删除要删除组件的标题(组件内部可能还有组件，所以要递归)
export function delCompsText(state, list) {
  list.forEach((ele) => {
    delete state.labelMap[ele.styles.label.text];
    if (ele.type === 'Search') {
      const { compList } = ele.styles;
      if (compList) {
        delCompsText(state, compList);
      }
    } else if (ele.type === 'Tab') {
      const { tabList } = ele.styles;
      tabList.forEach((tab) => {
        if (tab.compList) {
          delCompsText(state, tab.compList);
        }
      });
    }
  });
}
// 复制style样式
function getCopyStyles() {
  return {
    lineParams: {
      smooth: false, // 默认是折线
      stack: null, // 默认是单个 堆积
      areaStyle: null, // 默认是曲线 面积
    },
    barParams: {
      vertical: true, // bar 的垂直方向
      stack: null, // 默认是单个 堆积
    },
    labelNormal: {
      show: false,
      position: 'top'
    }, // 显示图表数据标签
    label: {// 标题备注
      text: null,
      subtext: null
    },
    tooltip: {
      show: true,
      confine: true, // 防止tooltip溢出容器截断
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    legend: {// 图例
      data: [],
      show: true,
      type: 'scroll',
      top: 'top',
      padding: [30, 20, 20, 15]
    },
    series: [],
    xAxis: [{
      type: 'category',
      data: [],
      select: [], // x轴选择的维度
      splitLine: {
        show: true
      },
      axisLabel: {
        show: true
      },
      show: true,
      name: null,
    }],
    yAxis: [{// 左侧y 轴
      type: 'value',
      min: 'dataMin',
      show: true,
      name: null,
      select: [], // 度量
      splitLine: {
        show: true
      },
      axisLabel: {
        show: true
      },
    }, {// 右侧y 轴
      type: 'value',
      min: 'dataMin',
      show: true,
      name: null,
      select: [], // 度量
      splitLine: {
        show: true
      },
      axisLabel: {
        show: true
      },
    }]
  };
}
// 获取类型的styles
function getStyles(state, type) {
  const styles = getCopyStyles();
  if (type === 'Line') {
    setText(state, styles, '折线图');
    return styles;
  }
  if (type === 'Bar') {
    setText(state, styles, '柱状图');
    return styles;
  }
  if (type === 'Comb') {
    setText(state, styles, '组合图');
    return styles;
  }
  if (type === 'Label') {
    const style = {
      label: {// 标题备注
        text: null,
        subtext: null
      },
    };
    setText(state, style, '标签卡');
    return style;
  }
  if (type === 'Pie') {
    const style = {
      label: {// 标题备注
        text: null,
        subtext: null
      },
      labelNormal: {// 显示图表数据标签
        show: true,
        position: 'outside',
        formatter: '{b} : {c} ({d}%)'
      },
      tooltip: {
        confine: true, // 防止tooltip溢出容器截断
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
      },
      legend: {
        show: true,
        top: 'top',
        type: 'scroll',
        padding: [30, 20, 20, 15],
        data: []
      },
      series: [
        {
          name: '饼图',
          type: 'pie',
          radius: '75%',
          center: ['45%', '60%'],
          top: 60,
          bottom: 35,
          data: [],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    };
    setText(state, style, '饼图');
    return style;
  }
  if (type === 'Lou') {
    const style = {
      label: {// 标题备注
        text: null,
        subtext: null
      },
      labelNormal: {
        show: true,
        position: 'left',
        formatter: '{b} : {c} {d}%'
      },
      tooltip: {
        confine: true, // 防止tooltip溢出容器截断
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} {d}%'
      },
      legend: {
        show: true,
        type: 'scroll',
        top: 'top',
        padding: [30, 20, 20, 15],
        data: []
      },
      series: [
        {
          name: '漏斗图',
          type: 'funnel',
          left: '10%',
          top: 60,
          bottom: 35,
          width: '80%',
          min: 0,
          max: 100,
          minSize: '0%',
          maxSize: '100%',
          sort: 'none',
          gap: 2,
          emphasis: {
            label: {
              fontSize: 20
            }
          },
          data: []
        }
      ]
    };
    setText(state, style, '漏斗图');
    return style;
  }
  if (type === 'Tab') {
    const style = {
      label: {},
      tabPosition: 'top',
      tabList: []
    };
    setText(state, style, 'Tab');
    return style;
  }
  if (type === 'Search') {
    const style = {
      label: {},
      compList: [],
      btnName: '查询'
    };
    setText(state, style, '搜索框');
    return style;
  }
  if (type === 'Select') {
    const style = {
      label: {},
      value: null, // 选中值
      multiple: false, // 是否多选
      columnVal: {}, // 传值属性
      columnName: {}, // 显示属性
      map: {},
    };
    setText(state, style, '选择框');
    return style;
  }
  if (type === 'Date') {
    const style = {
      label: {},
      value: null,
      type: 'daterange', // 日期区间类型
      time: {
        show: true,
        position: 'pre', // next pre
        value: 1,
        unit: 60 * 60 * 24,
      },
      map: {},
    };
    setText(state, style, '日期');
    return style;
  }
  if (type === 'Table') {
    const style = {
      label: {},
      indexNo: false, // 显示序号
      position: 'center', // 列对齐方式
      page: false, // 是否显示分页
    };
    setText(state, style, '表格');
    return style;
  }
  return {};
}
function getW(state, type) {
  if (type === 'Tab' || type === 'Search') {
    return state.colNum;
  }
  if (state.searchComps[type]) {
    return state.colNum / 4;
  }
  return state.colNum / 2;
}
function getH(state, type) {
  if (type === 'Search') {
    return 3;
  }
  if (state.searchComps[type]) {
    return 2;
  }
  return 10;
}
export function getTypeObj({ type, x, y }, i, state) {
  return {
    i, // 唯一id
    type, // 组件类型
    // 组件位置信息
    x,
    y,
    h: getH(state, type),
    w: getW(state, type),
    //
    styles: getStyles(state, type),
    params: {}, // 数据源参数
  };
}
// 组件切换相关方法
// 添加新组件并删除旧组件
function delAddComp(list, id, obj, state) {
  for (let i = 0, j = list.length; i < j; i += 1) {
    if (list[i].type === 'Tab') {
      list[i].styles.tabList.forEach((tab) => {
        delAddComp(tab.compList || [], id, obj, state);
      });
    } else if (list[i].i === id) {
      // 删除标题
      delete state.labelMap[list[i].styles.label.text];
      list.splice(i, 1);// 删除
      list.push(obj);// 新增
      return;
    }
  }
}
// 新旧组件参数交换
// 切换规则 http://wiki.cheyaoshicorp.com/pages/viewpage.action?pageId=188540995
function switchParams(newObj, oldObj) {
  // 设置 params
  const newP = newObj.params;
  const oldP = oldObj.params;
  if (oldObj.type !== 'Table') { // 旧组件不是表格
    if (newObj.type === 'Table') {
      newP.pageNo = 1;
      newP.hasMetric = 'columns';
      newP.rows = oldP.dimensions;
      newP.columns = oldP.metrics;
      delete oldP.metrics;
      delete oldP.dimensions;
    }
  } else { // 旧组件是表格
    delete oldP.pageNo;
    delete oldP.hasMetric;
    const { rows, columns } = oldP;
    newP.dimensions = [];
    newP.metrics = [];
    rows.concat(columns).forEach((item) => {
      if (item.dmType === 'dimension') {
        newP.dimensions.push(item);
      } else {
        newP.metrics.push(item);
      }
    });
  }
  //
  Object.assign(newP, oldP);
  // 设置styles
  const newStyles = newObj.styles;
  const oldStyles = oldObj.styles;
  const { xAxis, yAxis } = newStyles;
  if (xAxis instanceof Array) { // 需要设置新组件的 xAxis yAxis
    if (oldStyles.xAxis instanceof Array) {
      xAxis[0].select = oldStyles.xAxis[0].select && oldStyles.xAxis[0].select[0]
        ? [oldStyles.xAxis[0].select[0]] : [];
      yAxis[0].select = oldStyles.yAxis[0].select || [];
      yAxis[1].select = oldStyles.yAxis[1].select || [];
    } else { // 可能是table组件
      xAxis[0].select = newP.dimensions[0] ? [newP.dimensions[0]] : [];
      yAxis[0].select = newP.metrics[0] ? [newP.metrics[0]] : [];
      yAxis[1].select = [];
    }
  }
}
export function switchMethod(state, newTypeObj) {
  const oldTypeObj = state.activeComp;// 旧组件
  // 新旧组件参数交换
  switchParams(newTypeObj, oldTypeObj);
  // 删除添加操作
  delAddComp(state.compList, oldTypeObj.i, newTypeObj, state);
}
// line bar comb
// dataSetId: (...)
// dataSetName: (...)
// dataSetType: (...)
// dimensions: (...)
// filters: (...)
// metrics: (...)
// pageSize: (...)

// tabel
// columns: Array(1)
// dataSetId: 36
// dataSetName: "测试数据源mysql"
// dataSetType: "sql"
// filters: Array(0)
// hasMetric: "columns"
// pageNo: 1
// pageSize: 20
// rows: Array(1)
