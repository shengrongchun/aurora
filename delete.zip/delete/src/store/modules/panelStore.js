import {
  getTypeObj, switchMethod
} from './options.js';
//
const panelStore = {
  state: {// 定义响应式变量
    colNum: 24, // 行分多少栅格
    rowHeight: 10, // 列一栅格多少px
    searchComps: { Select: true, Date: true }, // 在查询组件中存放的组件
    compList: [], // 组件列表
    labelMap: {}, // 组件名称去重对象
    theme: 'default', // 主题
    //
    preView: false,
    activeComp: {}, // 选中组件
    datasetList: null, // 缓存数据集，不要切换组件每次都请求
  },
  mutations: {// 改变state状态的唯一定义同步方法
    changeActiveComp(state, val) {
      if (state.preView) return;
      state.activeComp = val;
    },
    addComp(state, obj) { // 增加组件方法
      if (obj.type === 'Search' && obj.compType === 'Search') {
        obj.vm.$message({
          type: 'warning',
          message: `${obj.type} 查询组件不能拖入查询组件中`
        });
        return;
      }
      if (state.searchComps[obj.type] && obj.compType !== 'Search') {
        obj.vm.$message({
          type: 'warning',
          message: `${obj.type} 组件只能拖入查询组件中`
        });
        return;
      }
      if (!state.searchComps[obj.type] && obj.compType === 'Search') {
        obj.vm.$message({
          type: 'warning',
          message: `${obj.type} 组件不能拖入查询组件中`
        });
        return;
      }
      const i = new Date().getTime();
      state.activeComp = getTypeObj(obj, i, state);
      // 目的是兄弟之间生命周期顺序的问题
      if (obj.type === 'Search') { // 如果是查询组件，需要放在末尾
        obj.list.push(state.activeComp);
      } else { // 否则放在最前面
        obj.list.unshift(state.activeComp);
      }
    },
    switchComp(state, type) { // 切换组件调用方法
      const {
        x, y, w, h
      } = state.activeComp;
      const typeObj = getTypeObj({
        type, // 切换类型
        x,
        y,
      }, new Date().getTime(), state);
      Object.assign(typeObj, { w, h });
      // 删除
      switchMethod(state, typeObj);
      state.activeComp = typeObj;
    },
    setCompList(state, obj) { // 保存方法
      const { labelMap, compList, theme } = obj;
      state.compList = compList;
      state.labelMap = labelMap;
      state.theme = theme || 'default';
    },
    initState(state) {
      state.preView = false;// 默认非预览模式
      state.compList = []; // 组件列表
      state.activeComp = {}; // 选中组件
      state.labelMap = {}; //
      state.theme = 'default';// 主题
      state.datasetList = null;// 数据集
    }
  }
};
export default panelStore;
