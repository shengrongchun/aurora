const d = (el, binding) => {
  const { _actions } = window;
  if (el && _actions && _actions.indexOf(binding.value) === -1) {
    el.style.display = 'none';
  }
};

export default {
  bind: d,
  inserted: d,
  update: d
};
