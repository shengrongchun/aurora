<template>
  <header class="navbar">
    <div class="leftIcon">
      <router-link :to="{name:'首页'}">Aurora</router-link>
    </div>
    <div class="centerMenu">
      <Menu />
    </div>
    <el-dropdown class="rightLogin">
      <div class="avatar-wrapper">
        {{ userName || '未登录' }}
        <!-- <i class="el-icon-caret-bottom" /> -->
      </div>
      <el-dropdown-menu
        slot="dropdown"
        class="user-dropdown"
      >
        <el-dropdown-item><span @click="logout">退出登录</span></el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </header>
</template>

<script>
import ssoAuth from '@hb/sso-auth';
import Menu from './Menu';

export default {
  components: {
    Menu,
  },
  computed: {
    userName() {
      return ssoAuth.userInfo.realName;
    }
  },
  methods: {
    logout() {
      ssoAuth.signOut();
    },
  }
};
</script>

<style lang="less" scoped>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  font-family: Zapfino,Arial,Verdana,Sans-serif;
  font-weight: bolder;
  height: 60px;
  line-height: 67px;
  background: #000;
  color: #fff;
  .leftIcon {
    height: 100%;
    font-size: 20px;
    min-width: 300px;
    margin: 0 25px;
    float: left;
  }
  .centerMenu {
    display: inline-block;
  }
  .rightLogin {
    margin: 0 15px;
    float: right;
    .avatar-wrapper {
      font-size: 16px;
      color: #fff;
    }
  }
}
</style>
