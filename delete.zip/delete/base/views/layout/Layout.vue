<template>
  <div class="layout">
    <Navbar />
    <AppMain />
  </div>
</template>
<script>
import Navbar from './Navbar';
import AppMain from './AppMain';

export default {
  name: 'Layout',
  components: {
    Navbar,
    AppMain
  }
};
</script>
<style scoped>
.layout {
  height: 100%;
}
</style>
