/* eslint-disable import/prefer-default-export */

export function filterParams(obj) {
  if (!obj) return {};
  Object.keys(obj).forEach((item) => {
    if (obj[item] === null || obj[item] === undefined || obj[item] === '') delete obj[item];
  });
  return obj;
}
